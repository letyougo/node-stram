db = 'org'
sql = """

CREATE TABLE "uc_department_yxt" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "department_id" bigint NOT NULL,
    "uuid" varchar(36) NOT NULL,
    UNIQUE ("department_id", "uuid")
)
;

"""
