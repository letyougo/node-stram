db = 'main'
sql = """
alter table uc_user_yxt add column "username" varchar(128) NOT NULL default '';
"""
