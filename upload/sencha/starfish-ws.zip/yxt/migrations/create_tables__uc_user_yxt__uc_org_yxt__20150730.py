db = 'main'
sql = """
CREATE TABLE "uc_user_yxt" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "user_id" bigint NOT NULL,
    "uuid" varchar(36) NOT NULL,
    UNIQUE ("user_id", "uuid")
)
;
CREATE TABLE "uc_org_yxt" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "org_id" bigint NOT NULL,
    "uuid" varchar(36) NOT NULL,
    UNIQUE ("org_id", "uuid")
)

"""
