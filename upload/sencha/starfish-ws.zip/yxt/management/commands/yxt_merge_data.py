from django.core.management import BaseCommand
from apps.acl.models import UserRole
from apps.bfs.models import BfsFile
from apps.chat.models import TextChat, MultimediaChat
from apps.message.models import MessageContent, Message, UserMessage, UserConversation
from apps.org.models import UserDepartment, DiscussionGroup, UserDiscussionGroup, WorkMail
from common.const import SrcType, DestType, PeerType
from yxt.utils import *
from log import config_logging

config_logging(filename='/mnt1/logs/starfish-yxt-merge-data.log')

log = logging.getLogger(__name__)

old_db = 'default_old'
new_db = 'default'
'''
bfs_file，
chat_multimedia， chat_text，
uc_department， uc_user_department
uc_discussion_group， uc_user_discussion_group
message， message_message_content， message_user_conversation， message_user_message
uc_user_position， uc_work_mail
acl_user_role
'''


class Command(BaseCommand):
    def handle(self, *args, **options):
        input('!!!disable apps.org.__init__ signal import first!!! ')

        self.skip_unknown_user = False
        if args[0] == 'import':
            self.org_id = int(args[1])
            self.transfer_all_users()
            self.transfer_all_orgs()
            self.transfer_all_user_orgs()
            return

        self.old_org_id, self.org_id = int(args[0]), int(args[1])

        self.user_match_table = self._all_users_ready()

        # BfsFile
        self.do_all(self.bfs_file, model=BfsFile)
        # TextChat, MultimediaChat
        self.do_all(self.chat, model=TextChat)
        self.do_all(self.chat, model=MultimediaChat)

        # Department, UserDepartment
        self.do_all(self.trans_user_field, model=Department, field='creator')
        self.do_all(self.trans_user_field, model=UserDepartment, order_by='-user_id', field='user_id')

        # DiscussionGroup, UserDiscussionGroup
        self.do_all(self.trans_user_field, model=DiscussionGroup, field='creator')
        self.do_all(self.trans_user_field, model=UserDiscussionGroup, order_by='-user_id', field='user_id')

        # UserPosition
        self.do_all(self.trans_user_field, model=UserPosition, order_by='-user_id', field='user_id')

        # WorkMail
        self.do_all(
            self.work_mail,
            qs=WorkMail.objects.using(self.org_id).filter(owner_type=WorkMail.TYPE_ORG_MEMBER).order_by('-owner')
        )

        # Message, MessageContent
        self.do_all(
            self.message,
            qs=Message.objects.using(self.org_id).filter(
                type__in=[Message.TYPE_TEXT_CHAT_CREATED, Message.TYPE_MULTIMEDIA_CHAT_CREATED]
            )
        )
        self.clear_message()

        # UserMessage, UserConversation
        self.do_all(self.usermessage_conversation, model=UserMessage, order_by='-user_id')
        self.do_all(self.usermessage_conversation, model=UserConversation, order_by='-user_id')

        # UserRole
        self.do_all(self.trans_user_field, model=UserRole, field='user_id')

    ##########################################################################
    def _all_users_ready(self):
        results = {}
        old_dict = dict((k, v) for k, v in UserYxt.objects.using(old_db).values_list('uuid', 'user_id'))
        new_dict = dict((k, v) for k, v in UserYxt.objects.using(new_db).values_list('uuid', 'user_id'))
        for uuid, old_uid in old_dict.items():
            if uuid not in new_dict:
                raise ValueError('UserYxt: %s(%s) missing' % (old_uid, uuid))
            results[old_uid] = new_dict[uuid]

        return results

    def _user_id_from_db(self, old_user_id):
        try:
            old_yxt = UserYxt.objects.using(old_db).get_or_none(user_id=old_user_id)
            if not old_yxt:
                raise ValueError('old UserYxt: %s missing' % (old_user_id))

            uuid = old_yxt.uuid

            new_yxt = UserYxt.objects.using(new_db).get_or_none(uuid=uuid)
            if not new_yxt:
                raise ValueError('new UserYxt: %s(%s) missing' % (old_user_id, uuid))
        except Exception as e:
            if self.skip_unknown_user:
                return old_user_id
            else:
                c = input('%s, Input c [continue], or s [skip_unknown_user]' % (e))
                if c == 's':
                    self.skip_unknown_user = True
                    return old_user_id
                elif c == 'c':
                    return UserYxt.objects.using(new_db).all().order_by('user_id')[0].user_id
            raise e

        return new_yxt.user_id

    def t_user_id(self, old_user_id):
        if old_user_id not in self.user_match_table:
            return self._user_id_from_db(old_user_id)
        else:
            return self.user_match_table[old_user_id]

    def t_filepath(self, old_filepath):
        l = old_filepath.split('/')
        l[0] = str(self.org_id)
        return '/'.join(l)
        # return '%s%s' % (self.org_id, old_filepath[1:])

    ###############################################################
    def do_all(self, method, qs=None, model=None, order_by=None, **kwargs):
        self.skip_unknown_user = False

        if qs is None:
            qs = model.objects.using(self.org_id).all().order_by(order_by or 'id')
        else:
            model = qs.model

        c = input('Ready to start %s, Input c [continue], s [skip]' % (model.__name__))
        if c != 'c':
            return

        total = qs.count()
        for i, o in enumerate(qs):
            result = method(o, **kwargs)
            log.info('%06d/%06d -%s-%s-%s: %s'
                     % (i+1, total, model.__name__, method.__name__, o.id, result))

    def get_diff(self, obj, field):
        diff_values = obj.get_field_diff(field)
        if diff_values:
            return {field: diff_values}

    def get_obj_field(self, obj, field):
        if self.old_org_id:
            model = type(obj)
            old_obj = model.objects.using(self.old_org_id).get_or_none(id=obj.id)
            if old_obj:
                return getattr(old_obj, field)
        else:
            return getattr(obj, field)

    def update_user_field(self, obj, field):
        val = self.get_obj_field(obj, field)
        if val:
            setattr(obj, field, self.t_user_id(val))
            return self.get_diff(obj, field)

    #################################################################
    def bfs_file(self, bfs):
        '''BfsFile.filepath'''
        diff = None
        if bfs.filepath:
            bfs.filepath = self.t_filepath(bfs.filepath)
            diff = self.get_diff(bfs, 'filepath')
            if diff:
                bfs.save()
        return diff

    def trans_user_field(self, obj, field):
        '''obj.field'''
        diff = self.update_user_field(obj, field)
        if diff:
            obj.save()
        return diff

    def work_mail(self, wm):
        '''WorkMail.owner_type'''
        diff = None
        if wm.owner_type == WorkMail.TYPE_ORG_MEMBER:
            diff = self.update_user_field(wm, 'owner')
            if diff:
                wm.save()
        return diff

    def chat(self, chat):
        '''BaseChat: src_type, src_id, dest_type, dest_id'''
        changes = []
        if chat.src_type == SrcType.ORG_MEMBER:
            diff = self.update_user_field(chat, 'src_id')
            if diff:
                changes.append(diff)

        if chat.dest_type == DestType.ORG_MEMBER:
            diff = self.update_user_field(chat, 'dest_id')
            if diff:
                changes.append(diff)

        if hasattr(chat, 'filepath'):
            chat.filepath = self.t_filepath(chat.filepath)
            diff = self.get_diff(chat, 'filepath')
            if diff:
                changes.append(diff)

        if changes:
            chat.save()

        return changes

    def message(self, m):
        '''Message: src_id, dest_id, MessageContent: content'''
        changes = self.chat(m)
        mc = MessageContent.objects.using(self.org_id).get_or_none(id=m.content)
        if m.type == Message.TYPE_TEXT_CHAT_CREATED:
            chat = TextChat.objects.using(self.org_id).get_or_none(id=m.resource_id)
        elif m.type == Message.TYPE_MULTIMEDIA_CHAT_CREATED:
            chat = MultimediaChat.objects.using(self.org_id).get_or_none(id=m.resource_id)

        if mc and chat:
            mc.content = {'chat': chat.to_dict()}
            mc.save()
            changes.append({'type': m.type, 'message_content': mc.id, 'chat': chat.id})

        return changes

    def usermessage_conversation(self, obj):
        '''UserMessage/UserConversation: user_id, peer_id'''
        changes = []
        diff = self.update_user_field(obj, 'user_id')
        if diff:
            changes.append(diff)

        if obj.peer_type == PeerType.ORG_MEMBER:
            diff = self.update_user_field(obj, 'peer_id')
            if diff:
                changes.append(diff)
        if changes:
            if isinstance(obj, UserMessage):
                obj.save(force_save=True)
            else:
                obj.save()

        return changes

    def clear_message(self):
        #  TYPE_DISCUSSION_GROUP_MEMBER_LEFT, TYPE_DISCUSSION_GROUP_DISBANDED
        to_be_deleted = Message.objects.using(self.org_id).exclude(
            type__in=[Message.TYPE_TEXT_CHAT_CREATED, Message.TYPE_MULTIMEDIA_CHAT_CREATED]
        )
        to_be_deleted_ids = list(to_be_deleted.values_list('id', flat=True))
        to_be_deleted_contents = list(to_be_deleted.values_list('content', flat=True))
        log.info('to_be_deleted message ids, count=%s' % len(to_be_deleted_ids))

        UserMessage.objects.using(self.org_id)\
            .filter(message_id__in=to_be_deleted_ids)\
            .delete(force=True)
        UserConversation.objects.using(self.org_id)\
            .filter(last_message_id__in=to_be_deleted_ids)\
            .update(last_message_id=0)
        UserConversation.objects.using(self.org_id)\
            .filter(max_message_id__in=to_be_deleted_ids)\
            .update(max_message_id=0)

        to_be_deleted.delete(force=True)

        MessageContent.objects\
            .using(self.org_id)\
            .filter(id__in=to_be_deleted_contents)\
            .delete(force=True)

    #########################################################
    def transfer_all_users(self):
        if input('import all users? y/n?') != 'y':
            return

        importer = ImportUser()
        for i, ux in enumerate(UserYxt.objects.using(old_db).all()):
            log.info('import User line: %s, %s, %s' % (i, ux.user_id, ux.uuid))

            u = User.objects.using(old_db).get_or_none(id=ux.user_id)
            if not u:
                log.error('missing: %s' % (ux.uuid))
                continue
            data = dict(seq=i, uuid=ux.uuid, status=1,
                        phone=u.phone, username=ux.username, name=u.name,
                        avatar=u.avatar, intro=u.intro, gender=u.gender)
            importer.import_by_data(data)

    def transfer_all_orgs(self):
        if input('import all orgs? y/n?') != 'y':
            return

        importer = ImportOrg()
        for i, ox in enumerate(OrgYxt.objects.using(old_db).filter(org_id=self.org_id)):
            log.info('import Org line: %s, %s, %s' % (i, ox.org_id, ox.uuid))

            o = Org.objects.using(old_db).get_or_none(id=ox.org_id)
            if not o:
                continue
            data = dict(seq=i, uuid=ox.uuid, is_deleted=0,
                        creator_uuid='', name=o.name,
                        avatar=o.avatar, intro=o.intro)
            importer.import_by_data(data)

    def transfer_all_user_orgs(self):
        if input('import all user_orgs? y/n?') != 'y':
            return

        importer = ImportUserOrg()
        for i, uo in enumerate(UserOrg.objects.using(old_db).filter(org_id=self.org_id)):
            log.info('import UserOrg line: %s, %s, %s' % (i, uo.org_id, uo.user_id))

            ux = UserYxt.objects.using(old_db).get_or_none(user_id=uo.user_id)
            ox = OrgYxt.objects.using(old_db).getx(org_id=uo.org_id)
            if not ux or not ox:
                log.error('missing: ux: %s, ox: %s' % (ux, ox))
                continue
            data = dict(seq=i, user_uuid=ux.uuid, org_uuid=ox.uuid, status=0 if uo.is_left else 1)
            importer.import_by_data(data)