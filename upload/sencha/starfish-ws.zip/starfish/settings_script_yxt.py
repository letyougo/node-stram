from .settings_prod_yxt import *

DEBUG = False
LOGGING_CONFIG = None

# 13s
MAX_QUERY_EXECUTION_TIME = 13000
