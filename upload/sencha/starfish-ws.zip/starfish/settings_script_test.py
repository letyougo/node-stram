from .settings_test import *

DEBUG = False
LOGGING_CONFIG = None

# 13s
MAX_QUERY_EXECUTION_TIME = 13000
