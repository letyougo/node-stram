#!/usr/bin/env python
import os

os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import json
import signal
import time
import utils

from django.db import connections

from apps.message.models import Message
from apps.message.utils import UserMessageUtils
from common.message_queue import MessageConsumerBase, SaveMessageQueue
from common.utils import shard_id

from log import config_logging
config_logging(filename='/mnt1/logs/starfish-save-user-message.log')

import logging
log = logging.getLogger(__name__)


class MessageConsumer(MessageConsumerBase):
    def consume(self, message):
        data = json.loads(message)
        org_id = data.get('scope_org_id', 0)

        if shard_id(org_id) not in settings.DATABASES:
            return

        m_obj = Message.objects.using(org_id).getx(id=data['id'])
        if not m_obj or m_obj.is_sent != 0:
            return

        body = dict(scope_org_id=data['scope_org_id'], id=data['id'],
                    session_id=data['session_id'])

        # ########## send logic, to fast or slow partitions #########
        if m_obj.type in [Message.TYPE_EMAIL_CREATED, ]:
            SaveMessageQueue().send_to(body, org_id, SaveMessageQueue.TO_SLOW)
        else:
            user_message_meta = UserMessageUtils.get_user_message_meta(m_obj)
            if user_message_meta:
                body.update(user_message_meta=user_message_meta)

                if len(user_message_meta) > settings.STARFISH_SAVE_USER_MESSAGE_LIMIT:
                    _to = SaveMessageQueue.TO_SLOW
                else:
                    _to = SaveMessageQueue.TO_FAST

                SaveMessageQueue().send_to(body, org_id, _to)
        #############################################################

        connections[shard_id(org_id)].close()

    def _get_name(self):
        return str(__file__)

if __name__ == '__main__':
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    utils.register_to_zk_or_wait(__file__, settings.ZK_HOSTS)

    MessageConsumer(
        conf={
            'url': settings.KAFKA_URL,
        },
        queue=settings.STARFISH_MESSAGE_QUEUE_NAME
    ).start()

    while True:
        time.sleep(1)
