import os

os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import json
import signal
import utils
import OpenSSL

from datetime import datetime, timedelta
from apnsclient import Session, APNs, Message

from maxwell import BackendSubscriber, BackendListener
from common.maxwell_utils import MaxwellEndpointUtil

from apps.account.models import User, UserDevice
from apps.org.models import Invitation
from apps.message import models

from log import config_logging
config_logging(
    filename='/mnt1/logs/starfish-push-to-ios-devices-%s.log' % os.environ['IOS_PUSH_ENV']
)

import logging
logging.getLogger("apnsclient.backends.stdio").setLevel(logging.ERROR)
log = logging.getLogger(__name__)


class MessageFormater(object):
    TYPE_INVITATION_CREATED = '{name}邀请您加入{org_name}'

    TYPE_INVITATION_UPDATED_CONFIRM = '{name}接受了您的邀请，加入了{org_name}'
    TYPE_INVITATION_UPDATED_IGNORE = '{name}忽略了您的邀请，没有加入{org_name}'
    TYPE_INVITATION_UPDATED_REFUSE = '{name}拒绝了您的邀请，没有加入{org_name}'

    TYPE_TEXT_CHAT_CREATED = '{name}：{chat_text}'
    TYPE_MULTIMEDIA_CHAT_CREATED = '{name}：[{format}]'

    TYPE_TASK_CREATED = '{name}：创建[任务]'
    TYPE_TASK_COMPLETED = '{name}：完成[任务]'

    TYPE_MAIL_CREATED = '{name}：[邮件]'


class SimpleListener(BackendListener):

    USER_DEVICE_TOKEN_EXPIRED = 20

    RETRIES = 3

    def __init__(self):
        self.session = Session()

    def on_success(self, pub_msg):
        try:
            self._on_success0(pub_msg)
        except Exception as e:
            log.info(pub_msg)
            log.exception(e)
            os._exit(1)

    def _on_success0(self, pub_msg):
        log.info('got pub message: %s', pub_msg.msg.id)
        user_ids = set([agent.user_id for agent in pub_msg.agents])
        for i in self._build_messages(user_ids, pub_msg.msg):
            self._send_message(i)

    def on_failure(self, errcode, errmsg):
        log.error('maxwell backend_subscriber error: %s, %s', errcode, errmsg)
        os._exit(1)

    def on_timeout(self):
        log.error('maxwell backend_subscriber timeout')
        os._exit(1)

    def _get_cert(self):
        if settings.IS_YXT_ENV:
            return '%s/conf/apns-%s_yxt.pem' % (root_path, os.environ['IOS_PUSH_ENV'])
        else:
            return '%s/conf/apns-%s.pem' % (root_path, os.environ['IOS_PUSH_ENV'])

    def _should_build_message(self, user_device):
        return user_device.update_time and user_device.update_time > \
            datetime.now() - timedelta(days=self.USER_DEVICE_TOKEN_EXPIRED)

    def _build_messages(self, user_ids, message):
        message = json.loads(message.payload.decode('utf8'))

        type_, message_ = message['type'], message
        if message['type'] == models.Message.TYPE_CONVERSATION_UPDATED:
            type_ = message['body']['conversation']['last_message']['type']
            message_ = message['body']['conversation']['last_message']

        if not hasattr(self, '_build_messages_type_%s' % type_):
            log.info('skip message, type=%s', type_)
            return []

        log.info('build message, user_ids=%s, id=%s, type=%s', user_ids, message_['id'], type_)

        return getattr(self, '_build_messages_type_%s' % type_)(user_ids, message_)

    def _build_messages_type_0(self, user_ids, message):
        invitation = message['body']['invitation']
        return self.__build_message(
            set([invitation['whom']['id']]) & user_ids,
            MessageFormater.TYPE_INVITATION_CREATED.format(
                name=invitation['who']['name'],
                org_name=invitation['org']['name']
            )
        )

    def _build_messages_type_1(self, user_ids, message):
        invitation = message['body']['invitation']
        if invitation['status'] == Invitation.STATUS_CONFIRM:
            alert = MessageFormater.TYPE_INVITATION_UPDATED_CONFIRM.format(
                name=invitation['whom']['name'],
                org_name=invitation['org']['name']
            )
        elif invitation['status'] == Invitation.STATUS_IGNORE:
            alert = MessageFormater.TYPE_INVITATION_UPDATED_IGNORE.format(
                name=invitation['whom']['name'],
                org_name=invitation['org']['name']
            )
        elif invitation['status'] == Invitation.STATUS_REFUSE:
            alert = MessageFormater.TYPE_INVITATION_UPDATED_REFUSE.format(
                name=invitation['whom']['name'],
                org_name=invitation['org']['name']
            )
        else:
            log.warning('invalid invitation status: %s', invitation['status'])
            return []

        return self.__build_message(
            set([invitation['who']['id']]) & user_ids,
            alert
        )

    def _build_messages_type_2(self, user_ids, message):
        user = User.objects.get_or_none(id=message['src_id'])

        return self.__build_message(
            user_ids,
            MessageFormater.TYPE_TEXT_CHAT_CREATED.format(
                name=user.name,
                chat_text=message['body']['chat']['content']
            )
        )

    def _build_messages_type_3(self, user_ids, message):
        user = User.objects.get_or_none(id=message['src_id'])

        format_ = '文件'
        if message['body']['chat']['mimetype'].startswith('image/'):
            format_ = '图片'
        elif message['body']['chat']['mimetype'].startswith('audio/'):
            format_ = '语音'
        else:
            pass

        return self.__build_message(
            user_ids,
            MessageFormater.TYPE_MULTIMEDIA_CHAT_CREATED.format(
                name=user.name, format=format_
            )
        )

    def _build_messages_type_5(self, user_ids, message):
        return self.__build_message(
            user_ids,
            MessageFormater.TYPE_TASK_CREATED.format(
                name=message['body']['operator']['name']
            )
        )

    def _build_messages_type_47(self, user_ids, message):
        return self.__build_message(
            user_ids,
            MessageFormater.TYPE_TASK_COMPLETED.format(
                name=message['body']['operator']['name']
            )
        )

    def _build_messages_type_4(self, user_ids, message):
        return self.__build_message(
            user_ids,
            MessageFormater.TYPE_MAIL_CREATED.format(
                name=message['body']['email']['meta']['from_detail']['value']['name'])
        )

    def __build_message(self, user_ids, alert):
        if not user_ids:
            return []

        user_devices = UserDevice.objects \
            .filter(user_id__in=user_ids)

        messages = []
        for user_device in user_devices:
            if not self._should_build_message(user_device):
                continue

            messages.append(Message(
                [user_device.device_token],
                sound='StarfishNews.caf',
                # sound='default',
                alert=alert,
                badge=self._calc_badge(user_device.user_id)))

            log.info('build message, token=%s', user_device.device_token)

        return messages

    def _send_message(self, message):
        conn = self.session.new_connection(
            os.environ['IOS_PUSH_ENV'], cert_file=self._get_cert())

        res = None
        for i in range(self.RETRIES):
            try:
                res = APNs(conn).send(message)
                break
            except (OpenSSL.SSL.SysCallError, OpenSSL.SSL.SysCallError):
                if i == self.RETRIES - 1:
                    raise

        for token, reason in res.failed.items():
            code, errmsg = reason
            log.warning("device failed: %s, reason: %s", token, errmsg)
            # UserDevice.find_by_device_token(token).delete()

    def _calc_badge(self, user_id):
        return User.all_unread_count(user_id)['total']


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    utils.register_to_zk_or_wait(
        '%s.%s' % (__file__, os.environ['IOS_PUSH_ENV']), settings.ZK_HOSTS)

    # endpoints = utils.MaxwellEndpoint.endpoints(0)

    BackendSubscriber(
        MaxwellEndpointUtil.get('maxwell_message_pub'),
        # endpoints['maxwell_message_pub'],
        SimpleListener()
    ).start()
