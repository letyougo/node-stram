import os
os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

from datetime import datetime

# do not remove
from django.conf import settings
settings.DATABASES

from apps.message.models import UserMessage, Message, MessageContent

from common.utils import shard_id

(user_id,
 peer_id,
 peer_type) = (13, 2, 0)

org_id = 1


def format_msg(m):
    c = MessageContent.objects.using(shard_id(org_id)).get_or_none(id=m.content)
    return (m.id, datetime.fromtimestamp(m.date_added).strftime('%Y-%m-%d %H:%M:%S'), c.content)

r = UserMessage.objects \
    .using(shard_id(org_id)) \
    .filter(user_id=user_id) \
    .filter(peer_type=peer_type, peer_id=peer_id) \
    .filter(status=0)

qs = Message.objects \
    .using(shard_id(org_id)) \
    .filter(id__in=[i.message_id for i in r])
for m in qs:
    print(format_msg(m))
