#!/usr/bin/env python
import os

os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import json
import signal
import time
import utils

from django.db import connections

from apps.message.models import Message
from apps.message.utils import UserMessageUtils
from apps.search import send_index_cmd

from common.message_queue import MessageConsumerMultiProcess
from common.utils import shard_id, ProcessExister

from log import config_logging
config_logging(filename='/mnt1/logs/starfish-save-user-message-worker.log')

import logging
log = logging.getLogger(__name__)


class SaveUserMessageConsumer(MessageConsumerMultiProcess):
    def consume(self, message):
        data = json.loads(message)
        org_id = data['scope_org_id']
        db = shard_id(org_id)

        if db not in settings.DATABASES:
            return

        m_obj = Message.objects.using(db).get_or_none(id=data['id'])
        if not m_obj or m_obj.is_sent != 0:
            return

        res = UserMessageUtils.save_user_message(m_obj,
                                                 session_id=data.get('session_id'),
                                                 user_message_meta=data.get('user_message_meta'))

        m_obj.is_sent = 1
        m_obj.save(using=db)

        if res:
            send_index_cmd(Message, m_obj.id, org_id, True)

        connections[shard_id(org_id)].close()

    def _get_name(self):
        return str(__file__)

if __name__ == '__main__':
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    utils.register_to_zk_or_wait(__file__, settings.ZK_HOSTS)

    consumer = SaveUserMessageConsumer(
        conf={
            'url': settings.KAFKA_URL,
        },
        queue=settings.STARFISH_SAVE_USER_MESSAGE_QUEUE_NAME
    )

    p = ProcessExister(consumer.stop, signal.SIGTERM, signal.SIGINT, signal.SIGHUP)
    consumer.start()

    while p.is_running:
        time.sleep(1)
