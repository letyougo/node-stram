#!/usr/bin/env python
import os

os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import time
import json
import signal
import utils

from datetime import datetime, timedelta
from django.db.models import IntegerField, DateField, get_model
from django.core.cache import cache as memcache

from common.utils import current_timestamp
from common.message_queue import MessageConsumerBase
from common.models import AutoCleanMixin
from django.db import connections
from log import config_logging
config_logging(filename='/mnt1/logs/starfish-auto-clean-tables.log')

import logging
log = logging.getLogger(__name__)


class MessageConsumer(MessageConsumerBase):
    def consume(self, message):
        data = json.loads(message)
        model = get_model(data['label'], data['model'])
        db = data.get('using')

        if not model or not db or AutoCleanMixin not in model.__bases__:
            return

        key = '%s_%s_%s' % (model.AUTO_CLEAN_CACHE_PREFIX, db, model.__name__)
        if memcache.get(key):
            return

        field, seconds = model.auto_clean_setting
        before = None
        for f in model._meta.local_fields:
            if f.attname == field:
                if isinstance(f, IntegerField):
                    before = current_timestamp() - seconds
                elif isinstance(f, DateField):
                    before = datetime.now() - timedelta(seconds=seconds)

        if before is None:
            log.error('wrong type of field in %s.auto_clean_setting = %s'
                      % (model.__name__, field))
            return

        to_be_deleted = model.objects\
            .using(db)\
            .filter(**{'%s__lt' % field: before})

        log.info('auto_clean_trigger: %s, before=%s, deleted count=%s, deleted=%s'
                 % (model.__name__, before,
                    to_be_deleted.count(), to_be_deleted.values_list('id', flat=True)))

        to_be_deleted.delete()
        memcache.set(key, datetime.now(), model.AUTO_CLEAN_INTERVAL)
        connections[db].close()

    def _get_name(self):
        return str(__file__)

if __name__ == '__main__':
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    utils.register_to_zk_or_wait(__file__, settings.ZK_HOSTS)

    MessageConsumer(
        conf={
            'url': settings.KAFKA_URL,
        },
        queue=settings.STARFISH_AUTO_CLEAN_TABLES_QUEUE_NAME
    ).start()

    while True:
        time.sleep(1)
