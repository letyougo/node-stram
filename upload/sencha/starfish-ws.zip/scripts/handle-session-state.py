#!/usr/bin/env python
import os

os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import json
import signal
import utils

from lifebookv2 import (
    Subscriber, Listener as ListenerBase)
from lifebookv2.lifebook_protocol_subscriber_publisher_structs_pb2 import SESSION_CREATED, SESSION_DELETED, SESSION_RESET

from apps.org.models import UserOrg
from apps.message.models import Message

from common.utils import current_timestamp
from common.const import SrcType, DestType
from common.maxwell_utils import MaxwellSenderUtil, LifebookUtil, MaxwellEndpointUtil

from log import config_logging
config_logging(filename='/mnt1/logs/starfish-handle-session-state.log')

import logging
log = logging.getLogger(__name__)


class Listener(ListenerBase):
    CONNECTION_LOST_MESSAGE = 'connection terminated due to client idle limit reached'

    def __init__(self, lifebook):
        self.lifebook = lifebook

    def on_success(self, event):
        # log.info('got event, type=%s, user_id=%s', event.type, event.user_id)

        try:
            return self._on_success0(event)
        except Exception as e:
            if str(e).find(self.CONNECTION_LOST_MESSAGE) < 0:
                log.exception(e)

            os._exit(1)

    def on_failure(self, errcode, errmsg):
        log.error('on_failure: %s', errmsg)
        os._exit(1)

    def on_timeout(self):
        # log.error('on_timeout')
        os._exit(2)

    def _on_success0(self, event):
        _type, user_id, session, agent = event.type, event.user_id, event.session, event.agent
        if _type not in [SESSION_CREATED, SESSION_RESET, SESSION_DELETED] or not session:
            return

        org_ids = UserOrg.objects \
            .filter(user_id=user_id) \
            .filter(is_left=0) \
            .values_list('org_id', flat=True)

        msg_type = Message.TYPE_USER_ONLINE if (_type == SESSION_CREATED or _type == SESSION_RESET)\
            else Message.TYPE_USER_OFFLINE

        if not org_ids:
            return

        user_ids = UserOrg.objects \
            .filter(org_id__in=org_ids) \
            .filter(is_left=0) \
            .values_list('user_id', flat=True)
        user_ids = list(set(user_ids))

        log.info('send message, event_type=%s, msg_type=%s, user_id=%s, agent_type=%s' % (_type, msg_type, user_id, agent.type))
        agent_data = dict(key=agent.key, type=agent.type, desc=agent.desc.decode('utf8'))
        online = len(self.lifebook.find_sessions_by_user(user_id))

        MaxwellSenderUtil.send(
            id=user_id,
            user_ids=user_ids,
            payload=self._build_payload(user_id, msg_type,
                                        online_agents_count=online,
                                        agent=agent_data).encode('utf8'),
            date_added=current_timestamp())

    def _build_payload(self, user_id, msg_type, **kwargs):
        return json.dumps({
            'id': user_id,
            'src_id': 0,
            'src_type': SrcType.SYSTEM,
            'dest_type': DestType.ORG,
            'dest_id': 0,
            'type': msg_type,
            'body': dict(user_id=user_id, **kwargs)
        })


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    utils.register_to_zk_or_wait(__file__, settings.ZK_HOSTS)

    # endpoints = utils.MaxwellEndpoint.endpoints(0)
    # sender = Sender(endpoints['maxwell_backend'])
    # lifebook = Lifebook(endpoints['lifebook_cmd'])

    lifebook = LifebookUtil.instance()

    Subscriber(
        MaxwellEndpointUtil.get('lifebook_sub'),
        # endpoints['lifebook_sub'],
        Listener(lifebook)
    ).start()
