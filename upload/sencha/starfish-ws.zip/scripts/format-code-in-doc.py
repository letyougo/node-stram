#!/bin/env python3
import json
import sys


class Counter(object):
    count = 0


# 要大批量更新文档的某些数据，使用该方法去批处理
def handle(j):
    return
    if isinstance(j, dict):
        for k, v in dict(j).items():
            if k in ['creator', 'person_in_charge', 'assignee']:
                Counter.count += 1
                print(Counter.count, k, '=', type(v))
                # if type(v) == dict:
                #     j['%s_info' % k] = v
                #     j[k] = v['id']
                # if type(v) == int:
                #     j[k] = {"avatar": "...", "id": v or 1, "name": "Steve"}
            else:
                handle(v)
    elif isinstance(j, list):
        for i in j:
            handle(i)


def format_code(c):
    if c[0].startswith('{') or c[0].startswith('['):
        return format_code0(c)

    return c


def format_code0(c):
    s = ''.join([i.strip() for i in c])
    j = json.loads(s)

    handle(j)
    return json.dumps(
        j,
        sort_keys=True,
        indent=2).split("\n")


def format(f):
    output, content = [], None
    with open(f, encoding='utf8') as f:
        content = f.read()

    codes, code_start = [], False
    for i, line in enumerate(content.split("\n")):
        print(i, line)
        if line.startswith("```javascript"):
            output.append(line)
            code_start = True
            continue

        if code_start:
            if line.startswith("```"):
                output.extend(format_code(codes))
                output.append("```")
                codes, code_start = [], False
            else:
                codes.append(line.strip())
        else:
            output.append(line)

    return '\n'.join(output)


def edit(f):
    output = []

    with open(f, encoding='utf8') as f:
        content = f.read()

    title = None
    for i, line in enumerate(content.split("\n")):
        res = line

        prefix = line.strip()
        if prefix.startswith('##'):
            title = prefix[2:].strip()

        if prefix.startswith("GET") or prefix.startswith("POST") or prefix.startswith("PATCH") or prefix.startswith("DELETE"):
            orgs = line.split('/')[1:]
            if len(orgs) >= 2 and orgs[0] == 'orgs' and orgs[1] == ':org_id':
                res = 'ORG API: %s' % line
                print('...', i, title, res)
            else:
                res = 'NORMAL API: %s' % line
                print('xxxx', i, title, res)

        output.append(res)

    return '\n'.join(output)


if __name__ == '__main__':
    # s = edit(sys.argv[1]).strip()
    s = format(sys.argv[1]).strip()
    if len(sys.argv) > 2:
        with open(sys.argv[2], mode='w', encoding='utf8') as f:
            f.write('%s\n' % s)
    else:
        print(s)
