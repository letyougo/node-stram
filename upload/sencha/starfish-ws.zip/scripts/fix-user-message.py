#!/usr/bin/env python
import os

os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import time
import signal
import threading
import utils

from django.db import connections
from apps.search import send_index_cmd
from apps.org.models import Org
from apps.message.models import Message
from apps.message.utils import UserMessageUtils

from common.utils import shard_id, current_timestamp, all_orgs

from log import config_logging
config_logging(filename='/mnt1/logs/starfish-fix-user-message.log')

import logging
log = logging.getLogger(__name__)


class Main(threading.Thread):

    MSG_PAGE_SIZE = 128

    ORG_PAGE_SIZE = 64

    def run(self):
        try:
            self._run0()
        except Exception as e:
            log.exception(e)
            os._exit(1)

    def _run0(self):
        while True:
            self._run1()
            time.sleep(300)

    def _run1(self):
        start_org_id = 0
        while True:
            org_ids = all_orgs() \
                .filter(id__gt=start_org_id) \
                .order_by('id') \
                .values_list('id', flat=True)[:self.ORG_PAGE_SIZE]
            if not org_ids:
                break

            org_ids = list(org_ids)
            start_org_id = org_ids[-1]

            self._run2(org_ids)

    def _run2(self, org_ids):
        for org_id in org_ids:
            messages = Message.objects \
                .using(shard_id(org_id)) \
                .filter(is_sent=0) \
                .filter(date_added__lt=current_timestamp() - 100) \
                .order_by('id')[:self.MSG_PAGE_SIZE]

            db_name = shard_id(org_id)
            for message in messages:
                log.info('fix user message: %s@%s', message.id, db_name)

                res = UserMessageUtils.save_user_message(message)

                message.is_sent = 1
                message.save(using=message._state.db)
                if res:
                    send_index_cmd(Message, message.id, org_id, True)

            connections[db_name].close()

            time.sleep(1)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    utils.register_to_zk_or_wait(__file__, settings.ZK_HOSTS)

    Main().run()
