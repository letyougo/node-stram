import threading
from django.core.management import BaseCommand

import logging
import math
from django.db import connections
import time
from apps.account.models import User
from apps.message.models import Message
from apps.org.models import Org, UserOrg, DiscussionGroup, Department
from apps.project.models import Task
from apps.search.utils import SearchType, MessageIndexWorker, IndexObject
from common.thread_pool import WorkerManager
from common.utils import shard_id, all_orgs

from log import config_logging

config_logging(filename='/mnt1/logs/starfish-rebuild-index.log')

logging.getLogger("elasticsearch").setLevel(logging.ERROR)
logging.getLogger("urllib3.util.retry").setLevel(logging.ERROR)
logging.getLogger("urllib3.connectionpool").setLevel(logging.ERROR)

log = logging.getLogger(__name__)


class Command(BaseCommand):
    MESSAGE_STEP_COUNT = 5000

    def build_index(self, model, pk, org_id):
        self.indexer.create_index(model, pk, org_id)
        log.info('build_index: model: %s, pk: %s, org_id: %s, cost: %s'
                 % (model.__name__, pk, org_id, self.indexer.timer_catch(org_id)))

    def bulk_index(self, queryset, org_id):
        self.indexer.timer_start(threading.get_ident())
        self.indexer.bulk_create_index(queryset, org_id)
        log.info('build_index: model: %s, qs count: %s, org_id: %s, cost: %s'
                 % (queryset.model.__name__, queryset.count(), org_id,
                    self.indexer.timer_stop(threading.get_ident())))
        # for obj in queryset:
        #     self.indexer.create_index_by_obj(obj, org_id)
        #     log.info('build_index: model: %s, pk: %s, org_id: %s, cost: %s'
        #              % (queryset.model.__name__, obj.id, org_id,
        #                 self.indexer.timer_catch(org_id)))

    def multi_thread_index_message(self, org_id, limit, thread_count, step):
        msg_queryset = Message.objects.using(shard_id(org_id)) \
            .filter(type__in=MessageIndexWorker.index_msg_types) \
            .order_by('-id')
        ids_queryset = msg_queryset.values_list('id', flat=True)

        total = ids_queryset.count()
        if total is 0:
            log.info('multi_thread_index: no message for org: %s' % org_id)
            return
        if limit and limit < total:
            total = limit
        max_id = ids_queryset[0]
        min_id = ids_queryset[total - 1]

        # 限制住新加的message，只做max_id之前的index
        limited_qs = ids_queryset.filter(id__lte=max_id)

        slice_ids = [max_id]
        for i in range(1, math.ceil(total / step)):
            slice_ids.append(limited_qs[i * step])
        slice_ids.append(min_id)

        wm = WorkerManager(thread_count, 1, 'rebuild-index', False)
        for i in range(len(slice_ids) - 1):
            qs = msg_queryset.filter(id__lte=slice_ids[i], id__gt=slice_ids[i + 1])
            wm.add_job(self.bulk_index, i,
                       org_id=org_id,
                       queryset=qs)

        log.info(
            'multi_thread_index: thread_count: %s, step: %s, total: %s, cost: %s, slice: %s, %s'
            % (thread_count, step, total,
               self.indexer.timer_catch(org_id),
               len(slice_ids) - 1, slice_ids))
        wm.start()
        wm.wait_for_complete()

    def _args(self, *args):
        org_id = None
        search_type = None
        thread_count = 2
        limit = None
        step = self.MESSAGE_STEP_COUNT
        delete = 1
        mapping = 0
        for i in args:
            k, v = i.split('=')
            if k.strip() == 'org':
                org_id = int(v)
            elif k.strip() == 'type':
                search_type = int(v)
            elif k.strip() == 'threads':
                thread_count = int(v)
            elif k.strip() == 'limit':
                limit = int(v)
            elif k.strip() == 'step':
                step = int(v)
            elif k.strip() == 'delete':
                delete = int(v)
            elif k.strip() == 'mapping':
                mapping = int(v)
        if org_id is None or search_type is None:
            print('org, type is necessary!\n'
                  'ARGS: \n'
                  'org=0 (0 for all), \n'
                  'type=0 (1:MESSAGE, 100:CONTACT, 101:USER, 102:DISCUSS_GROUP, 103:DEPARTMENT, 200:TASK, 0:all), \n'
                  'threads=1 (thread pool count, default 1),\n'
                  'limit=0 (index limit to recent messages count),\n'
                  'step=5000 (execute count per thread),\n'
                  'delete=1 (delete index & type before rebuild),\n'
                  'mapping=0 (put mapping before rebuild)\n')
        return org_id, search_type, thread_count, limit, step, delete, mapping

    def set_mapping(self, org_id, doc_type, add_users=False, add_projects=False):
        properties = {
            "id": {
                "type": "long"
            },
            "name": {
                "type": "string",
                "analyzer": "standard"
            }
        }
        if add_users:
            properties['users'] = {'type': 'string', 'index': 'not_analyzed'}
        if add_projects:
            properties['projects'] = {'type': 'string', 'index': 'not_analyzed'}

        body = {
            doc_type: {
                "properties": properties
            }
        }
        try:
            self.es.indices.delete_mapping(index=str(org_id), doc_type=doc_type)
            self.es.indices.put_mapping(doc_type, body, index=str(org_id))
        except Exception as e:
            log.error('set_mapping, error: org:%s, doc_type:%s, %s' % (org_id, doc_type, e))

    def delete_index_type(self, org_id, doc_type):
        try:
            q = {'query': {'match_all': {}}}
            self.es.delete_by_query(str(org_id), doc_type, body=q)
        except Exception as e:
            log.error('delete_index_type, error: org:%s, doc_type:%s, %s' % (org_id, doc_type, e))

    def handle(self, *args, **options):
        org_id, search_type, thread_count, limit, step, delete, mapping = self._args(*args)
        if org_id is None or search_type is None:
            return

        self.indexer = IndexObject()
        self.es = self.indexer.es

        orgs = all_orgs().order_by('id')
        if org_id:
            orgs = orgs.filter(id=org_id)

        for org_id in orgs.values_list('id', flat=True):
            self.indexer.timer_start(org_id)
            log.info('rebuild-index START for org: %s' % org_id)

            # MESSAGE
            if search_type == SearchType.MESSAGE or search_type == 0:
                # if delete:
                #     self.delete_index_type(org_id, 'Message')
                if thread_count == 1:
                    objs = Message.objects.using(shard_id(org_id)) \
                        .filter(type__in=MessageIndexWorker.index_msg_types) \
                        .order_by('-id')
                    if limit:
                        objs = objs[:limit]
                    for pk in objs.values_list('id', flat=True):
                        self.build_index(Message, pk, org_id)
                elif thread_count > 1:
                    self.multi_thread_index_message(org_id, limit, thread_count, step)

            #  CONTACT
            if search_type in [0, SearchType.CONTACT, SearchType.ORG_MEMBER]:
                if delete:
                    self.delete_index_type(org_id, 'User')
                if mapping:
                    self.set_mapping(org_id, 'User', add_projects=True)
                objs = UserOrg.objects.filter(org_id=org_id, is_left=0)
                for pk in objs.values_list('user_id', flat=True):
                    self.build_index(User, pk, org_id)

            if search_type in [0, SearchType.CONTACT, SearchType.DISCUSS_GROUP]:
                if delete:
                    self.delete_index_type(org_id, 'DiscussionGroup')
                if mapping:
                    self.set_mapping(org_id, 'DiscussionGroup', add_users=True)
                objs = DiscussionGroup.objects.using(org_id).filter(is_disbanded=0)
                for pk in objs.values_list('id', flat=True):
                    self.build_index(DiscussionGroup, pk, org_id)

            if search_type in [0, SearchType.CONTACT, SearchType.DEPARTMENT]:
                if delete:
                    self.delete_index_type(org_id, 'Department')
                if mapping:
                    self.set_mapping(org_id, 'Department')
                objs = Department.objects.using(org_id).filter(is_disbanded=0)
                for pk in objs.values_list('id', flat=True):
                    self.build_index(Department, pk, org_id)

            if search_type == SearchType.TASK:
                if delete:
                    self.delete_index_type(org_id, 'Task')

                objs = Task.objects.using(org_id)
                for pk in objs.values_list('id', flat=True):
                    self.build_index(Task, pk, org_id)

            log.info('rebuild-index FINISH for org: %s, cost: %s, db_cost: %s s, es_cost: %s s'
                     % (org_id,
                        self.indexer.timer_stop(org_id),
                        self.indexer.db_cost,
                        self.indexer.es_cost))

            connections[shard_id(org_id)].close()
            time.sleep(1)
