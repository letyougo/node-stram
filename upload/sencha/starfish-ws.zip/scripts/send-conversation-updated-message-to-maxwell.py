#!/usr/bin/env python
import os

os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import json
import signal
import time
import simpleflake
import maxwell
import utils

from apps.message.models import Message, UserConversation
from common.message_queue import MessageConsumerBase
from common.const import SrcType, DestType
from common.utils import shard_id, current_timestamp, TargetObject
from common.maxwell_utils import MaxwellSenderUtil, LifebookUtil

from log import config_logging
config_logging(filename='/mnt1/logs/starfish-send-conversation-updated-message-to-maxwell.log')

import logging
log = logging.getLogger(__name__)


class MessageConsumer(MessageConsumerBase):
    def __init__(self, *args, **kwargs):
        super(MessageConsumer, self).__init__(*args, **kwargs)

        self._init_sender_and_lifebook()

    def consume(self, data):
        data = json.loads(data)
        log.info('got conversation updated message: %s', data)

        retries = 5
        for i in range(retries):
            try:
                self._consume1(data)
                break
            except Exception as e:
                log.warning('consume message: %s fail.', data)
                if i == retries - 1:
                    log.exception(e)
                    os._exit(1)

                self._init_sender_and_lifebook()

        log.info('done process conversation updated message: %s', data)

    def _consume1(self, data):
        conversation = UserConversation.objects \
            .using(shard_id(data['scope_org_id'])) \
            .get_or_none(id=data['conversation_id'])
        if not conversation:
            log.warning('conversation %s is none.', data['conversation_id'])
            return

        id_ = simpleflake.simpleflake()
        _kwargs = {
            'id': id_,
            'src_type': SrcType.SYSTEM,
            'src_id': 0,
            'dest_type': DestType.ORG_MEMBER,
            'dest_id': conversation.user_id,
            'type': Message.TYPE_CONVERSATION_UPDATED,
            'scope_org_id': data['scope_org_id'],
            'body': {
                'conversation': conversation.to_dict(data.get('last_message_id', None))
            }
        }
        _kwargs = TargetObject().update(shard_id(data['scope_org_id']), **_kwargs)
        payload = json.dumps(_kwargs).encode('utf8')

        log.info(
            'conversation updated: payload.id=%s, id=%s, user_id=%s, unread_count=%s',
            id_, conversation.id, conversation.user_id, conversation.unread_count
        )

        MaxwellSenderUtil.send(
            id=simpleflake.simpleflake(),
            user_ids=[conversation.user_id],
            payload=payload,
            excl_agent_ids_per_users=self._build_excl_agent_ids_per_users(data.get('session_id')),
            date_added=current_timestamp()
        )

    def _init_sender_and_lifebook(self):
        # endpoints = MaxwellEndpoint.endpoints(0)
        # self.sender = Sender(endpoints['maxwell_backend'])
        # self.lifebook = Lifebook(endpoints['lifebook_cmd'])

        self.lifebook = LifebookUtil.instance()

    def _build_excl_agent_ids_per_users(self, session_id):
        if not session_id:
            return []

        user_id, session_key = session_id.split(':')
        user_id = int(user_id)
        agent_key, _, _ = self.lifebook.find_session(user_id, session_key)
        if not agent_key:
            return []

        return [
            maxwell.maxwell_protocol_sender_receiver_structs_pb2.agent_ids_per_user_t(
                user_id=user_id, agent_keys=[agent_key])
        ]

    def _get_name(self):
        return str(__file__)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    utils.register_to_zk_or_wait(__file__, settings.ZK_HOSTS)

    MessageConsumer(
        conf={
            'url': settings.KAFKA_URL
        },
        queue=settings.STARFISH_CONVERSATION_UPDATED_MESSAGE_QUEUE_NAME
    ).start()

    while True:
        time.sleep(1)
