import os
import sys
import psycopg2
import psycopg2.extras


excluded = (
    1,    # 比特兄弟
    2,    # 比特兄弟测试
    124,  # 比特兄弟测试2
    144,  # 中矿龙科
)

creators = (
    7,    # 宋航
    9,    # 王立强
    67,   # 缪正伟
    90,   # Niliang
    91,   # Niliang
    135,  # 测试账号
    136,  # 测试账号
    140,  # 杨爱学_测试
    174,  # 大白
    182,  # 测试账号
    184,  # 测试账号
    187,  # 测试账号
)
select_orgs = """
select * from uc_org where creator in (%s) and id not in (%s)
""" % (
    ','.join([str(i) for i in creators]),
    ','.join([str(i) for i in excluded]),
)

delete_user_org = """
delete from uc_user_org where org_id in (%s)
"""

delete_org_domain = """
delete from uc_org_domain where org_id in (%s)
"""

delete_user_last_org = """
delete from uc_user_last_org where org_id in (%s)
"""

delete_invitation = """
delete from uc_invitation where org_id in (%s)
"""

delete_org = """
delete from uc_org where id in (%s)
"""

drop_database = """
psql -Umos postgres -c "drop database starfish_prod_org_%08d"
"""

reset_org_serial = """
SELECT setval('uc_org_id_seq', (SELECT MAX(id) FROM uc_org));
"""

rebuild_org_db = """
bash /opt/mos/codebase/starfish-ws/scripts/create-new-org-db.sh %s %s in-102-bj ;
"""

conn_string = \
    "host='in-102-bj' dbname='starfish_prod_main' user='mos' password='mos517nrm'"
conn = psycopg2.connect(conn_string)


def exec_sql(c, sql):
    print('### run query: %s' % sql.strip())
    c.execute(sql)


cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
cursor.execute(select_orgs)
org_ids = []
for i in cursor.fetchall():
    org_ids.append(i['id'])

    print("### id=%s, creator=%s, name=%s" % (i['id'], i['creator'], i['name']))
    if len(sys.argv) != 2 or sys.argv[1].strip() != '~run':
        continue

    print(drop_database % i['id'])
    print(rebuild_org_db % (i['id'], i['id']))

if len(sys.argv) != 2 or sys.argv[1].strip() != '~run':
    os._exit(1)

org_ids_str = ','.join([str(i) for i in org_ids])
exec_sql(cursor, delete_user_org % org_ids_str)
exec_sql(cursor, delete_org_domain % org_ids_str)
exec_sql(cursor, delete_user_last_org % org_ids_str)
exec_sql(cursor, delete_invitation % org_ids_str)

exec_sql(cursor, delete_org % org_ids_str)


conn.commit()
conn.close()

conn = psycopg2.connect(conn_string)
cursor = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
exec_sql(cursor, reset_org_serial)
conn.commit()
conn.close()
