#!/usr/bin/env python
import os
import signal

os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import time
from threading import Thread
from common.sync import RabbitMqUtils
from apps.message.models import Message
from common.const import SrcType, DestType
from common.utils import shard_id, TargetObject, current_timestamp
from django.core.cache import cache as memcache
from common import Singleton

import utils
from log import config_logging
config_logging(filename='/mnt1/logs/starfish-receive-sip-message.log')

import logging
log = logging.getLogger(__name__)


class VoiceCallUtil(object, metaclass=Singleton):
    TIMER_CACHE_PREFIX = 'voice_call_id_timer'
    DATA_CACHE_PREFIX = 'voice_call_id_data'
    OPERATION_CACHE_PREFIX = 'voice_call_id_operation'
    MAX_VOICE_LENGTH = 3600 * 4

    def timer_key(self, call_id):
        return '%s::%s' % (self.TIMER_CACHE_PREFIX, str(call_id))

    def data_key(self, call_id):
        return '%s::%s' % (self.DATA_CACHE_PREFIX, str(call_id))

    def start_voice_call(self, call_id):
        memcache.set(self.timer_key(call_id), current_timestamp(), self.MAX_VOICE_LENGTH)

    def end_voice_call(self, call_id):
        key = self.timer_key(call_id)
        start = memcache.get(key)
        if start is None:
            return 0
        else:
            memcache.delete(key)
            return current_timestamp() - int(start)

    def regist_invite_data(self, call_id, uri):
        memcache.set(self.data_key(call_id), self.__get_params(uri), self.MAX_VOICE_LENGTH)

    def get_data_by_call_id(self, call_id, key):
        data = memcache.get(self.data_key(call_id))
        if data:
            return data.get(key)

    def __get_params(self, uri):
        data = {}
        for s in uri.split(';'):
            if '=' in s:
                k, v = tuple(s.split('='))
                data[k] = v
        return data

    def set_operation_event(self, call_id, operation, reply_status=''):
        '''return True if operation of call_id is set first time, otherwise False
            expired in 10 min
        '''
        key = '%s::%s::%s::%s' \
              % (self.OPERATION_CACHE_PREFIX, str(call_id), operation, str(reply_status))
        return memcache.add(key, 1, timeout=60*10)


class MessageReceiver(Thread):
    def __init__(self, queue, *args, **kwargs):
        super(MessageReceiver, self).__init__(daemon=False, *args, **kwargs)
        self.queue = queue

    def handle(self, data):
        operation = data['operation']
        from_id, to_id = int(data['from']), int(data['to'])
        # cseq = data['cseq']
        call_id = data['call_id']

        if not VoiceCallUtil()\
                .set_operation_event(call_id, operation, data.get('reply_status', '')):
            log.info('skip deplicated even, call_id: %s, operation: %s' % (call_id, operation))
            return

        duration = None
        if operation == 'INVITE':
            optype = data['type']
            if optype == 'request':
               VoiceCallUtil().regist_invite_data(call_id, data['request_original_uri'])
               return
            elif optype == 'response':
                reply_status = int(data['reply_status'])
                if reply_status == 603:
                    from_id, to_id = to_id, from_id
                    operation = 'DENY'
                elif reply_status == 200:
                    VoiceCallUtil().start_voice_call(call_id)
                else:
                    return
        elif operation == 'CANCEL':
            pass
        elif operation == 'REPLY':
            reply_status = data['reply_status']
            if reply_status == 603:
                operation = 'DENY'
            else:
                return
        elif operation == 'BYE':
            duration = VoiceCallUtil().end_voice_call(call_id)
        #elif operation == 'ACK':
        #    VoiceCallUtil().start_voice_call(call_id)
        #    return
        else:
            return

        org_id = VoiceCallUtil().get_data_by_call_id(call_id, 'orgID')
        if not org_id:
            log.error('can not get orgID by call_id: %s, operation: %s' % (call_id, operation))
            return

        content = TargetObject() \
            .update(shard_id(org_id),
                    src_type=SrcType.ORG_MEMBER,
                    src_id=from_id,
                    dest_type=DestType.ORG_MEMBER,
                    dest_id=to_id,
                    operation=operation)
        if duration is not None:
            content.update(duration=duration)

        message = Message(
            src_type=SrcType.ORG_MEMBER,
            src_id=from_id,
            dest_type=DestType.ORG_MEMBER,
            dest_id=to_id,
            type=Message.TYPE_VOICE_MESSAGE_UPDATED,
        )
        message.sendout(content, shard_id(org_id), True)

    def run(self):
        def _callback(ch, method, properties, body):
            'E_SIP_MESSAGE\nto::1004\nfrom::1000\ncseq::18156\ncall_id::2facc2961d4447ca964cd6d2a2b8d666\noperation::INVITE'
            try:
                data = dict(tuple(i.split('::')) for i in body.decode().split('\n')[1:])
                log.info("%s Received %s" % (self.queue, data))
                self.handle(data)
            except Exception as e:
                log.error('handle received data, queue %s, error: %s' % (self.queue, e))
                log.exception(e)

            ch.basic_ack(delivery_tag=method.delivery_tag)

        RabbitMqUtils(self.queue, **settings.RABBIT_MQ_CONF).receive(_callback)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    utils.register_to_zk_or_wait(__file__, settings.ZK_HOSTS)

    MessageReceiver('starfish_sip_event').start()

    time.sleep(10)
