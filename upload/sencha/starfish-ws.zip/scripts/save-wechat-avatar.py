#!/usr/bin/env python
import os
os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import json
import signal
import time
import requests
import shutil
import utils

from apps.account.models import User, UserAvatar
from common.utils import ensure_dir_exists, shard_id
from common.message_queue import MessageConsumerBase
from django.db import connections

from log import config_logging
config_logging(filename='/mnt1/logs/starfish-save-wechat-avatar.log')

import logging
log = logging.getLogger(__name__)


class MessageConsumer(MessageConsumerBase):
    def consume(self, message):
        data = json.loads(message)

        user = User.wechat_account(data['openid'])
        if not user:
            log.warning('no such bind user, openid: %s', data['openid'])
            return

        if user.avatar:
            log.info('user already has avatar, skip fetch wechat avatar.')
            return

        filepath = UserAvatar.gen_filepath()
        r = requests.get(data['headimgurl'], stream=True)
        if r.status_code != requests.codes.ok:
            log.error('fetch wechat avatar fail: %s', r.reason)

        ensure_dir_exists(UserAvatar.full_path(filepath))
        with open(UserAvatar.full_path(filepath), 'wb') as f:
            r.raw.decode_content = True
            shutil.copyfileobj(r.raw, f)

        user.avatar = filepath
        user.save()

        connections[shard_id()].close()

    def _get_name(self):
        return str(__file__)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    utils.register_to_zk_or_wait(__file__, settings.ZK_HOSTS)

    MessageConsumer(
        conf={
            'url': settings.KAFKA_URL
        },
        queue=settings.STARFISH_WECHAT_BIND_QUEUE_NAME
    ).start()

    while True:
        time.sleep(1)
