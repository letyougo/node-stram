#!/usr/bin/env python

import os
os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import time

from django.db import connections

from log import config_logging
config_logging(filename='/mnt1/logs/starfish-import-mail-to-starfish.log')

import logging
log = logging.getLogger(__name__)


def main():
    from apps.mail import utils

    while True:
        for f in os.listdir(settings.TMP_MAIL_DIR):
            if f.endswith('.fail'):
                continue

            filename = '%s/%s' % (settings.TMP_MAIL_DIR, f)
            try:
                with open(filename) as f:
                    utils.MailStorage(f.read()).save()
                # os.remove(filename)
                os.rename(filename, "%s.fail" % filename)
            except Exception as e:
                log.exception(e)
                os.rename(filename, "%s.fail" % filename)

        for alias in connections:
            connections[alias].close()

        time.sleep(5)

if __name__ == '__main__':
    import utils
    utils.register_to_zk_or_wait(__file__, settings.ZK_HOSTS)

    main()
