#!/usr/bin/env python
import os

os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import signal
import utils
from common.maxwell_utils import LifebookUtil, MaxwellEndpointUtil

from lifebookv2 import (
    Subscriber, Listener as ListenerBase)

from log import config_logging
config_logging(filename='/mnt1/logs/starfish-remove-expired-agents.log')

import logging
log = logging.getLogger(__name__)


class Listener(ListenerBase):

    MAX_AGENTS_PER_USER = 4

    def __init__(self):
        self.lifebook = None

    def on_success(self, event):
        log.info('got event, type=%s, user_id=%s', event.type, event.user_id)

        try:
            return self._on_success0(event.user_id)
        except Exception as e:
            log.exception(e)
            os._exit(1)

    def on_failure(self, errcode, errmsg):
        log.error('on_failure: %s', errmsg)
        os._exit(1)

    def on_timeout(self):
        os._exit(2)

    def _on_success0(self, user_id):
        log.info('remove user:%s\'s expired agents.', user_id)

        r = self._get_lifebook().find_agents_by_user(user_id)
        if len(r) < self.MAX_AGENTS_PER_USER:
            log.info('user:%s has %s agents, do not need to delete.', user_id, len(r))
            return

        r = list(sorted(r, key=lambda x: x.expired_at))[:len(r) - self.MAX_AGENTS_PER_USER]
        for i in r:
            log.info('remove agent: user_id=%s, agent_key=%s', user_id, i.key)
            self._get_lifebook().delete_agent(user_id, i.key)

    def _get_lifebook(self):
        if not self.lifebook:
            # endpoints = utils.MaxwellEndpoint.endpoints(0)
            # self.lifebook = Lifebook(endpoints['lifebook_cmd'])
            self.lifebook = LifebookUtil.instance()
        return self.lifebook


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    utils.register_to_zk_or_wait(__file__, settings.ZK_HOSTS)

    # endpoints = utils.MaxwellEndpoint.endpoints(0)

    Subscriber(
        MaxwellEndpointUtil.get('lifebook_sub'),
        # endpoints['lifebook_sub'],
        Listener()
    ).start()
