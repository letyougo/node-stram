#!/usr/bin/env python
import os

os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import json
import signal
import time
import utils

from common.message_queue import MessageConsumerBase

from apps.mail.models import MailMetadata
from apps.mail.utils import build_and_send_mail
from django.db import connections
from common.utils import shard_id

from log import config_logging
config_logging(filename='/mnt1/logs/starfish-mail-build-send.log')

import logging
log = logging.getLogger(__name__)


class MessageConsumer(MessageConsumerBase):
    def consume(self, message):
        data = json.loads(message)
        mail_metas = data.pop('mail_metas', None)
        mail_message = build_and_send_mail(**data).as_string()

        if mail_metas is None:
            log.error('send-mail-queue get a message without mail_metas')
        else:
            log.info('build and send mail, meta: %s', mail_metas)
            for org_id, mail_id in mail_metas.items():
                mail = MailMetadata.objects.using(org_id).get_or_none(id=mail_id)
                if mail:
                    mail.filepath = MailMetadata.save_file2(mail_message, org_id)
                    mail.save()
                else:
                    log.error('send-mail-queue get a message, missing mail %s:%s'
                              % (org_id, mail_id))

        connections[shard_id(org_id)].close()

    def _get_name(self):
        return str(__file__)

if __name__ == '__main__':
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    utils.register_to_zk_or_wait(__file__, settings.ZK_HOSTS)

    MessageConsumer(
        conf={
            'url': settings.KAFKA_URL,
        },
        queue=settings.STARFISH_EMAIL_QUEUE_NAME
    ).start()

    while True:
        time.sleep(1)
