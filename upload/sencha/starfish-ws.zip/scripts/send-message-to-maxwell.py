#!/usr/bin/env python
import os

os.environ['DJANGO_SETTINGS_MODULE'] = 'starfish.settings'

import sys
root_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, root_path)

# do not remove
from django.conf import settings
settings.DATABASES

import json
import signal
import time
import maxwell
import utils

from apps.acl.models import UserRole
from apps.message.models import Message
from common.utils import shard_id
from common.message_queue import MessageConsumerBase
from common.maxwell_utils import MaxwellSenderUtil, LifebookUtil

from log import config_logging
config_logging(filename='/mnt1/logs/starfish-send-message-to-maxwell.log')

import logging
log = logging.getLogger(__name__)


class MessageConsumer(MessageConsumerBase):
    def __init__(self, *args, **kwargs):
        super(MessageConsumer, self).__init__(*args, **kwargs)

        self._init_sender_and_lifebook()

        # 聊天内容再 conversation 消息中已经推送了
        self.skip_types = (
            Message.TYPE_TEXT_CHAT_CREATED,
            Message.TYPE_MULTIMEDIA_CHAT_CREATED,
            Message.TYPE_TASK_CREATED,
            Message.TYPE_TASK_COMPLETED,
            Message.TYPE_EMAIL_CREATED,
        )

    def consume(self, data):
        data = json.loads(data)
        log.info('got message: %s', self._message_summary(data))

        if data['type'] in self.skip_types:
            return

        retries = 5
        for i in range(retries):
            try:
                self._consume1(data)
                break
            except Exception as e:
                log.error('error occurred when consume message: %s', data)
                log.exception(e)

                if i == retries - 1:
                    os._exit(1)

                self._init_sender_and_lifebook()

    def _consume1(self, data):
        MaxwellSenderUtil.send(
            id=data['id'],
            user_ids=self._build_user_ids(data),
            payload=json.dumps(data).encode('utf8'),
            excl_agent_ids_per_users=self._build_excl_agent_ids_per_users(data['session_id']),
            date_added=data['date_added'])

    def _init_sender_and_lifebook(self):
        # endpoints = MaxwellEndpoint.endpoints(0)
        # self.sender = Sender(endpoints['maxwell_backend'])
        # self.lifebook = Lifebook(endpoints['lifebook_cmd'])

        self.lifebook = LifebookUtil.instance()

    def _build_excl_agent_ids_per_users(self, session_id):
        if not session_id:
            return []

        user_id, session_key = session_id.split(':')
        user_id = int(user_id)
        agent_key, _, _ = self.lifebook.find_session(user_id, session_key)
        if not agent_key:
            return []

        return [
            maxwell.maxwell_protocol_sender_receiver_structs_pb2.agent_ids_per_user_t(
                user_id=user_id, agent_keys=[agent_key])
        ]

    def _build_user_ids(self, data):
        from apps.org.models import UserDiscussionGroup, Department, UserOrg
        from common.const import DestType, SrcType

        org_id = data['scope_org_id']

        user_ids = []
        if data['dest_type'] == DestType.ORG_MEMBER:
            user_ids.append(data['dest_id'])
            if 'src_type' in data and 'src_id' in data \
                    and data['src_type'] == SrcType.ORG_MEMBER:
                user_ids.append(int(data['src_id']))
            user_ids = list(set(user_ids))
        elif data['dest_type'] == DestType.DISCUSSION_GROUP:
            if data['type'] == Message.TYPE_DISCUSSION_GROUP_DISBANDED:
                user_ids = UserDiscussionGroup.objects \
                    .using(shard_id(org_id)) \
                    .filter(group_id=data['dest_id'], is_left=0) \
                    .values_list('user_id', flat=True)
                user_ids = [i for i in user_ids]
            else:
                user_ids = UserDiscussionGroup.user_ids(org_id, data['dest_id'])
                user_ids = list(set(user_ids) | set(UserRole.user_list(org_id)))
        elif data['dest_type'] == DestType.DEPARTMENT:
            user_ids = Department.user_ids(org_id, data['dest_id'], filter_disbanded=False)

        elif data['dest_type'] == DestType.ORG:
            user_ids = UserOrg.objects \
                .filter(org_id=data['dest_id']) \
                .values_list('user_id', flat=True)
            user_ids = [i for i in user_ids]
        elif data['dest_type'] == DestType.USER_ORG:
            org_ids = UserOrg.objects \
                .filter(user_id=data['dest_id']) \
                .values_list('org_id', flat=True)

            if not org_ids:
                return []

            user_ids = UserOrg.objects \
                .filter(org_id__in=org_ids) \
                .filter(is_left=0) \
                .values_list('user_id', flat=True)
            user_ids = list(set(user_ids))
        else:
            raise ValueError('invalid dest type: %s' % data['dest_type'])

        return user_ids

    def _message_summary(self, data):
        body = data['body']
        if data['type'] == Message.TYPE_CONVERSATION_UPDATED:
            return {
                'id': data['id'],
                'type': 'TYPE_CONVERSATION_UPDATED',
                'conversation': {
                    'id': body['conversation']['id'],
                    'user_id': body['conversation']['user_id'],
                    'last_message_id': body['conversation']['last_message']['id']
                }
            }

        if data['type'] == Message.TYPE_EMAIL_CREATED:
            return {
                'id': data['id'],
                'type': 'TYPE_EMAIL_CREATED',
                'subject': body['email']['meta']['subject']
            }

        return dict((k, v) for k, v in data.items() if k != 'body')

    def _get_name(self):
        return str(__file__)


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, signal.SIG_DFL)
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    utils.register_to_zk_or_wait(__file__, settings.ZK_HOSTS)

    MessageConsumer(
        conf={
            'url': settings.KAFKA_URL
        },
        queue=settings.STARFISH_MESSAGE_QUEUE_NAME
    ).start()

    while True:
        time.sleep(1)
