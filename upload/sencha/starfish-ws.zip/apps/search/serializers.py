import logging
from rest_framework import serializers
from apps.account.models import User
from apps.message.models import Message, MessageContent, UserMessage
from apps.org.models import DiscussionGroup, UserDiscussionGroup, Department
from apps.project.models import Task
from apps.search import index_key
from common.serializers import BaseModelSerializer
log = logging.getLogger(__name__)


class BaseIndexSerializer(BaseModelSerializer):
    def __init__(self, *args, **kwargs):
        self.index_org_id = kwargs.pop('index_org_id', None)
        super(BaseIndexSerializer, self).__init__(*args, **kwargs)


class MessageIndexSerializer(BaseIndexSerializer):
    content = serializers.SerializerMethodField('get_content')
    users = serializers.SerializerMethodField('get_users')

    class Meta:
        model = Message
        fields = ('id', 'content', 'type', 'users', 'create_time', 'create_timestamp',
                  'src_type', 'src_id')

    def pre_fetch_cache(self, queryset, db):
        message_content_id_list = []
        message_id_list = []
        for mid, content_id in queryset.values_list('id', 'content'):
            message_id_list.append(mid)
            message_content_id_list.append(content_id)

        msg_content_qs = MessageContent.objects.using(db).filter(id__in=message_content_id_list)
        self.message_content_cache = dict((mc.id, mc) for mc in msg_content_qs)

        user_message_qs = UserMessage.objects.using(db)\
            .filter(message_id__in=message_id_list)\
            .exclude(status=Message.STATUS_IGNORE)

        self.user_message_cache = dict((mid, []) for mid in message_id_list)
        for um in user_message_qs:
            self.user_message_cache[um.message_id].append(um)

    def get_content(self, obj):
        msg_content = getattr(self, 'message_content_cache', {}).get(obj.content)
        if msg_content is None:
            msg_content = MessageContent.objects.using(obj._state.db).get_or_none(id=obj.content)

        if msg_content:
            if obj.type == Message.TYPE_TEXT_CHAT_CREATED:
                return msg_content.content['chat']['content']  # TextChat.content
            elif obj.type == Message.TYPE_MULTIMEDIA_CHAT_CREATED:
                return msg_content.content['chat']['name']  # MultimediaChat.meta.name
            elif obj.type in [Message.TYPE_TASK_CREATED, Message.TYPE_TASK_COMPLETED]:
                return msg_content.content['task']['subject']  # Task.subject
            elif obj.type == Message.TYPE_FILES_CREATED:
                if 'files' not in msg_content.content:
                    return ''

                return ' '.join([d['name'] for d in msg_content.content['files']])  # File.name

    def get_users(self, obj):
        um_list = getattr(self, 'user_message_cache', {}).get(obj.id)
        if um_list is None:
            um_list = UserMessage.objects\
                .using(obj._state.db)\
                .filter(message_id=obj.id)\
                .exclude(status=Message.STATUS_IGNORE)

        results = {}
        for um in um_list:
            results[index_key(um.user_id)] = {"user_message_id": um.id,
                                              "conversation_id": um.conversation.id,
                                              "peer_type": um.peer_type, "peer_id": um.peer_id}
        if not results:
            log.warning(
                'No users for Message: %s, '
                'type: %s, dest_type: %s, dest_id: %s, create_time: %s, db: %s'
                % (obj.id, obj.type, obj.dest_type, obj.dest_id, obj.create_time, obj._state.db))
        return results


class OrgMemberIndexSerializer(BaseIndexSerializer):
    projects = serializers.SerializerMethodField('get_projects')

    def get_projects(self, obj):
        from apps.project.models import Project
        if not self.index_org_id:
            raise ValueError('index_org_id should not be None')
        project_ids = [index_key(i) for i in Project.joined_projects(self.index_org_id, obj.id)]
        return project_ids

    class Meta:
        model = User
        fields = ('id', 'name', 'projects')


class DiscussionGroupIndexSerializer(BaseIndexSerializer):
    users = serializers.SerializerMethodField('get_users')

    class Meta:
        model = DiscussionGroup
        fields = ('id', 'name', 'users')

    def get_users(self, obj):
        user_ids = [index_key(i) for i in UserDiscussionGroup.user_ids(obj.org_id, obj.id)]
        if not user_ids:
            log.warning(
                'No users for DiscussionGroup: %s, db: %s', obj.id, obj._state.db)
        return user_ids


class DepartmentIndexSerializer(BaseIndexSerializer):
    class Meta:
        model = Department
        fields = ('id', 'name')


class TaskIndexSerializer(BaseIndexSerializer):
    tags = serializers.SerializerMethodField('get_tags')

    def get_tags(self, obj):
        return list(obj.tags.values_list('name', flat=True))

    class Meta:
        model = Task
        fields = ('id', 'subject', 'content', 'tags',
                  'assignee', 'project_id')
