from django.conf.urls import patterns, url
from apps.search import views

full_search = views.SearchViewSet.as_view({
    'get': 'search',
})

search_group_by_conversations = views.SearchConversationViewSet.as_view({
    'get': 'search',
})

search_project_members = views.SearchProjectInfo.as_view({
    'get': 'search_members',
})

search_project_tasks = views.SearchProjectInfo.as_view({
    'get': 'search_tasks',
})

urlpatterns = patterns(
    '',
    url(r'^v1/orgs/(?P<org_id>\d+)/search$', full_search, name='full-search'),
    url(r'^v1/orgs/(?P<org_id>\d+)/search/conversations$',
        search_group_by_conversations, name='search-group-by-conversations'),

    url(r'^v1/orgs/(?P<org_id>\d+)/search/project/members$',
        search_project_members, name='search-project-members'),

    url(r'^v1/orgs/(?P<org_id>\d+)/search/project/tasks$',
        search_project_tasks, name='search-project-tasks'),
)
