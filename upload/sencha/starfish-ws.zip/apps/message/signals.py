import json
from django.conf import settings

from django.db.models import F
from django.db.models.signals import post_save, pre_save
from django.db.models.signals import post_delete
from django.dispatch.dispatcher import receiver

from apps.message.models import (
    Message, UserMessage, UserConversation, UserMessageUnreadCount)
from common.globals import get_current_session_id
from common.message_queue import send_message_to_queue, SystemMessage

from common.utils import to_org_id, current_timestamp

import logging
log = logging.getLogger(__name__)


@receiver(post_save, sender=Message)
def send_message_on_message_saved(sender, instance, **kwargs):
    if not kwargs['created']:
        return
    content = instance._snapshot or Message._load_resource(instance)
    if content:
        instance.sendout(content)


# @receiver(pre_save, sender=UserMessage)
# def block_user_message_status_update_unexpected(sender, instance, **kwargs):
#     if instance.id is not None and instance.get_field_diff('status'):
#         raise RuntimeError('unexpected update usermessage status: %s, %s'
#                            % (instance.id, instance.status))


# @receiver(post_save, sender=UserMessage)
# def update_user_conversation_on_user_message_created(sender, instance, **kwargs):
#     if instance._state.db == 'default':
#         return
#
#     if not kwargs['created']:
#         return
#
#     add_unread_count = 0 if (instance.is_read or instance.is_ignored) else 1
#     conversation = UserConversation.find_by_usermessage(instance)
#
#     if not conversation:
#         # create if not exists
#         conversation, created = UserConversation.objects \
#             .using(kwargs['using']) \
#             .get_or_create(
#                 user_id=instance.user_id,
#                 peer_id=instance.peer_id,
#                 peer_type=instance.peer_type,
#                 defaults={
#                     'last_message_id': instance.message_id,
#                     'max_message_id': instance.message_id,
#                     'last_updated': current_timestamp(),
#                     'unread_count': add_unread_count})
#     else:
#         # update last_message_id & last_updated & unread_count
#         UserConversation.objects \
#             .using(kwargs['using']) \
#             .filter(id=conversation.id) \
#             .update(
#                 unread_count=F('unread_count') + add_unread_count,
#                 last_updated=current_timestamp(),
#                 last_message_id=instance.message_id,
#                 max_message_id=max(instance.message_id, conversation.max_message_id)
#             )
#
#     # # update unread_count
#     # if kwargs['created']:
#     #     if instance.is_read or instance.is_ignored:
#     #         pass
#     #     else:
#     #         UserConversation.objects \
#     #             .using(instance._state.db) \
#     #             .filter(id=conversation.id) \
#     #             .update(unread_count=F('unread_count') + 1)
#     # else:
#     #     if instance.is_read or instance.is_ignored:
#     #         UserConversation.objects \
#     #             .using(instance._state.db) \
#     #             .filter(id=conversation.id) \
#     #             .filter(unread_count__gt=0) \
#     #             .update(unread_count=F('unread_count') - 1)
#     #     else:
#     #         pass
#
#     # if hasattr(instance, '_no_trigger_send_message'):
#     #     return
#
#     return send_message_to_queue(
#         settings.STARFISH_CONVERSATION_UPDATED_MESSAGE_QUEUE_NAME,
#         json.dumps({
#             'conversation_id': conversation.id,
#             'last_message_id': instance.message_id,
#             'scope_org_id': to_org_id(instance._state.db),
#             'session_id': getattr(instance, '_session_id', None),
#         })
#     )


@receiver(post_save, sender=UserMessage)
def update_global_user_message_unread_count(sender, instance, **kwargs):
    if instance._state.db != 'default':
        return

    # create if not exists
    obj, created = UserMessageUnreadCount.objects \
        .using(instance._state.db) \
        .get_or_create(
            user_id=instance.user_id,
            defaults={'unread_count': 0})

    # update unread_count
    if kwargs['created']:
        if instance.is_read or instance.is_ignored:
            pass
        else:
            UserMessageUnreadCount.objects \
                .using(instance._state.db) \
                .filter(id=obj.id) \
                .update(unread_count=F('unread_count') + 1)
    else:
        if instance.is_read or instance.is_ignored:
            UserMessageUnreadCount.objects \
                .using(instance._state.db) \
                .filter(id=obj.id) \
                .filter(unread_count__gt=0) \
                .update(unread_count=F('unread_count') - 1)
        else:
            pass

    body = {
        'value': UserMessageUnreadCount.objects.get_or_none(id=obj.id).to_dict(),
        'messages': [instance.message_id],
        'status': instance.status
    }
    SystemMessage(Message.TYPE_GLOBAL_MESSAGES_UPDATED, body).send(obj.user_id)


@receiver(post_delete, sender=UserConversation)
def send_message_on_conversation_deleted(sender, instance, **kwargs):
    body = {
        'conversation': instance.to_dict0(),
    }
    SystemMessage(Message.TYPE_CONVERSATION_DELETED, body, instance.org_id)\
        .send(instance.user_id, session_id=get_current_session_id())


@receiver(post_delete, sender=UserConversation)
def delete_user_message_on_conversation_deleted(sender, instance, **kwargs):
    UserMessage.objects \
        .using(instance._state.db) \
        .filter(user_id=instance.user_id) \
        .filter(peer_type=instance.peer_type) \
        .filter(peer_id=instance.peer_id) \
        .delete()
