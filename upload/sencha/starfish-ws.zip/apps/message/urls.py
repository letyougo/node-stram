from django.conf.urls import patterns, url
from apps.acl.models import SystemRole

from apps.message import views

conversation_list = views.ConversationViewSet.as_view({
    'get': ('list', SystemRole.ORG_MEMBER_SELF)
})

conversation_detail = views.ConversationViewSet.as_view({
    'delete': 'destroy',
    'patch': 'partial_update',
})

messages_list = views.OrgMessageViewSet.as_view({
    'post': 'create',
})

conversation_messages_list = views.OrgMessageViewSet.as_view({
    'get': 'list',
    'patch': 'update_conversation_messages',
})

multi_messages_detail = views.OrgMessageViewSet.as_view({
    'patch': 'multi_partial_update',
})

org_message_status = views.OrgMessageViewSet.as_view({
    'get': 'status',
})

conversation_unread_message_ids_list = views.OrgMessageViewSet.as_view({
    'get': 'list_unread',
})

global_message_list = views.GlobalMessageViewSet.as_view({
    'get': ('list', SystemRole.USER_SELF)
})

global_message_unread_count = views.GlobalMessageViewSet.as_view({
    'get': 'unread_count',
})

multi_global_messages_detail = views.GlobalMessageViewSet.as_view({
    'patch': 'multi_partial_update',
})

global_message_status = views.GlobalMessageViewSet.as_view({
    'get': 'status',
})

urlpatterns = patterns(
    '',
    url(r'^v1/orgs/(?P<org_id>\d+)/conversations/(?P<conversation_id>\d+)/messages$',
        conversation_messages_list, name='conversation-messages-list'),
    url(r'^v1/orgs/(?P<org_id>\d+)/members/(?P<user_id>\d+)/conversations$',
        conversation_list, name='conversations-list'),

    url(r'^v1/orgs/(?P<org_id>\d+)/conversations/(?P<conversation_id>\d+)$',
        conversation_detail, name='conversation-detail'),

    url(r'^v1/orgs/(?P<org_id>\d+)/messages$', messages_list, name='messages-list'),
    url(r'^v1/orgs/(?P<org_id>\d+)/messages/(?P<message_id>[\d,]+)$',
        multi_messages_detail, name='multi-messages-detail'),
    url(r'^v1/orgs/(?P<org_id>\d+)/messages/(?P<message_id>\d+)/status$',
        org_message_status, name='org-message-status'),

    url(r'^v1/users/(?P<user_id>\d+)/messages/unread_count$',
        global_message_unread_count, name='global-message-unread-count'),
    url(r'^v1/users/(?P<user_id>\d+)/messages$', global_message_list, name='global-messages-list'),
    url(r'^v1/messages/(?P<message_id>[\d,]+)$', multi_global_messages_detail,
        name='multi-global-messages-detail'),
    url(r'^v1/messages/(?P<message_id>\d+)/status$',
        org_message_status, name='global-message-status'),

    # 获取conversation_id中未读消息id list
    url(r'^v1/orgs/(?P<org_id>\d+)/conversations/(?P<conversation_id>\d+)/messages/unread_ids$',
        conversation_unread_message_ids_list, name='conversation-unread-message-ids-list'),
)
