import json
from django.conf import settings
from django.db.models import Q
from rest_framework.response import Response

from apps.message.models import (
    Message, UserConversation, UserMessage, UserMessageUnreadCount)
from apps.message import chat, task, fs
from apps.account.models import User
from apps.message.utils import update_user_message_status, \
    handle_global_user_message_status_updated, ignore_all_message_in_conversation

from common.const import ErrorCode, DestType, SrcType
from common.exceptions import APIError
from common.message_queue import send_message_to_queue
from common.utils import shard_id, TargetObject, list_ids, setattr_if_changed
from common.viewset import ViewSet

import logging
log = logging.getLogger(__name__)


class BaseMessageViewSet(ViewSet):
    def _build_result(self, request, user_messages, org_id=0):
        messages = Message.load_by_user_messages(org_id, user_messages)
        return [messages[um.message_id] for um in user_messages if um.message_id in messages]

    def _status(self, request, user_messages):
        status = request.GET.get('status')
        if status is not None:  # new version api
            user_messages = user_messages.filter(status=status).order_by('id')
            start = request.GET.get('start')
            ps = int(request.GET.get('ps', 30))
            if start:
                user_messages = user_messages.filter(id__gt=start)

            results = []
            _t = TargetObject()
            for r in user_messages.values('id', 'user_id', 'update_at')[:ps]:
                r['user'] = _t.obj_info(User, r['user_id'])
                results.append(r)

        else:  # @TODO: old api to be deprecated
            results = []
            for i in user_messages:
                if i.is_read:
                    s = {
                        'status': 'read',
                        'time': i.update_at,
                        'user': i.user_id}
                elif i.is_ignored:
                    s = {
                        'status': 'ignored',
                        'time': i.update_at,
                        'user': i.user_id}
                else:
                    s = {
                        'status': 'unread',
                        'time': 0,
                        'user': i.user_id}
                results.append(s)

        return Response({'errcode': ErrorCode.OK, 'data': results})


class ConversationViewSet(ViewSet):
    DEFAULT_PAGE_SIZE = 50

    def list(self, request, org_id, user_id):
        if request.GET.get('peer_id') and request.GET.get('peer_type'):
            return self._search_by_peer(request, org_id, user_id)

        return self._list0(request, org_id, user_id)

    def destroy(self, request, org_id, conversation_id):
        UserConversation.objects \
            .using(shard_id(org_id)) \
            .filter(id=conversation_id) \
            .delete()

        return Response({'errcode': ErrorCode.OK})

    def partial_update(self, request, org_id, conversation_id):
        conversation = UserConversation.objects.using(org_id).getx(id=conversation_id)
        if not conversation:
            raise APIError(ErrorCode.NO_SUCH_CONVERSATION,
                           org_id=org_id, conversation_id=conversation_id)

        is_hide = request.DATA.get('is_hide', 0)
        if setattr_if_changed(conversation, is_hide=is_hide):
            conversation.save()

            if is_hide:
                ignore_all_message_in_conversation(org_id, conversation_id)

            send_message_to_queue(
                settings.STARFISH_CONVERSATION_UPDATED_MESSAGE_QUEUE_NAME,
                {
                    'conversation_id': conversation.id,
                    'scope_org_id': org_id
                }
            )

        if request.DATA.get('is_delete_all_messages') == 1:
            if setattr_if_changed(conversation, last_message_id=0, max_message_id=0):
                conversation.save()

            ignore_all_message_in_conversation(org_id, conversation_id)

            UserMessage.objects \
                .using(org_id) \
                .filter(user_id=conversation.user_id) \
                .filter(peer_type=conversation.peer_type, peer_id=conversation.peer_id) \
                .delete()

            Message(
                src_type=SrcType.ORG_MEMBER,
                src_id=conversation.user_id,
                dest_type=DestType.ORG_MEMBER,
                dest_id=conversation.user_id,
                type=Message.TYPE_MESSAGES_DELETED_IN_CONVERSATION,
            ).sendout({'conversation': conversation.to_dict()},
                      db=shard_id(org_id))

        return Response({'errcode': ErrorCode.OK, 'data': conversation.to_dict()})

    def _list0(self, request, org_id, user_id):
        start = request.GET.get('start', 0)
        if not start:
            return self._list1(request, org_id, user_id)

        uc = UserConversation.objects \
            .using(shard_id(org_id)) \
            .get_or_none(id=start)
        if not uc:
            return self._list1(request, org_id, user_id)

        ret = UserConversation.objects \
            .using(shard_id(org_id)) \
            .filter(user_id=user_id, is_hide=0) \
            .filter(last_message_id__lt=uc.last_message_id) \
            .order_by('-last_message_id')[:int(request.GET.get('ps', self.DEFAULT_PAGE_SIZE))]

        return Response({
            'errcode': ErrorCode.OK,
            'data': self._build_result(request, ret, org_id, user_id)})

    def _list1(self, request, org_id, user_id):
        ret = UserConversation.objects \
            .using(shard_id(org_id)) \
            .filter(user_id=user_id, is_hide=0) \
            .order_by('-last_message_id')[:int(request.GET.get('ps', self.DEFAULT_PAGE_SIZE))]

        return Response({
            'errcode': ErrorCode.OK,
            'data': self._build_result(request, ret, org_id, user_id)})

    def _search_by_peer(self, request, org_id, user_id):
        conversation = UserConversation.find(org_id, user_id,
                                             request.GET['peer_type'], request.GET['peer_id'])

        data = conversation.to_dict() if conversation else {}
        return Response({'errcode': ErrorCode.OK, 'data': data})

    def _build_result(self, request, user_conversations, org_id, user_id):
        message_ids = [i.max_message_id for i in user_conversations]

        user_messages = UserMessage.objects \
            .using(shard_id(org_id)) \
            .filter(user_id=user_id) \
            .filter(message_id__in=message_ids)

        messages = Message.load_by_user_messages(org_id, user_messages)

        ret = []
        for uc in user_conversations:
            last_message = messages.get(uc.max_message_id) or {}
            # if not last_message:
            #     continue

            r = uc.to_dict0()
            r['last_message'] = last_message
            ret.append(r)

        return ret


class OrgMessageViewSet(
        BaseMessageViewSet,
        chat.ChatMessageMixin, task.TaskMessageMixin, fs.FSMessageMixin):

    PAGE_SIZE = 30
    UNREAD_PAGE_SIZE = 100

    def create(self, request, org_id):
        self._normalize_dest(request)

        for dest in request.DATA['dests']:
            dest_type, dest_id = dest['type'], dest['id']
            if dest_type == DestType.ORG_MEMBER:
                u = User.objects.get_or_none(id=dest_id)
                if not u or not u.in_org(org_id):
                    return Response({'errcode': ErrorCode.PERMISSION_DENIED})
            elif dest_type == DestType.DISCUSSION_GROUP:
                if not request.current_user.in_discussion_group(org_id, dest_id):
                    return Response({'errcode': ErrorCode.PERMISSION_DENIED})
            elif dest_type == DestType.DEPARTMENT:
                message_type = int(request.DATA['type'])
                if message_type in (Message.TYPE_TASK_CREATED, Message.TYPE_TASK_COMPLETED):
                    pass
                else:
                    if not request.current_user.in_department(org_id, dest_id):
                        return Response({'errcode': ErrorCode.PERMISSION_DENIED})
            else:
                return Response({'errcode': ErrorCode.INVALID_DEST_TYPE})

        return self._create_message(request, org_id)

    def _create_message(self, request, org_id):
        message_type = int(request.DATA['type'])
        messages, ret = [], []
        if message_type in (Message.TYPE_TEXT_CHAT_CREATED, Message.TYPE_MULTIMEDIA_CHAT_CREATED):
            messages = [
                self.create_chat_message(request, org_id, dest['type'], dest['id'])
                for dest in request.DATA['dests']
            ]

        if message_type in (Message.TYPE_TASK_CREATED, Message.TYPE_TASK_COMPLETED):
            messages = [
                self.create_task_message(request, org_id, dest['type'], dest['id'])
                for dest in request.DATA['dests']
            ]

        if message_type in (Message.TYPE_FILES_CREATED, ):
            messages = [
                self.create_fs_message(request, org_id, dest['type'], dest['id'])
                for dest in request.DATA['dests']
            ]

        for m in messages:
            r = m.to_dict()
            r.update({
                'is_read': 1,
                'is_ignored': 0,
                'unread_count': -1,
                'body': m._snapshot,
            })

            ret.append(r)

        if not ret:
            return Response({'errcode': ErrorCode.INVALID_MESSAGE_TYPE})
        elif len(ret) == 1:
            return Response({'errcode': ErrorCode.OK, 'data': ret[0]})
        else:
            return Response({'errcode': ErrorCode.OK, 'data': ret})

    def update_conversation_messages(self, request, org_id, conversation_id):
        ignore_all_message_in_conversation(org_id, conversation_id)
        return Response({'errcode': ErrorCode.OK})

    def __unread_message_ids_by_conversation(self, conversation, ordering='id'):
        qs = UserMessage.objects \
            .using(conversation.org_id) \
            .filter(user_id=conversation.user_id) \
            .filter(peer_type=conversation.peer_type, peer_id=conversation.peer_id) \
            .filter(status=Message.STATUS_NULL) \
            .values_list('message_id', flat=True)\
            .order_by(ordering)

        return qs

    def list(self, request, org_id, conversation_id):
        conversation = UserConversation.objects \
            .using(shard_id(org_id)) \
            .getx(id=conversation_id)
        if not conversation:
            return Response({'errcode': ErrorCode.NO_SUCH_CONVERSATION})

        qs = UserMessage.objects \
            .using(shard_id(org_id)) \
            .filter(user_id=conversation.user_id) \
            .filter(peer_type=conversation.peer_type, peer_id=conversation.peer_id)

        page_size = int(request.GET.get('ps', self.PAGE_SIZE))
        start = int(request.GET.get('start', 0))  # messages that id earlier than start
        middle = int(request.GET.get('middle', 0))

        with_equal = False
        end = request.GET.get('end', 0)
        if end == 'first_unread':  # end is earliest unread message
            unread_message_ids = self.__unread_message_ids_by_conversation(conversation)
            if not unread_message_ids.exists():
                raise APIError(ErrorCode.NO_SUCH_MESSAGE, conversation_id=conversation_id)
            end = unread_message_ids[0]
            with_equal = True
        else:  # messages that id later than end
            end = int(end)

        if middle:
            # list messages earlier than middle and later than middle, half of page_size for each.
            # order by id desc limit page_size
            earlier = qs.filter(message_id__lt=middle).order_by('-message_id')[:int(page_size/2)]
            later = qs.filter(message_id__gte=middle).order_by('message_id')[:page_size-int(page_size/2)]
            earlier, later = list(earlier), list(later)
            later.reverse()
            ret = later + earlier
        else:
            if start:
                # list messages earlier than start, order by id desc limit page_size
                qs = qs.filter(message_id__lt=start)
                ret = qs.order_by('-message_id')[:page_size]
            elif end:
                # list messages later than end, order by id desc limit page_size
                if with_equal:
                    qs = qs.filter(message_id__gte=end)
                else:
                    qs = qs.filter(message_id__gt=end)
                ret = list(reversed(qs.order_by('message_id')[:page_size]))
            else:
                ret = qs.order_by('-message_id')[:page_size]

        return Response({
            'errcode': ErrorCode.OK,
            'data': self._build_result(request, ret, org_id)})

    def list_unread(self, request, org_id, conversation_id):
        conversation = UserConversation.objects \
            .using(shard_id(org_id)) \
            .getx(id=conversation_id)
        if not conversation:
            return Response({'errcode': ErrorCode.NO_SUCH_CONVERSATION})

        qs = self.__unread_message_ids_by_conversation(
            conversation,
            ordering='id' if request.GET.get('asc') else '-id')

        ret = self.paging(request, qs, default_count=self.UNREAD_PAGE_SIZE)
        return Response({'errcode': ErrorCode.OK, 'data': ret})

    def _normalize_dest(self, request):
        # dest_type, dest_id -> dests
        if 'dest_type' in request.DATA:
            request.DATA['dests'] = [
                {'type': request.DATA['dest_type'],
                 'id': request.DATA['dest_id']}
            ]

    def multi_partial_update(self, request, org_id, message_id):
        message_ids = list_ids(message_id)

        user_messages = UserMessage.objects\
            .using(org_id) \
            .filter(user_id=request.current_uid,
                    message_id__in=message_ids,
                    status=Message.STATUS_NULL)

        is_read, is_ignored = (
            int(request.DATA.get('is_read', 0)),
            int(request.DATA.get('is_ignored', 0)),
        )
        if (is_read and is_ignored) or (not is_read and not is_ignored):
            raise APIError(ErrorCode.BAD_REQUEST_PARAMS, is_read=is_read, is_ignored=is_ignored)

        status = Message.STATUS_READ if is_read else Message.STATUS_IGNORE
        # user_messages = user_messages.filter(status=Message.STATUS_NULL)

        s = set(user_messages.values_list('peer_type', 'peer_id'))
        if len(s) == 0:  # skip set user_message status repeat
            return Response({'errcode': ErrorCode.OK})

        for peer_type, peer_id in s:
            conversation = UserConversation.find(org_id, request.current_uid, peer_type, peer_id)
            update_user_message_status(conversation,
                                       user_messages.filter(peer_type=peer_type, peer_id=peer_id),
                                       status)
        return Response({'errcode': ErrorCode.OK})

    def status(self, request, org_id, message_id):
        r = UserMessage.objects \
            .using(shard_id(org_id)) \
            .filter(message_id=message_id)\
            .exclude(user_id=request.current_uid)

        return self._status(request, r)


class GlobalMessageViewSet(BaseMessageViewSet):
    PAGE_SIZE = 30

    def list(self, request, user_id):
        qs = UserMessage.objects \
            .filter(user_id=user_id)

        start = int(request.GET.get('start', 0))
        if start:
            qs = qs.filter(message_id__lt=start)

        ret = qs.order_by('-id')[:self.PAGE_SIZE]

        return Response({
            'errcode': ErrorCode.OK,
            'data': self._build_result(request, ret)})

    def multi_partial_update(self, request, message_id):
        if isinstance(message_id, int):
            message_ids = [message_id]
        else:
            message_ids = [int(i) for i in message_id.split(',') if i]

        user_messages = UserMessage.objects \
            .filter(user_id=request.current_uid) \
            .filter(message_id__in=message_ids)

        is_read, is_ignored = (
            int(request.DATA.get('is_read', 0)),
            int(request.DATA.get('is_ignored', 0)),
        )
        if (is_read and is_ignored) or (not is_read and not is_ignored):
            raise APIError(ErrorCode.BAD_REQUEST_PARAMS, is_read=is_read, is_ignored=is_ignored)

        status = Message.STATUS_READ if is_read else Message.STATUS_IGNORE
        user_messages = user_messages.exclude(status=status)

        message_ids = list(user_messages.values_list('message_id', flat=True))
        if message_ids:
            updated_count = user_messages.update(status=status)
            handle_global_user_message_status_updated(request.current_uid, status,
                                                      message_ids, updated_count)

        return Response({'errcode': ErrorCode.OK})

    def unread_count(self, request, user_id):
        o = UserMessageUnreadCount.objects \
            .get_or_none(user_id=user_id)

        cnt = 0 if not o else o.unread_count

        return Response({'errcode': ErrorCode.OK, 'data': cnt})

    def status(self, request, message_id):
        r = UserMessage.objects \
            .filter(message_id=message_id)

        return self._status(request, r)
