from datetime import datetime, timedelta
import json
from django.conf import settings
from django.db.models import F
from apps.message.models import Message, UserMessage, MessageContent, UserConversation, \
    UserMessageUnreadCount
from apps.org.models import UserDiscussionGroup, Department
from common import AutoRegistryBase
from common.cache import MessageStatusCache

from common.const import DestType, PeerType, SrcType, ErrorCode
from common.exceptions import APIError
from common.message_queue import send_message_to_queue, SystemMessage
from common.utils import to_org_id, current_timestamp, shard_id

import logging
log = logging.getLogger(__name__)


class UserMessageCreator(AutoRegistryBase):
    NEED_UPDATE_CONVERSATION = True
    REGIST_KEY = (
        Message.TYPE_MULTIMEDIA_CHAT_CREATED,
        Message.TYPE_TEXT_CHAT_CREATED,

        Message.TYPE_FILES_CREATED,

        Message.TYPE_TASK_CREATED,
        Message.TYPE_TASK_COMPLETED,
        Message.TYPE_TASK_COMMENT_CREATED,

        Message.TYPE_VOICE_MESSAGE_UPDATED,
    )

    def __init__(self, message):
        self.message = message
        self.peer_type = {
            DestType.ORG_MEMBER: PeerType.ORG_MEMBER,
            DestType.DEPARTMENT: PeerType.DEPARTMENT,
            DestType.DISCUSSION_GROUP: PeerType.DISCUSSION_GROUP,
        }.get(message.dest_type)

        self.result = []  # save a tuple of (user_id, peer_id, peer_type, status)
        self.build_user_messages()  # do the build job

    def _message_content(self):
        body = MessageContent.objects \
            .using(self.message.org_id) \
            .getx(id=self.message.content).content

        return body

    def add(self, user_id, peer_id=None, peer_type=None, status=None):
        if peer_id is None:
            peer_id = self.message.dest_id

        if peer_type is None:
            peer_type = self.peer_type

        if status is None:
            if self.message.src_type == SrcType.ORG_MEMBER and user_id == self.message.src_id:
                status = Message.STATUS_READ
            else:
                status = Message.STATUS_NULL

        self.result.append(
            (user_id, peer_id, peer_type, status)
        )

    def build_user_messages(self):
        if self.message.dest_type is DestType.ORG_MEMBER:
            self.add(self.message.src_id)

            if self.message.dest_id != self.message.src_id:
                self.add(self.message.dest_id, self.message.src_id)

        elif self.message.dest_type is DestType.DISCUSSION_GROUP:
            for user_id in UserDiscussionGroup.user_ids(self.message.org_id, self.message.dest_id):
                self.add(user_id)

        elif self.message.dest_type is DestType.DEPARTMENT:
            for user_id in Department.user_ids(self.message.org_id, self.message.dest_id):
                self.add(user_id)


class EmailUserMessageCreator(UserMessageCreator):
    REGIST_KEY = (
        Message.TYPE_EMAIL_CREATED,
    )

    def build_user_messages(self):
        if self.message.dest_type == DestType.ORG_MEMBER:

            if self.message.src_type == SrcType.EXTERNAL_CONTACT:
                self.add(self.message.dest_id, self.message.src_id, PeerType.EXTERNAL_CONTACT)
                return
            elif self.message.src_type == SrcType.GENERATED_CONTACT:
                self.add(self.message.dest_id, self.message.src_id, PeerType.GENERATED_CONTACT)
                return

        super(EmailUserMessageCreator, self).build_user_messages()


class GroupDisbandedMessageCreator(UserMessageCreator):
    NEED_UPDATE_CONVERSATION = False
    REGIST_KEY = (
        Message.TYPE_DISCUSSION_GROUP_DISBANDED,
    )

    def build_user_messages(self):
        for user_id in UserDiscussionGroup.user_ids(self.message.org_id, self.message.dest_id,
                                                    filter_disbanded=False):
            self.add(user_id, status=Message.STATUS_READ)


class DepartmentDisbandedMessageCreator(UserMessageCreator):
    NEED_UPDATE_CONVERSATION = False
    REGIST_KEY = (
        Message.TYPE_DEPARTMENT_DISBANDED,
    )

    def build_user_messages(self):
        message_content = self._message_content()
        group_id = message_content['group']['id']
        for user_id in Department.user_ids(self.message.org_id, group_id,
                                           direct_in=1, filter_disbanded=False):
            self.add(user_id, status=Message.STATUS_READ,
                     peer_type=PeerType.DEPARTMENT, peer_id=group_id)


class GroupMemberLeftMessageCreator(GroupDisbandedMessageCreator):
    NEED_UPDATE_CONVERSATION = False
    REGIST_KEY = (
        Message.TYPE_DISCUSSION_GROUP_MEMBER_LEFT,
    )

    def build_user_messages(self):
        super(GroupMemberLeftMessageCreator, self).build_user_messages()
        user_id = self._message_content()['user']['id']
        if user_id:
            self.add(user_id, status=Message.STATUS_READ)


class DepartmentMemberLeftMessageCreator(DepartmentDisbandedMessageCreator):
    NEED_UPDATE_CONVERSATION = False
    REGIST_KEY = (
        Message.TYPE_DEPARTMENT_MEMBER_LEFT,
    )

    def build_user_messages(self):
        super(DepartmentMemberLeftMessageCreator, self).build_user_messages()
        data = self._message_content()
        user_id = data['user']['id']
        group_id = data['group']['id']
        if user_id:
            self.add(user_id, status=Message.STATUS_READ,
                     peer_type=PeerType.DEPARTMENT, peer_id=group_id)


class InvitationUserMessageCreator(UserMessageCreator):
    REGIST_KEY = (
        Message.TYPE_INVITATION_CREATED,
        Message.TYPE_INVITATION_UPDATED
    )

    def build_user_messages(self):
        self.add(self.message.dest_id, self.message.src_id,
                 PeerType.ORG_MEMBER, Message.STATUS_NULL)


class UserMessageUtils(object):
    @classmethod
    def get_user_message_meta(cls, message):
        creator_class = UserMessageCreator.registed(message.type)
        if not creator_class:
            return []

        return creator_class(message).result

    @classmethod
    def need_update_conversation(cls, message):
        creator_class = UserMessageCreator.registed(message.type)
        if not creator_class:
            return False

        return creator_class.NEED_UPDATE_CONVERSATION

    @classmethod
    def save_user_message(cls, message, session_id=None, user_message_meta=None):
        meta = user_message_meta or cls.get_user_message_meta(message)
        if not meta:
            return

        db = message._state.db
        _need_update_conversation = cls.need_update_conversation(message)

        unread_user_ids = []
        for user_id, peer_id, peer_type, status in meta:
            um = UserMessage(user_id=user_id, message_id=message.id,
                             peer_id=peer_id, peer_type=peer_type,
                             status=status)
            um.save(using=db)

            if status == Message.STATUS_NULL:
                unread_user_ids.append(user_id)

            # create or update conversation
            update_conversation_on_user_message_created(db, um, session_id,
                                                        is_update_time=_need_update_conversation)

        MessageStatus().new_message(message, unread_user_ids)

        return meta

# class Utils(object):
#     @classmethod
#     def get_user_message_meta(cls, message):
#         res = []
#
#         if message.type in (
#                 Message.TYPE_MULTIMEDIA_CHAT_CREATED,
#                 Message.TYPE_TEXT_CHAT_CREATED):
#             res = cls._build_user_message_for_chat(message)
#
#         if message.type in (
#                 Message.TYPE_INVITATION_CREATED,
#                 Message.TYPE_INVITATION_UPDATED):
#             res = cls._build_user_message_for_invitation(message)
#
#         if message.type == Message.TYPE_EMAIL_CREATED:
#             res = cls._build_user_message_for_mail(message)
#
#         if message.type in (
#                 Message.TYPE_TASK_CREATED,
#                 Message.TYPE_TASK_COMPLETED,
#                 Message.TYPE_TASK_COMMENT_CREATED):
#             res = cls._build_user_message_for_task(message)
#
#         if message.type == Message.TYPE_DISCUSSION_GROUP_MEMBER_LEFT:
#             res = cls._build_user_message_for_group_member_left(message)
#
#         if message.type == Message.TYPE_DISCUSSION_GROUP_DISBANDED:
#             res = cls._build_user_message_for_group_disbanded(message)
#
#         if message.type == Message.TYPE_FILES_CREATED:
#             res = cls._build_user_message_for_file(message)
#
#         return res
#
#     @classmethod
#     def save_user_message(cls, message, session_id=None, user_message_meta=None):
#         meta = user_message_meta or cls.get_user_message_meta(message)
#         if meta is None:
#             log.error('can not handle message type: %s', message.type)
#
#         db = message._state.db
#
#         unread_user_ids = []
#         for user_id, peer_id, peer_type, status in meta:
#             um = UserMessage(user_id=user_id, message_id=message.id,
#                              peer_id=peer_id, peer_type=peer_type,
#                              status=status)
#             um.save(using=db)
#
#             if status == Message.STATUS_NULL:
#                 unread_user_ids.append(user_id)
#
#             # create or update conversation
#             update_conversation_on_user_message_created(db, um, session_id)
#
#         MessageStatus().new_message(message, unread_user_ids)

    # @classmethod
    # def _build_user_message_for_chat(cls, message):
    #     ret = []
    #
    #     if message.dest_type == DestType.ORG_MEMBER:
    #         ret.append((message.src_id, message.dest_id, PeerType.ORG_MEMBER, Message.STATUS_READ))
    #
    #         if message.dest_id == message.src_id:
    #             ret.append(
    #                 (message.dest_id, message.src_id, PeerType.ORG_MEMBER, Message.STATUS_READ))
    #         else:
    #             ret.append(
    #                 (message.dest_id, message.src_id, PeerType.ORG_MEMBER, Message.STATUS_NULL))
    #
    #     if message.dest_type == DestType.DISCUSSION_GROUP:
    #         for user_id in UserDiscussionGroup.user_ids(
    #                 to_org_id(message._state.db), message.dest_id):
    #             if user_id == message.src_id:
    #                 ret.append(
    #                     (user_id, message.dest_id,
    #                         PeerType.DISCUSSION_GROUP, Message.STATUS_READ))
    #             else:
    #                 ret.append(
    #                     (user_id, message.dest_id, PeerType.DISCUSSION_GROUP, Message.STATUS_NULL))
    #
    #     if message.dest_type == DestType.DEPARTMENT:
    #         for user_id in Department.user_ids(
    #                 to_org_id(message._state.db), message.dest_id):
    #             if user_id == message.src_id:
    #                 ret.append(
    #                     (user_id, message.dest_id,
    #                         PeerType.DEPARTMENT, Message.STATUS_READ))
    #             else:
    #                 ret.append(
    #                     (user_id, message.dest_id, PeerType.DEPARTMENT, Message.STATUS_NULL))
    #
    #     return ret
    #
    # @classmethod
    # def _build_user_message_for_invitation(cls, message):
    #     return [(message.dest_id, message.src_id, PeerType.ORG_MEMBER, Message.STATUS_NULL)]
    #
    # @classmethod
    # def _build_user_message_for_group_member_left(cls, message):
    #     body = MessageContent.objects \
    #         .using(message._state.db) \
    #         .get_or_none(id=message.content).content
    #
    #     ret = []
    #
    #     readers = set([body['user']['id'], body['operator']['id']])
    #     for i in readers:
    #         ret.append((i, message.dest_id, PeerType.DISCUSSION_GROUP, Message.STATUS_READ))
    #
    #     # for type == TYPE_DISCUSSION_GROUP_MEMBER_LEFT, don't send to group members.
    #     if message.type == Message.TYPE_DISCUSSION_GROUP_MEMBER_LEFT:
    #         return ret
    #
    #     # add message for others in group
    #     for user_id in UserDiscussionGroup.user_ids(to_org_id(message._state.db), message.dest_id):
    #         if user_id in readers:
    #             continue
    #
    #         ret.append(
    #             (user_id, message.dest_id, PeerType.DISCUSSION_GROUP, Message.STATUS_READ))
    #
    #     return ret
    #
    # @classmethod
    # def _build_user_message_for_group_disbanded(cls, message):
    #     ret = []
    #     for user_id in UserDiscussionGroup.user_ids(
    #             to_org_id(message._state.db), message.dest_id, filter_disbanded=False):
    #         ret.append(
    #             (user_id, message.dest_id, PeerType.DISCUSSION_GROUP, Message.STATUS_READ))
    #
    #     return ret
    #
    # @classmethod
    # def _build_user_message_for_mail(cls, message):
    #     ret = []
    #
    #     if message.dest_type == DestType.ORG_MEMBER:
    #         if message.src_type == SrcType.ORG_MEMBER:
    #             ret.append(
    #                 (message.src_id, message.dest_id,
    #                  PeerType.ORG_MEMBER, Message.STATUS_READ))
    #             if message.dest_id != message.src_id:
    #                 ret.append(
    #                     (message.dest_id, message.src_id,
    #                      PeerType.ORG_MEMBER, Message.STATUS_NULL))
    #
    #         if message.src_type in (SrcType.EXTERNAL_CONTACT, SrcType.GENERATED_CONTACT):
    #             if message.src_type == SrcType.EXTERNAL_CONTACT:
    #                 peer_type = PeerType.EXTERNAL_CONTACT
    #             else:
    #                 peer_type = PeerType.GENERATED_CONTACT
    #             ret.append(
    #                 (message.dest_id,
    #                  message.src_id,
    #                  peer_type, Message.STATUS_NULL))
    #
    #     if message.dest_type == DestType.DEPARTMENT:
    #         for user_id in Department.user_ids(
    #                 to_org_id(message._state.db), message.dest_id):
    #             if user_id == message.src_id and message.src_type == SrcType.ORG_MEMBER:
    #                 ret.append(
    #                     (user_id, message.dest_id, PeerType.DEPARTMENT, Message.STATUS_READ))
    #             else:
    #                 ret.append(
    #                     (user_id, message.dest_id, PeerType.DEPARTMENT, Message.STATUS_NULL))
    #
    #     if message.dest_type == DestType.DISCUSSION_GROUP:
    #         for user_id in UserDiscussionGroup.user_ids(
    #                 to_org_id(message._state.db), message.dest_id):
    #             if user_id == message.src_id and message.src_type == SrcType.ORG_MEMBER:
    #                 ret.append(
    #                     (user_id, message.dest_id, PeerType.DISCUSSION_GROUP, Message.STATUS_READ))
    #             else:
    #                 ret.append(
    #                     (user_id, message.dest_id, PeerType.DISCUSSION_GROUP, Message.STATUS_NULL))
    #
    #     return ret
    #
    # @classmethod
    # def _build_user_message_for_task(cls, message):
    #     ret = []
    #
    #     if message.dest_type == DestType.ORG_MEMBER:
    #         ret.append(
    #             (message.src_id, message.dest_id,
    #              PeerType.ORG_MEMBER, Message.STATUS_READ))
    #         if message.dest_id != message.src_id:
    #             ret.append(
    #                 (message.dest_id, message.src_id,
    #                  PeerType.ORG_MEMBER, Message.STATUS_NULL))
    #     elif message.dest_type == DestType.DISCUSSION_GROUP:
    #         for user_id in UserDiscussionGroup.user_ids(
    #                 to_org_id(message._state.db), message.dest_id):
    #             if user_id == message.src_id:
    #                 ret.append(
    #                     (user_id, message.dest_id,
    #                         PeerType.DISCUSSION_GROUP, Message.STATUS_READ))
    #             else:
    #                 ret.append(
    #                     (user_id, message.dest_id,
    #                         PeerType.DISCUSSION_GROUP, Message.STATUS_NULL))
    #     elif message.dest_type == DestType.DEPARTMENT:
    #         for user_id in Department.user_ids(
    #                 to_org_id(message._state.db), message.dest_id):
    #             if user_id == message.src_id:
    #                 ret.append(
    #                     (user_id, message.dest_id,
    #                         PeerType.DEPARTMENT, Message.STATUS_READ))
    #             else:
    #                 ret.append(
    #                     (user_id, message.dest_id,
    #                         PeerType.DEPARTMENT, Message.STATUS_NULL))
    #
    #     else:
    #         log.warning('invalid dest id for task message: %s', message.id)
    #
    #     return ret
    #
    # @classmethod
    # def _build_user_message_for_file(cls, message):
    #     ret = []
    #
    #     if message.dest_type == DestType.ORG_MEMBER:
    #         ret.append(
    #             (message.src_id, message.dest_id,
    #              PeerType.ORG_MEMBER, Message.STATUS_READ))
    #         if message.dest_id != message.src_id:
    #             ret.append(
    #                 (message.dest_id, message.src_id,
    #                  PeerType.ORG_MEMBER, Message.STATUS_NULL))
    #
    #     elif message.dest_type == DestType.DISCUSSION_GROUP:
    #         for user_id in UserDiscussionGroup.user_ids(
    #                 to_org_id(message._state.db), message.dest_id):
    #             if user_id == message.src_id:
    #                 ret.append(
    #                     (user_id, message.dest_id,
    #                         PeerType.DISCUSSION_GROUP, Message.STATUS_READ))
    #             else:
    #                 ret.append(
    #                     (user_id, message.dest_id,
    #                         PeerType.DISCUSSION_GROUP, Message.STATUS_NULL))
    #
    #     elif message.dest_type == DestType.DEPARTMENT:
    #         for user_id in Department.user_ids(
    #                 to_org_id(message._state.db), message.dest_id):
    #             if user_id == message.src_id:
    #                 ret.append(
    #                     (user_id, message.dest_id,
    #                         PeerType.DEPARTMENT, Message.STATUS_READ))
    #             else:
    #                 ret.append(
    #                     (user_id, message.dest_id,
    #                         PeerType.DEPARTMENT, Message.STATUS_NULL))
    #
    #     else:
    #         log.warning('invalid dest id for file message: %s', message.id)
    #
    #     return ret


def ignore_all_message_in_conversation(org_id, conversation_id):
    conversation = UserConversation.objects.using(org_id).getx(id=conversation_id)
    if not conversation:
        raise APIError(ErrorCode.NO_SUCH_CONVERSATION,
                       org_id=org_id, conversation_id=conversation_id)

    user_messages = UserMessage.objects \
        .using(org_id) \
        .filter(user_id=conversation.user_id) \
        .filter(peer_type=conversation.peer_type, peer_id=conversation.peer_id) \
        .filter(status=Message.STATUS_NULL)

    update_user_message_status(conversation, user_messages, Message.STATUS_IGNORE)


def ignore_all_message_and_conversations(db, peer_type, peer_id, user_id=None):
    uc_qs = UserConversation.objects\
        .using(db)\
        .filter(peer_type=peer_type, peer_id=peer_id)\
        .exclude(unread_count=0)
    if user_id:
        uc_qs = uc_qs.filter(user_id=user_id)

    for ucid in uc_qs.values_list('id', flat=True):
        ignore_all_message_in_conversation(to_org_id(db), ucid)

    log.info('ignore_all_messages[%s], '
             'peer_id: %s, peer_type=%s, user_id=%s' % (db, peer_id, peer_type, user_id))


def update_conversation_on_user_message_created(db, usermessage, session_id, is_update_time=True):
    if db == 'default':
        return

    add_unread_count = 1 if usermessage.is_unread else 0
    conversation = UserConversation.find_by_usermessage(usermessage)

    if not conversation:
        # create if not exists
        conversation, created = UserConversation.objects \
            .using(db) \
            .get_or_create(
                user_id=usermessage.user_id,
                peer_id=usermessage.peer_id,
                peer_type=usermessage.peer_type,
                defaults={
                    'last_message_id': usermessage.message_id,
                    'max_message_id': usermessage.message_id,
                    'last_updated': current_timestamp(),
                    'unread_count': add_unread_count})
    else:
        # update last_message_id & last_updated & unread_count
        UserConversation.objects \
            .using(db) \
            .filter(id=conversation.id) \
            .update(
                unread_count=F('unread_count') + add_unread_count,
                last_updated=current_timestamp() if is_update_time else conversation.last_updated,
                last_message_id=usermessage.message_id,
                is_hide=0,
                max_message_id=max(usermessage.message_id, conversation.max_message_id)
            )
    send_message_to_queue(
        settings.STARFISH_CONVERSATION_UPDATED_MESSAGE_QUEUE_NAME,
        {
            'conversation_id': conversation.id,
            'last_message_id': usermessage.message_id,
            'scope_org_id': usermessage.org_id,
            'session_id': session_id,
        }
    )


def update_user_message_status(conversation, usermessage_qs, status):
    message_ids = list(usermessage_qs.values_list('message_id', flat=True))
    if len(message_ids) == 0:
        return

    count = usermessage_qs.update(status=status,
                                  update_at=current_timestamp())
    if count == 0:
        return

    org_id = conversation.org_id
    count = min(count, conversation.unread_count)

    UserConversation.objects \
        .using(org_id) \
        .filter(id=conversation.id) \
        .update(unread_count=F('unread_count')-count,
                last_updated=current_timestamp())

    # message conversation updated
    send_message_to_queue(
        settings.STARFISH_CONVERSATION_UPDATED_MESSAGE_QUEUE_NAME,
        json.dumps({
            'conversation_id': conversation.id,
            'scope_org_id': org_id
        })
    )

    # send message TYPE_MESSAGE_UPDATED
    body = dict(conversation=conversation.id,
                messages=message_ids,
                status=status)
    SystemMessage(Message.TYPE_MESSAGE_UPDATED, body, org_id)\
        .send(conversation.user_id)

    # update message unread cache
    MessageStatus().user_update_message_status(org_id, conversation.user_id, message_ids)


def handle_global_user_message_status_updated(user_id, status, message_ids, count=None):
    if count == 0 or len(message_ids) == 0:
        return

    um = UserMessageUnreadCount.objects.get_or_none(user_id=user_id)
    if not um:
        return
    
    count = min(count or len(message_ids), um.unread_count)

    UserMessageUnreadCount.objects \
        .filter(user_id=user_id) \
        .update(unread_count=F('unread_count') - count)

    body = {
        'value': UserMessageUnreadCount.objects.get_or_none(id=um.id).to_dict(),
        'messages': message_ids,
        'status': status
    }
    SystemMessage(Message.TYPE_GLOBAL_MESSAGES_UPDATED, body).send(um.user_id)


class MessageStatus(object):
    USER_COUNT_LIMIT = 30
    MESSAGE_TIME_LIMIT = 3600*24*7  # one week

    def get_cache(self, org_id):
        return MessageStatusCache(org_id, self.MESSAGE_TIME_LIMIT)

    def is_message_valid(self, message):
        '''
        message that created over MESSAGE_TIME_LIMIT will not be cached.
        message that targets over USER_COUNT_LIMIT will not be cached.
        '''
        # check message create time
        if message.create_time < datetime.now() - timedelta(seconds=self.MESSAGE_TIME_LIMIT):
            return False

        cache = self.get_cache(message.org_id)
        targets_count = cache.get_message_total_count(message.id)

        if targets_count is None:
            #  targets count cache is missing, rebuild it
            targets_count = UserMessage.objects.using(message.org_id)\
                .filter(message_id=message.id).count() - 1  # exclude message sender
            cache.set_message_total_count(message.id, targets_count)

        # check message target count
        if targets_count > self.USER_COUNT_LIMIT:
            return False

        return True

    def new_message(self, message, unread_user_ids):
        '''
        initialize cache when user-messages for a message is created
        '''
        if not message.org_id:
            return

        if not unread_user_ids:
            return

        cache = self.get_cache(message.org_id)
        cache.set_message_total_count(message.id, len(unread_user_ids))

        if not self.is_message_valid(message):
            return

        cache.new_unread_message(message.id, *unread_user_ids)
        self.send_message_on_unread_count_updated(message.org_id, message.src_id,
                                                  {message.id: len(unread_user_ids)}
                                                  )

    def get_unread_count(self, org_id, messages):
        '''
        get unread count of given messages from cache
        '''
        message_ids = [m.id for m in messages if self.is_message_valid(m)]
        if message_ids:
            cache = self.get_cache(org_id)
            return cache.message_unread_count(*message_ids)
        else:
            return {}

    def user_update_message_status(self, org_id, user_id, message_ids):
        '''
        update user-message status in cache
        user_id: who read the messages
        message_ids: messages ids were read
        '''
        cache = self.get_cache(org_id)

        updated = {}
        for mid in message_ids:
            unread_count = cache.update_message_read(mid, user_id)
            if unread_count is not None:
                updated[mid] = unread_count

        updated_messages = Message.objects.using(org_id)\
            .filter(id__in=updated.keys())\
            .filter(src_type=SrcType.ORG_MEMBER)

        #  group by src_id, notify user(message src_id user) in batch
        src_to_notify = {}
        for mid, src_id in updated_messages.values_list('id', 'src_id'):
            if src_id not in src_to_notify:
                src_to_notify[src_id] = {}

            src_to_notify[src_id][mid] = updated[mid]

        for src_id, data in src_to_notify.items():
            self.send_message_on_unread_count_updated(org_id, src_id, data)

    def send_message_on_unread_count_updated(self, org_id, msg_src_id, data):
        '''
        data: a dict like {message_id: unread_count}
        '''
        ums = UserMessage.objects.using(org_id)\
            .filter(user_id=msg_src_id)\
            .filter(message_id__in=data.keys())\
            .values_list('message_id', 'peer_type', 'peer_id')
        peers = {mid: (peer_type, peer_id) for mid, peer_type, peer_id in ums}

        res = []
        for mid, count in data.items():
            if mid not in peers:
                continue
            peer_type, peer_id = peers[mid]
            res.append({'message_id': mid, 'unread_count': count,
                        'peer_type': peer_type, 'peer_id': peer_id})

        body = {"data": res}
        SystemMessage(Message.TYPE_MESSAGE_UNREAD_COUNT_UPDATED, body, org_id) \
            .send(msg_src_id)
