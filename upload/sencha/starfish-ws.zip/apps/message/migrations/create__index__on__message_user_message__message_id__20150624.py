db = 'org'
sql = """
CREATE INDEX "message_user_message_message_id" ON "message_user_message" ("message_id");
"""
