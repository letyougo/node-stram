db = 'org'
sql = """
ALTER TABLE message_user_conversation ADD COLUMN "is_hide" smallint CHECK ("is_hide" >= 0) NOT NULL default 0;
"""