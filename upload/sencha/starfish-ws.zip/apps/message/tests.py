import os

from apps.message.models import Message

from common.tests import TestCase
from common.const import ErrorCode, DestType


class MessageTest(TestCase):

    test_files_dir = '%s/test-files' % os.path.dirname(os.path.abspath(__file__))

    def test_create_chat_message(self):
        self.login('alice')

        data = {
            'type': Message.TYPE_TEXT_CHAT_CREATED,
            'dest_id': self.users['bob'].id,
            'dest_type': DestType.ORG_MEMBER,
            'body': {
                'chat': {'content': 'hello moto'}
            }
        }
        chat_resp = self.client.post(
            '/v1/orgs/%s/messages' % self.orgs['ibm'].id, data=data, format='json')
        self.assertEqual(chat_resp.data['errcode'], ErrorCode.OK)

    def test_create_multimedia_chat_message(self):
        self.login('alice')

        test_file = '%s/exim-filter.pdf' % self.test_files_dir
        test_bfs_file = \
            self._prepare_bfs_file(self.users['alice'].id, self.orgs['ibm'].id, test_file)

        data = {
            'type': Message.TYPE_MULTIMEDIA_CHAT_CREATED,
            'dest_id': self.users['bob'].id,
            'dest_type': DestType.ORG_MEMBER,
            'body': {
                'chat': {
                    'bfs_file_id': test_bfs_file.id,
                    'name': 'hello.pdf'
                }
            },
        }
        chat_resp = self.client.post(
            '/v1/orgs/%s/messages' % self.orgs['ibm'].id, data=data, format='json')
        self.assertEqual(chat_resp.data['errcode'], ErrorCode.OK)

    def test_create_multimedia_chat_message2(self):
        self.login('alice')

        test_file = '%s/exim-filter.pdf' % self.test_files_dir
        test_bfs_file = \
            self._prepare_bfs_file(self.users['alice'].id, self.orgs['ibm'].id, test_file)

        data = {
            'type': Message.TYPE_MULTIMEDIA_CHAT_CREATED,
            'dests': [{'type': DestType.ORG_MEMBER, 'id': self.users['bob'].id}],
            'body': {
                'chat': {
                    'bfs_file_id': test_bfs_file.id,
                    'name': 'hello.pdf'
                }
            }
        }
        chat_resp = self.client.post(
            '/v1/orgs/%s/messages' % self.orgs['ibm'].id, data=data, format='json')
        self.assertEqual(chat_resp.data['errcode'], ErrorCode.OK)

    def test_create_multimedia_chat_message3(self):
        self.login('alice')

        test_file = '%s/hello.m4a' % self.test_files_dir
        test_bfs_file = \
            self._prepare_bfs_file(self.users['alice'].id, self.orgs['ibm'].id, test_file)

        data = {
            'type': Message.TYPE_MULTIMEDIA_CHAT_CREATED,
            'dests': [{'type': DestType.ORG_MEMBER, 'id': self.users['bob'].id}],
            'body': {
                'chat': {
                    'bfs_file_id': test_bfs_file.id,
                    'name': 'hello.m4a'
                }
            }
        }
        chat_resp = self.client.post(
            '/v1/orgs/%s/messages' % self.orgs['ibm'].id, data=data, format='json')
        self.assertEqual(chat_resp.data['errcode'], ErrorCode.OK)

    def test_create_multimedia_chat_message4(self):
        self.login('alice')

        test_file = '%s/test.psd' % self.test_files_dir
        test_bfs_file = \
            self._prepare_bfs_file(self.users['alice'].id, self.orgs['ibm'].id, test_file)

        data = {
            'type': Message.TYPE_MULTIMEDIA_CHAT_CREATED,
            'dests': [{'type': DestType.ORG_MEMBER, 'id': self.users['bob'].id}],
            'body': {
                'chat': {
                    'bfs_file_id': test_bfs_file.id,
                    'name': 'hello.psd'
                }
            }
        }
        chat_resp = self.client.post(
            '/v1/orgs/%s/messages' % self.orgs['ibm'].id, data=data, format='json')
        self.assertEqual(chat_resp.data['errcode'], ErrorCode.OK)

    def test_share_file(self):
        self.login('alice')

        test_file = '%s/exim-filter.pdf' % self.test_files_dir
        test_bfs_file = \
            self._prepare_bfs_file(self.users['alice'].id, self.orgs['ibm'].id, test_file)

        data = {
            'name': 'new.pdf',
            'parent': 0,
            'bfs_file_id': test_bfs_file.id,
        }
        response = self.client.post(
            '/v2/orgs/%s/file/files' % (self.orgs['ibm'].id), data=data, format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.OK)

        data = {
            'type': Message.TYPE_FILES_CREATED,
            'dests': [{'type': DestType.ORG_MEMBER, 'id': self.users['bob'].id}],
            'body': {
                'files': [response.data['data']['id']]
            }
        }
        chat_resp = self.client.post(
            '/v1/orgs/%s/messages' % self.orgs['ibm'].id, data=data, format='json')
        self.assertEqual(chat_resp.data['errcode'], ErrorCode.OK)
        self.assertEqual(
            chat_resp.data['data']['body']['files'][0]['id'], response.data['data']['id'])
