from django.db.models.query import QuerySet
import simpleflake

from django.db import models
from django.db import IntegrityError

from jsonfield import JSONCharField

from common import models as _models
from common.message_queue import MessageSender

from common.utils import shard_id, current_timestamp, to_org_id
from common.const import DestType, SrcType
from django.core.cache import cache as memcache
import logging

log = logging.getLogger(__name__)


class Message(_models.BaseOrgModel):
    # Const Variables
    TYPE_INVITATION_CREATED = 0
    TYPE_INVITATION_UPDATED = 1

    TYPE_TEXT_CHAT_CREATED = 2
    TYPE_MULTIMEDIA_CHAT_CREATED = 3

    TYPE_EMAIL_CREATED = 4

    TYPE_TASK_CREATED = 5
    TYPE_TASK_UPDATED = 6

    TYPE_MESSAGE_UPDATED = 7
    TYPE_USER_UPDATED = 8
    TYPE_CONVERSATION_CREATED = 9

    TYPE_ORG_CREATED = 10
    TYPE_ORG_UPDATED = 11

    TYPE_DISCUSSION_GROUP_CREATED = 12
    TYPE_DISCUSSION_GROUP_UPDATED = 13

    TYPE_ORG_MEMBER_JOINED = 14
    TYPE_ORG_MEMBER_LEFT = 15

    TYPE_DISCUSSION_GROUP_MEMBER_JOINED = 16
    TYPE_DISCUSSION_GROUP_MEMBER_LEFT = 17

    TYPE_CONVERSATION_UPDATED = 18
    TYPE_GLOBAL_MESSAGES_UPDATED = 19

    TYPE_DISCUSSION_GROUP_DISBANDED = 20
    TYPE_CONVERSATION_DELETED = 21

    TYPE_TASK_COMMENT_CREATED = 22
    TYPE_TASK_COMMENT_DELETED = 23

    TYPE_TASK_FOLLOWER_CREATED_DISUSED = 24
    TYPE_TASK_FOLLOWER_DELETED_DISUSED = 25

    TYPE_TASK_ATTACHMENT_CREATED = 26
    TYPE_TASK_ATTACHMENT_DELETED = 27

    TYPE_PROJECT_CREATED = 28
    TYPE_PROJECT_UPDATED = 29
    TYPE_PROJECT_DELETED = 30

    TYPE_PROJECT_MEMBER_JOINED = 31
    TYPE_PROJECT_MEMBER_LEFT = 32

    TYPE_PLAN_CREATED_DISUSED = 33
    TYPE_PLAN_UPDATED_DISUSED = 34
    TYPE_PLAN_DELETED_DISUSED = 35

    TYPE_TAG_CREATED = 36
    TYPE_TAG_UPDATED = 37
    TYPE_TAG_DELETED = 38

    TYPE_TASK_DELETED = 39

    TYPE_DEPARTMENT_CREATED = 40
    TYPE_DEPARTMENT_UPDATED = 41
    TYPE_DEPARTMENT_DISBANDED = 42

    TYPE_DEPARTMENT_MEMBER_JOINED = 43
    TYPE_DEPARTMENT_MEMBER_LEFT = 44

    TYPE_USER_ONLINE = 45
    TYPE_USER_OFFLINE = 46

    TYPE_TASK_COMPLETED = 47

    TYPE_FILES_CREATED = 48

    TYPE_USER_SELF_PASSWORD_CHANGED = 49
    TYPE_OFFLINE = 50

    TYPE_ORG_MEMBER_UPDATED = 51

    TYPE_ORG_APP_UPDATED = 52
    TYPE_ORG_MEMBER_NAVI_APP_UPDATED = 53

    TYPE_MESSAGE_UNREAD_COUNT_UPDATED = 54

    TYPE_MEMBER_DEPARTMENTS_UPDATED = 55

    TYPE_VOICE_MESSAGE_UPDATED = 56

    TYPE_MESSAGES_DELETED_IN_CONVERSATION = 57
    ########################################################
    STATUS_NULL = 0
    STATUS_READ = 1
    STATUS_IGNORE = 2

    CONTENT_TYPE_SNAPSHOT = 0
    CONTENT_TYPE_RESOURCE = 1

    # instance extra attributes
    _send_to_self = True  # control whether send to self device
    _snapshot = None

    # Fields
    src_id = _models.PositiveBigIntegerField()
    src_type = models.PositiveSmallIntegerField()

    dest_id = _models.PositiveBigIntegerField()
    dest_type = models.PositiveSmallIntegerField()

    type = models.PositiveSmallIntegerField()

    content_type = models.PositiveSmallIntegerField(default=CONTENT_TYPE_SNAPSHOT)
    content = _models.PositiveBigIntegerField()

    date_added = models.PositiveIntegerField()

    resource_id = _models.PositiveBigIntegerField(default=0)

    is_sent = models.PositiveSmallIntegerField(default=0, db_index=True)

    # Methods
    def has_owner(self, user_id):
        r = UserMessage.objects \
            .using(self._state.db) \
            .filter(user_id=user_id, message_id=self.id)
        if r:
            return True

        if self.dest_type == DestType.ORG_MEMBER:
            if self.src_type == SrcType.ORG_MEMBER:
                return user_id in (self.src_id, self.dest_id)

            return user_id == self.dest_id

        from apps.account.models import User
        user = User.objects.get_or_none(id=user_id)
        if not user:
            return False

        if self.dest_type == DestType.DISCUSSION_GROUP:
            r = user.in_discussion_group(to_org_id(self._state.db), self.dest_id)
            if not r:
                return False

            return r.date_joined < self.date_added

        if self.dest_type == DestType.DEPARTMENT:
            return user.in_department(to_org_id(self._state.db), self.dest_id)

        return False

    @classmethod
    def load_by_user_messages(cls, org_id, user_messages):
        '''
        the return value is a dict that contains 'is_read', 'is_ignored', 'unread_count'
        '''
        from apps.message.utils import MessageStatus

        if isinstance(user_messages, QuerySet):
            messages_status = {k: v for k, v in user_messages.values_list('message_id', 'status')}
        else:
            messages_status = {um.message_id: um.status for um in user_messages}

        messages = Message.objects\
            .using(org_id)\
            .filter(id__in=messages_status.keys())

        message_contents = MessageContent.objects \
            .using(org_id) \
            .filter(id__in=[i.content for i in messages
                    if i.content_type == Message.CONTENT_TYPE_SNAPSHOT])
        message_contents = dict([(i.id, i) for i in message_contents])

        #  message unread count
        messages_unread_count = MessageStatus().get_unread_count(org_id, messages)

        ret = {}
        for m in messages:
            r = m.to_dict()

            if m.content_type == Message.CONTENT_TYPE_SNAPSHOT:
                r['body'] = message_contents[m.content].content
                # unread_count=-1 means not statistic for the message
                r['unread_count'] = messages_unread_count.get(m.id, -1)
            elif m.content_type == Message.CONTENT_TYPE_RESOURCE:
                r['body'] = cls._load_resource(m)
                if not r['body']:
                    continue
            else:
                raise ValueError('invalid content type')

            r['is_read'] = int(messages_status[m.id] == Message.STATUS_READ)
            r['is_ignored'] = int(messages_status[m.id] == Message.STATUS_IGNORE)

            ret[m.id] = r

        return ret

    @classmethod
    def _load_resource(cls, message):
        if message.type == Message.TYPE_INVITATION_CREATED:
            from apps.org.models import Invitation

            r = Invitation.objects.get_or_none(id=message.content)
            if not r:
                return None

            return {'invitation': r.to_dict()}

        raise ValueError('not supported yet!')

    @classmethod
    def unread_users(cls, org_id, *message_ids):
        ums = UserMessage.objects.using(shard_id(org_id))\
            .filter(message_id__in=message_ids, status=Message.STATUS_NULL)\
            .values_list('message_id', 'user_id')

        results = dict((m, []) for m in message_ids)
        for message_id, user_id in ums:
            results[message_id].append(user_id)

        return results

    def save(self, *args, **kwargs):
        if not self.pk:
            if not self.date_added:
                self.date_added = current_timestamp()

        if self.pk:
            return super(Message, self).save(*args, **kwargs)

        self.dest_id = int(self.dest_id)

        kwargs['force_insert'] = True
        for i in range(10):
            self.id = simpleflake.simpleflake()
            try:
                return super(Message, self).save(*args, **kwargs)
            except IntegrityError as e:
                continue

        raise e

    def to_dict(self):
        ret = super(Message, self).to_dict(
            exclude=['content', 'content_type', 'is_sent', 'resource_id']
        )
        ret.update(scope_org_id=self.org_id)
        return ret

    def sendout(self, data, db=None, write_db=False):
        # only TYPE_TEXT_CHAT_CREATED, TYPE_MULTIMEDIA_CHAT_CREATED use _send_to_self=Fasle
        if not self._send_to_self:
            from common.globals import get_current_session_id
            session_id = get_current_session_id()
        else:
            session_id = None

        if not write_db:
            org_id = self.org_id if db is None else to_org_id(db)
            MessageSender(self.type, data, org_id)\
                .send(src_id=self.src_id, src_type=self.src_type,
                      dest_id=self.dest_id, dest_type=self.dest_type,
                      date_added=self.date_added, message_id=self.id, session_id=session_id)
        elif not self.id:
            content_obj = MessageContent(content=data)
            content_obj.save(using=db)

            self.content = content_obj.id
            self._snapshot = content_obj.content
            self.save(using=db)
        else:
            raise RuntimeError('can not MessageContent.sendout(write_db=True) id=%s' % self.id)

    class Meta:
        db_table = 'message'
        index_together = [['type', 'resource_id']]


class UserMessage(_models.BaseOrgModel):
    user_id = _models.PositiveBigIntegerField(db_index=True)

    peer_id = _models.PositiveBigIntegerField()
    peer_type = models.PositiveSmallIntegerField()

    message_id = _models.PositiveBigIntegerField(db_index=True)
    status = models.PositiveSmallIntegerField()
    update_at = models.PositiveIntegerField(default=0)

    @property
    def is_unread(self):
        return int(self.status == Message.STATUS_NULL)

    @property
    def is_read(self):
        return int(self.status == Message.STATUS_READ)

    @property
    def is_ignored(self):
        return int(self.status == Message.STATUS_IGNORE)

    # def set_read(self):
    #     self.status = Message.STATUS_READ
    #     self.update_at = current_timestamp()
    #
    # def set_ignored(self):
    #     self.status = Message.STATUS_IGNORE
    #     self.update_at = current_timestamp()

    def save(self, force_save=False, *args, **kwargs):
        if self.id and not force_save:
            #  block user message status update unexpected
            raise RuntimeError('unexpected save UserMessage: %s' % (self.id))

        self.update_at = current_timestamp()
        super(UserMessage, self).save(*args, **kwargs)

    @property
    def conversation(self):
        return UserConversation.objects.using(self._state.db) \
            .getx(user_id=self.user_id, peer_type=self.peer_type, peer_id=self.peer_id)

    class Meta:
        db_table = 'message_user_message'


class MessageContent(_models.BaseOrgModel):
    content = JSONCharField(max_length=4096 * 16)

    class Meta:
        db_table = 'message_message_content'


class UserConversation(_models.SimpleBaseOrgModel):
    user_id = _models.PositiveBigIntegerField()

    peer_id = _models.PositiveBigIntegerField()
    peer_type = models.PositiveSmallIntegerField()

    last_message_id = _models.PositiveBigIntegerField()
    max_message_id = _models.PositiveBigIntegerField(default=0)

    unread_count = models.PositiveIntegerField()
    last_updated = models.PositiveIntegerField()
    
    is_hide = models.PositiveIntegerField(default=0)

    def to_dict0(self):
        ret = super(UserConversation, self).to_dict(exclude=['max_message_id', 'last_message_id'])
        if ret['unread_count'] < 0:
            ret['unread_count'] = 0
            log.error('UserConversation %s get negative unread count=%s'
                      % (self.id, self.unread_count))
        return ret

    def to_dict(self, last_message_id=None):
        ret = self.to_dict0()
        ret['last_message'] = {}

        message_id = last_message_id if last_message_id is not None else self.max_message_id
        if message_id:
            user_message = UserMessage.objects.using(self.org_id) \
                .filter(user_id=self.user_id, message_id=message_id)

            ret['last_message'] = Message.load_by_user_messages(self.org_id, user_message)\
                .get(message_id, {})

        return ret

    def save(self, *args, **kwargs):
        self.last_updated = current_timestamp()
        self.max_message_id = max(self.max_message_id, self.last_message_id)

        super(UserConversation, self).save(*args, **kwargs)

    @classmethod
    def find(cls, org_id, user_id, peer_type, peer_id):
        '''find and cache: conversation_id'''
        key = '-'.join(str(i) for i in [cls.__name__, org_id, user_id, peer_type, peer_id])
        c_id = memcache.get(key)
        if not c_id:
            obj = cls.objects.using(org_id) \
                .get_or_none(user_id=user_id, peer_type=peer_type, peer_id=peer_id)

            if obj:
                memcache.set(key, obj.id)
            return obj
        else:
            return cls.objects.using(org_id).get_or_none(id=c_id)

    @classmethod
    def find_by_usermessage(cls, usermessage):
        return cls.find(usermessage.org_id, usermessage.user_id,
                        usermessage.peer_type, usermessage.peer_id)

    class Meta:
        db_table = 'message_user_conversation'
        unique_together = ('user_id', 'peer_type', 'peer_id')
        index_together = [['user_id', 'last_updated']]


class UserMessageUnreadCount(_models.BaseModel):
    user_id = _models.PositiveBigIntegerField(db_index=True)
    unread_count = models.PositiveIntegerField()
    last_updated = models.PositiveIntegerField()

    def save(self, *args, **kwargs):
        self.last_updated = current_timestamp()
        super(UserMessageUnreadCount, self).save(*args, **kwargs)

    @classmethod
    def calc_unread_count(cls, user_id):
        r = UserMessageUnreadCount.objects.get_or_none(user_id=user_id)
        if not r:
            return 0

        return r.unread_count

    class Meta:
        db_table = 'message_user_message_unread_count'
