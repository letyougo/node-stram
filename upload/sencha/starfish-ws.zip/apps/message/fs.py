from apps.message.models import Message, MessageContent
from apps.fs.models import File

from common.const import SrcType
from common.utils import shard_id

import logging
log = logging.getLogger(__name__)


class FSMessageMixin(object):
    def create_fs_message(self, request, org_id, dest_type, dest_id):
        content = MessageContent(
            content={
                'files': [f.to_dict() for f in self._load_files(request, org_id)],
            },
        )
        content.save(using=shard_id(org_id))

        message = Message(
            src_type=SrcType.ORG_MEMBER,
            src_id=request.current_uid,
            dest_id=dest_id,
            dest_type=dest_type,
            content=content.id,
            type=request.DATA['type'],
        )

        message._snapshot = content.content
        message.save(using=shard_id(org_id))

        return message

    def _load_files(self, request, org_id):
        files = File.objects \
            .using(shard_id(org_id)) \
            .filter(id__in=request.DATA['body']['files'])
        if not files:
            raise ValueError('no files')

        for f in files:
            if not f.has_owner(request.current_user):
                raise ValueError('permission denied')

        return files
