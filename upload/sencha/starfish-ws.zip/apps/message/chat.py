import re
import os
import math
import html
import audioread

from django.conf import settings

from apps.bfs.models import BfsFile
from apps.chat.models import MultimediaChat, TextChat
from apps.message.models import Message, MessageContent

from common.const import SrcType
from common.utils import (
    shard_id, calc_thumbnail_size, detect_mime_type,
    openImage, check_bfs_file_permission)

import logging
log = logging.getLogger(__name__)


class ChatMessageMixin(object):
    def create_chat_message(self, request, org_id, dest_type, dest_id):
        chat = None
        send_to_self = True
        # multimedia chat
        if 'bfs_file_id' in request.DATA['body']['chat']:
            send_to_self = False
            chat = self._create_multimedia_chat(
                request, org_id, dest_type, dest_id, request.DATA['body']['chat']['bfs_file_id'])

        # text chat
        if 'content' in request.DATA['body']['chat']:
            send_to_self = False
            chat = self._create_text_chat(
                request, org_id, dest_type, dest_id, request.DATA['body']['chat']['content'])

        # re-transfer chat
        if 'id' in request.DATA['body']['chat']:
            chat = self._create_ref_chat(
                request, org_id, dest_type, dest_id, request.DATA['body']['chat']['id'])

        if not chat:
            raise ValueError('invalid args, no content and no files')

        content = MessageContent(
            content={'chat': chat.to_dict()},
        )
        content.save(using=shard_id(org_id))

        message = Message(
            src_type=SrcType.ORG_MEMBER,
            src_id=request.current_uid,
            dest_type=dest_type,
            dest_id=dest_id,
            content=content.id,
            resource_id=chat.id,
            type=request.DATA['type'],
        )

        message._snapshot = content.content
        message._send_to_self = send_to_self
        message.save(using=shard_id(org_id))

        return message

    def _create_text_chat(self, request, org_id, dest_type, dest_id, content):
        content = html.escape(content)
        if not re.sub(r'[\s　]+', '', content):
            raise ValueError('emtpy content')

        chat = TextChat(
            src_id=request.current_uid,
            src_type=SrcType.ORG_MEMBER,
            dest_id=dest_id,
            dest_type=dest_type,
            content=content,
        )
        chat.save(using=shard_id(org_id))

        return chat

    def _create_multimedia_chat(self, request, org_id, dest_type, dest_id, bfs_file_id):
        bfs_file = BfsFile.get(request.DATA['body']['chat']['bfs_file_id'], org_id)
        if not bfs_file:
            raise ValueError('invalid args, no bfs file')

        r = check_bfs_file_permission(request.current_uid, org_id, bfs_file)
        if r:
            raise ValueError('permission denied')

        filename = request.DATA['body']['chat']['name']
        filepath = bfs_file.filepath
        chat = MultimediaChat(
            src_id=request.current_uid,
            src_type=SrcType.ORG_MEMBER,
            dest_id=dest_id,
            dest_type=dest_type,
            meta={},
            filepath=filepath
        )

        mimetype = detect_mime_type(MultimediaChat.full_path(chat.filepath))
        mimetype = self._fix_audio_mime_type(mimetype, filename)

        _meta = {
            'name': filename,
            'size': os.path.getsize(MultimediaChat.full_path(chat.filepath)),
            'mimetype': mimetype,
        }

        if mimetype in ('audio/mp4', ):
            audio = audioread.audio_open(MultimediaChat.full_path(chat.filepath))
            length = int(math.ceil(audio.duration))
            audio.close()
            if not length:
                raise ValueError('empty audio.')
            _meta.update(length=length)

        elif mimetype.startswith('image/'):
            try:
                image = openImage(MultimediaChat.full_path(chat.filepath), mimetype)
                self._append_thumb_info(_meta, image.size)
                image.close()
            except Exception as e:
                log.warning('can not open image %s, %s' % (mimetype, e))
                _meta['mimetype'] = "application/octet-stream"

        chat.meta.update(_meta)
        chat.save(using=shard_id(org_id))

        return chat

    def _create_ref_chat(self, request, org_id, dest_type, dest_id, id_):
        _type = int(request.DATA['type'])
        if _type not in (Message.TYPE_TEXT_CHAT_CREATED, Message.TYPE_MULTIMEDIA_CHAT_CREATED):
            raise ValueError('invalid chat type')

        if _type == Message.TYPE_TEXT_CHAT_CREATED:
            _r = TextChat.objects \
                .using(shard_id(org_id)) \
                .get_or_none(id=id_)
            if not _r:
                raise ValueError('invalid chat id')

            if not _r.has_owner(request.current_user):
                raise ValueError('permission denied')

            r = TextChat(
                src_id=request.current_uid,
                src_type=SrcType.ORG_MEMBER,
                dest_id=dest_id,
                dest_type=dest_type,
                content=_r.content,
            )
            r.save(using=shard_id(org_id))
            return r

        if _type == Message.TYPE_MULTIMEDIA_CHAT_CREATED:
            _r = MultimediaChat.objects \
                .using(shard_id(org_id)) \
                .get_or_none(id=id_)
            if not _r:
                raise ValueError()

            if not _r.has_owner(request.current_user):
                raise ValueError('permission denied')

            r = MultimediaChat(
                src_id=request.current_uid,
                src_type=SrcType.ORG_MEMBER,
                dest_id=dest_id,
                dest_type=dest_type,
                meta=_r.meta,
                filepath=_r.filepath
            )
            r.save(using=shard_id(org_id))

            return r

    def _fix_audio_mime_type(self, mimetype, name):
        if mimetype == 'video/mp4' and name[-4:] == '.m4a':
            return 'audio/mp4'

        return mimetype

    def _append_thumb_info(self, meta, image_size):
        meta.update({'thumbs': {}})
        for k, v in list(settings.IMAGE_RESIZE_SPEC.items()):
            w, h = calc_thumbnail_size(
                image_size[0], image_size[1], v[0], v[1])
            meta['thumbs'][k] = {'width': w, 'height': h}
