from apps.project.models import Task
from apps.message.models import Message, MessageContent

from common.const import SrcType
from common.utils import shard_id


class TaskMessageMixin(object):
    def create_task_message(self, request, org_id, dest_type, dest_id):
        # TODO check permission
        task = Task.objects \
            .using(shard_id(org_id)) \
            .get_or_none(id=request.DATA['body']['task']['id'])

        if not task:
            raise ValueError('no such task.')

        type_ = int(request.DATA['type'])
        if type_ not in (Message.TYPE_TASK_CREATED, Message.TYPE_TASK_COMPLETED):
            raise ValueError()

        if type_ == Message.TYPE_TASK_CREATED:
            return self._create_task_created_message(request, dest_type, dest_id, task)

        if type_ == Message.TYPE_TASK_COMPLETED:
            return self._create_task_completed_message(request, dest_type, dest_id, task)

    def _create_task_created_message(self, request, dest_type, dest_id, task):
        content = MessageContent(
            content={'task': task.to_dict(), 'operator': request.current_user.to_dict()},
        )
        content.save(using=task._state.db)

        message = Message(
            src_type=SrcType.ORG_MEMBER,
            src_id=request.current_uid,
            dest_type=dest_type,
            dest_id=dest_id,
            content=content.id,
            resource_id=task.id,
            type=Message.TYPE_TASK_CREATED,
        )

        message._snapshot = content.content
        message.save(using=task._state.db)

        return message

    def _create_task_completed_message(self, request, dest_type, dest_id, task):
        content = MessageContent(
            content={'task': task.to_dict()},
        )
        content.save(using=task._state.db)

        message = Message(
            src_type=SrcType.ORG_MEMBER,
            src_id=request.current_uid,
            dest_type=dest_type,
            dest_id=dest_id,
            content=content.id,
            resource_id=task.id,
            type=Message.TYPE_TASK_COMPLETED,
        )

        message._snapshot = content.content
        message.save(using=task._state.db)

        return message
