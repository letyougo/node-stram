import json
import os
import hashlib
import unittest

from email.utils import COMMASPACE

from apps.bfs.models import BfsFile
from apps.mail.models import (
    MailMetadata, MailAttachment, MailContent,
    Direction)
from apps.mail import utils

from common.const import ErrorCode, SrcType
from common.utils import shard_id, to_str
from common.tests import TestCase


class SimpleTest(TestCase):
    test_files_dir = '%s/test-files' % os.path.dirname(os.path.abspath(__file__))

    def test_mail_attachment_limit(self):
        self.login('bob')
        # make a 6M size file
        filepath = self.get_tmp_file()
        s = ''.join(('0' for i in range(6*1024*1024)))
        f = open(filepath, 'wb')
        f.write(s.encode())
        f.close()

        bfs = self._prepare_bfs_file(self.users['bob'].id, self.orgs['ibm'].id, filepath)

        data = {'to': ['bitbrothers_test1@163.com'],
                'cc': [],
                'bcc': [],
                'subject': self.rand_string(),
                'content': self.rand_string(),
                'action_type': 0,
                'attachments': [{"bfs_file_id": bfs.id, "name": "big.txt"}],
                }

        response = self.client.post(
            '/v1/orgs/%s/mail/mails' % (self.orgs['ibm'].id), data=data, format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.ATTACHMENT_EXCEED_LIMIT)

    def test_mail_body_limit(self):
        self.login('bob')
        # make a 3M size file
        filepath = self.get_tmp_file()
        s = ''.join(('0' for i in range(3*1024*1024)))
        f = open(filepath, 'wb')
        f.write(s.encode())
        f.close()

        bfs = self._prepare_bfs_file(self.users['bob'].id, self.orgs['ibm'].id, filepath)

        data = {'to': ['bitbrothers_test1@163.com'],
                'cc': [],
                'bcc': [],
                'subject': self.rand_string(),
                'content': s,  # make a 3M size content
                'action_type': 0,
                'attachments': [{"bfs_file_id": bfs.id, "name": "big.txt"}],
                }

        response = self.client.post(
            '/v1/orgs/%s/mail/mails' % (self.orgs['ibm'].id), data=data, format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.MAIL_BODY_SIZE_EXCEED_LIMIT)

    def test_reply_mail_reply_to_permission_denied(self):
        self.login('alice')

        r = utils.MailStorage(
            open('%s/test-mail2.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()
        data = {'to': ['bitbrothers_test1@163.com'],
                'cc': [],
                'bcc': [],
                'subject': list(r.values())[0].meta['subject'],
                'content': self.rand_string(),
                'reply_to': list(r.values())[0].id}
        response = self.client.post(
            '/v1/orgs/%s/mail/mails' % (self.orgs['ibm'].id), data=data)
        self.assertEqual(response.data['errcode'], ErrorCode.PERMISSION_DENIED)

    def test_mail_references(self):
        r3 = utils.MailStorage(
            open('%s/test-mail-ref3.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()
        r2 = utils.MailStorage(
            open('%s/test-mail-ref2.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()
        r1 = utils.MailStorage(
            open('%s/test-mail-ref1.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()

        expected = [list(r3.values())[0].message_id, list(r2.values())[0].message_id]
        self.assertEqual([i for i in list(r1.values())[0].get_refs_message_ids()], expected)

    def test_same_subject(self):
        self.assertTrue(utils.same_subjects('hello', 'hello'))
        self.assertFalse(utils.same_subjects('hello', 'hello, moto'))

        self.assertTrue(utils.same_subjects('hello', 'Re: hello'))
        self.assertTrue(utils.same_subjects('Re: hello', 'hello'))

        self.assertTrue(utils.same_subjects('hello', 'Re: Re: hello'))
        self.assertTrue(utils.same_subjects('Re: Re: hello', 'hello'))

    def test_build_mail(self):
        r = utils.MailStorage(
            open('%s/test-mail2.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()

        kwargs = {
            'sender': 'bob@starfish.im',
            'to': ['bitbrothers_test1@163.com', 'bitbrothers_test3@163.com'],
            'cc': ['bitbrothers_test2@163.com', 'bitbrothers_test4@163.com'],
            'subject': '中文abc',
            'content': '中文abc',
            'reply_to_mail': list(r.values())[0],
            'files': [
                {'name': 'hello.txt',
                 'fullpath': BfsFile.full_path(
                     self._prepare_bfs_file(
                         self.users['bob'].id,
                         self.orgs['ibm'].id,
                         '%s/test-mail-attach1.txt' % SimpleTest.test_files_dir).filepath)},
                {'name': 'moto.txt',
                 'fullpath': BfsFile.full_path(
                     self._prepare_bfs_file(
                         self.users['bob'].id,
                         self.orgs['ibm'].id,
                         '%s/test-mail-attach2.txt' % SimpleTest.test_files_dir).filepath)},
            ]
        }

        mail = utils.build_mail(**kwargs)
        txt_part = mail.get_payload()[0]
        self.assertEqual(txt_part.get_payload()[0].get_content_charset(), 'utf8')
        self.assertEqual(txt_part.get_payload()[1].get_content_charset(), 'utf8')

        self.assertEqual(mail['From'], kwargs['sender'])
        self.assertEqual(len(mail['Subject']._chunks), 1)
        self.assertEqual(mail['Subject']._chunks[0][0], to_str(kwargs['subject']))
        self.assertEqual(mail['To'], COMMASPACE.join(kwargs['to']))
        self.assertEqual(mail['Cc'], COMMASPACE.join(kwargs['cc']))
        self.assertIsNotNone(mail['Message-ID'])
        self.assertEqual(
            txt_part.get_payload()[0].get_payload(decode=True),
            to_str(kwargs['content']).encode('utf8'))

        self.assertEqual(
            mail.get_payload()[1].get_payload(decode=True),
            open('%s/test-mail-attach1.txt' % SimpleTest.test_files_dir, 'rb').read())
        self.assertEqual(
            mail.get_payload()[2].get_payload(decode=True),
            open('%s/test-mail-attach2.txt' % SimpleTest.test_files_dir, 'rb').read())

    def test_store_mail(self):
        r = utils.MailStorage(
            open('%s/test-mail.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()
        self.assertEqual(len(r), 1)

        mail_metadata = r[self.orgs['ibm'].default_domain_name]
        # check mail meta
        meta = {
            'action_type': 0,
            'others': ['zenglu.liu@gmail.com'],
            'cc': [],
            'to': set(['eve@ibm.starfish.im', 'bob@ibm.starfish.im']),
            'from': 'lixin@hello.moto.com',
            'subject': 'Re: ab31d5d7-93e6-4c88-8e96-6ce40500928f'
        }
        self.assertEqual(
            mail_metadata.message_id,
            '<CACs9NPCzKBoVK+vh-M0ME0Ge7mzrZ950sZ8uSgHst_zNHNdbWQ@mail.gmail.com>')
        self.assertEqual(
            mail_metadata.identity.hash,
            hashlib.md5(mail_metadata.message_id.encode('utf8')).digest())

        self.assertEqual(mail_metadata.meta['from_detail']['type'], SrcType.GENERATED_CONTACT)
        del mail_metadata.meta['from_detail']

        mail_metadata.meta['to'] = set(mail_metadata.meta['to'])
        self.assertEqual(mail_metadata.meta, meta)
        self.assertEqual(mail_metadata.date, 1366030328.0)

        # check original mail
        content = None
        with open('%s/test-mail.txt' % SimpleTest.test_files_dir, 'rb') as f:
            content = f.read()

        self.assertEqual(MailMetadata.load_file(mail_metadata.filepath), content)

    def test_store_mail_content_and_attachment(self):
        r = utils.MailStorage(
            open('%s/test-mail3.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()

        mail_contents = MailContent.objects \
            .using(shard_id(self.orgs['ibm'].id)) \
            .filter(mail_id=list(r.values())[0].id)

        self.assertEqual(len(mail_contents), 2)

        self.assertEqual(mail_contents[0].content, 'moto\n\nfoobar\n')
        self.assertEqual(mail_contents[0].content_type, MailContent.CONTENT_TYPE_TEXT_PLAIN)
        self.assertEqual(
            mail_contents[1].content,
            '<div dir="ltr"><div>moto<br><br></div>foobar<br><br><br>\n</div>\n')
        self.assertEqual(mail_contents[1].content_type, MailContent.CONTENT_TYPE_TEXT_HTML)

        mail_attachments = MailAttachment.objects \
            .using(shard_id(self.orgs['ibm'].id)) \
            .filter(mail_id=list(r.values())[0].id)

        self.assertEqual(len(mail_attachments), 2)

        self.__file_equals('房间v1.png', mail_attachments[0])
        self.__file_equals('exim-filter.pdf', mail_attachments[1])

    def test_store_mail_content_chinese(self):
        r = utils.MailStorage(
            open('%s/test-mail5.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()

        mail_contents = MailContent.objects \
            .using(shard_id(self.orgs['ibm'].id)) \
            .filter(mail_id=list(r.values())[0].id)

        self.assertEqual(len(mail_contents), 2)

        self.assertEqual(mail_contents[0].content, 'hello 中文\r\n')
        self.assertEqual(mail_contents[0].content_type, MailContent.CONTENT_TYPE_TEXT_PLAIN)
        self.assertEqual(
            mail_contents[1].content,
            '<div dir="ltr">hello 中文<br></div>\n')
        self.assertEqual(mail_contents[1].content_type, MailContent.CONTENT_TYPE_TEXT_HTML)

    def __file_equals(self, fn, attachment):
        self.assertEqual(fn, attachment.filename)

        content = open('%s/%s' % (SimpleTest.test_files_dir, fn), 'rb').read()
        self.assertEqual(len(content), attachment.filesize)
        self.assertEqual(content, MailAttachment.load_file(attachment.filepath))

    def test_store_mail_zh_cn(self):
        r = utils.MailStorage(
            open('%s/test-mail4.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()
        self.assertEqual(list(r.values())[0].meta['subject'], '啊哈哈哈')

        mail_contents = MailContent.objects \
            .using(shard_id(self.orgs['ibm'].id)) \
            .filter(mail_id=list(r.values())[0].id)

        self.assertEqual(len(mail_contents), 1)
        self.assertEqual(mail_contents[0].content_type, MailContent.CONTENT_TYPE_TEXT_PLAIN)
        self.assertEqual(mail_contents[0].content, '哈哈')

    @unittest.skip("testing skipping")
    def test_fetch_mail_attachment_ok(self):
        r = utils.MailStorage(
            open('%s/test-mail3.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()
        mail_metadata = list(r.values())[0]

        mail_attachments = MailAttachment.objects \
            .using(shard_id(self.orgs['ibm'].id)) \
            .filter(mail_id=mail_metadata.id)

        self.login('bob')

        response = self.client.get(
            '/v1/orgs/%s/mail/mails/%s/attachments/%s' %
            (self.orgs['ibm'].id, mail_metadata.id, mail_attachments[0].id))

        self.assertEqual(response.get('Content-Type'), 'image/png')
        self.assertEqual(
            int(response.get('Content-Length')), mail_attachments[0].filesize)
        self.assertEqual(
            response.content, MailAttachment.load_file(mail_attachments[0].filepath))

        response = self.client.get(
            '/v1/orgs/%s/mail/mails/%s/attachments/%s' %
            (self.orgs['ibm'].id, mail_metadata.id, mail_attachments[1].id))

        self.assertEqual(response.get('Content-Type'), 'application/pdf')
        self.assertEqual(
            response.get('Content-Disposition'),
            "attachment; filename*=UTF-8''exim-filter.pdf")
        self.assertEqual(
            int(response.get('Content-Length')), mail_attachments[1].filesize)
        self.assertEqual(
            response.content, MailAttachment.load_file(mail_attachments[1].filepath))

    def test_fetch_mail_attachment_no_such_mail(self):
        self.login('bob')

        no_such_mail_id = 11111
        no_such_mail_attachment_id = 1231312
        response = self.client.get(
            '/v1/orgs/%s/mail/mails/%s/attachments/%s' %
            (self.orgs['ibm'].id, no_such_mail_id, no_such_mail_attachment_id))

        ret = json.loads(response.content.decode('utf8'))
        self.assertEqual(ret['errcode'], ErrorCode.PERMISSION_DENIED)

    @unittest.skip("testing skipping")
    def test_fetch_mail_attachment_no_such_attachment(self):
        self.login('bob')

        r = utils.MailStorage(
            open('%s/test-mail3.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()
        mail_metadata = list(r.values())[0]

        no_such_mail_attachment_id = 1231312
        response = self.client.get(
            '/v1/orgs/%s/mail/mails/%s/attachments/%s' %
            (self.orgs['ibm'].id, mail_metadata.id, no_such_mail_attachment_id))

        ret = json.loads(str(response.content, 'utf8'))
        self.assertEqual(ret['errcode'], ErrorCode.NO_SUCH_EMAIL_ATTACHMENT)

    def test_fetch_mail_attachment_permission_denied(self):
        self.login('alice')

        r = utils.MailStorage(
            open('%s/test-mail3.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()
        mail_metadata = list(r.values())[0]

        mail_attachments = MailAttachment.objects \
            .using(shard_id(self.orgs['ibm'].id)) \
            .filter(mail_id=mail_metadata.id)

        response = self.client.get(
            '/v1/orgs/%s/mail/mails/%s/attachments/%s' %
            (self.orgs['ibm'].id, mail_metadata.id, mail_attachments[0].id))

        self.assertEqual(response['content-type'], 'application/json')

        ret = json.loads(str(response.content, 'utf8'))
        self.assertEqual(ret['errcode'], ErrorCode.PERMISSION_DENIED)

    @unittest.skip("testing skipping")
    def test_mails_list(self):
        utils.MailStorage(
            open('%s/test-mail-ref3.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()
        utils.MailStorage(
            open('%s/test-mail-ref2.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()
        utils.MailStorage(
            open('%s/test-mail-ref1.txt' % SimpleTest.test_files_dir, encoding='utf-8').read()
        ).save()

        self.login('bob')

        response = self.client.get(
            '/v1/orgs/%s/members/%s/mail/subjects' %
            (self.orgs['ibm'].id, self.users['bob'].id), format='json'
        )
        self.assertEqual(response.data['errcode'], ErrorCode.OK)

        self.assertEqual(response.data['data'][0]['direction'], Direction.BOTH)
        self.assertEqual(response.data['data'][0]['user_id'], self.users['bob'].id)
        self.assertEqual(response.data['data'][0]['id'], 1)
        self.assertEqual(response.data['data'][0]['last_mail_id'], 3)
        self.assertEqual(response.data['data'][0]['is_read'], 0)
        self.assertEqual(response.data['data'][0]['is_deleted'], 0)

        # set is_read = 1
        response = self.client.patch(
            '/v1/orgs/%s/mail/mails/%s' % (self.orgs['ibm'].id, 1),
            data={'is_read': 1}, format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.OK)

        response = self.client.patch(
            '/v1/orgs/%s/mail/mails/%s' % (self.orgs['ibm'].id, 2),
            data={'is_read': 1}, format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.OK)

        response = self.client.patch(
            '/v1/orgs/%s/mail/mails/%s' % (self.orgs['ibm'].id, 3),
            data={'is_read': 1}, format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.OK)

        response = self.client.get(
            '/v1/orgs/%s/members/%s/mail/subjects' %
            (self.orgs['ibm'].id, self.users['bob'].id), format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.OK)

        self.assertEqual(response.data['data'][0]['direction'], Direction.BOTH)
        self.assertEqual(response.data['data'][0]['user_id'], self.users['bob'].id)
        self.assertEqual(response.data['data'][0]['id'], 1)
        self.assertEqual(response.data['data'][0]['last_mail_id'], 3)
        self.assertEqual(response.data['data'][0]['is_read'], 1)
        self.assertEqual(response.data['data'][0]['is_deleted'], 0)

        # delete mail
        response = self.client.delete(
            '/v1/orgs/%s/mail/mails/%s' % (self.orgs['ibm'].id, 1), format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.OK)

        response = self.client.delete(
            '/v1/orgs/%s/mail/mails/%s' % (self.orgs['ibm'].id, 2), format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.OK)

        response = self.client.delete(
            '/v1/orgs/%s/mail/mails/%s' % (self.orgs['ibm'].id, 3), format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.OK)

        response = self.client.get(
            '/v1/orgs/%s/members/%s/mail/subjects' %
            (self.orgs['ibm'].id, self.users['bob'].id), format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.OK)
        self.assertEqual(len(response.data['data']), 0)
