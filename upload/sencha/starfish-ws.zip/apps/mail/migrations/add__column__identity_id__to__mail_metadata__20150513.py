db = 'org'
sql = """
alter table mail_metadata add column "identity_id" bigint NOT NULL default 0;
CREATE INDEX "mail_metadata_identity_id" ON "mail_metadata" ("identity_id");
"""
