db = 'org'
sql = """
CREATE TABLE "mail_message_id" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "message_id" varchar(128) NOT NULL,
    "hash" bytea NOT NULL
);
CREATE TABLE "mail_metadata_references" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "from_mailmetadata_id" bigint NOT NULL,
    "to_mailmetadata_id" bigint NOT NULL,
    UNIQUE ("from_mailmetadata_id", "to_mailmetadata_id")
);

CREATE INDEX "mail_message_id_hash" ON "mail_message_id" ("hash");
CREATE INDEX "mail_metadata_references_from_mailmetadata_id" ON "mail_metadata_references" ("from_mailmetadata_id");
CREATE INDEX "mail_metadata_references_to_mailmetadata_id" ON "mail_metadata_references" ("to_mailmetadata_id");

"""