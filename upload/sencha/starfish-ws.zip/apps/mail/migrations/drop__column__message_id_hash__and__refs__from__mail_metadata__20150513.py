db = 'org'
# sql = """
# ALTER TABLE mail_metadata DROP COLUMN "message_id_hash";
# ALTER TABLE mail_metadata DROP COLUMN "refs";
# ALTER TABLE mail_metadata DROP COLUMN "message_id";
# """
