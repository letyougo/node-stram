import itertools

from django.db.models import Q
from django.dispatch import Signal
from django.db.models.signals import post_save
from django.dispatch.dispatcher import receiver

from apps.message.models import Message, MessageContent
from apps.org.models import WorkMail, Department, UserDiscussionGroup, GeneratedContact
from apps.mail.models import (MailMetadata, UserMail, UserSubject, Direction)

from common.const import DestType, SrcType

import logging
log = logging.getLogger(__name__)


def on_mail_saved(sender, **kwargs):
    _save_user_mail(kwargs['metadata'])


def _save_user_mail(metadata):
    if metadata.meta['from_detail']['type'] == SrcType.ORG_MEMBER:
        user_id = metadata.meta['from_detail']['value']['id']
        UserMail.save_skip_self_outgoing(
            metadata=metadata,
            user_id=user_id,
            mail_id=metadata.id,
            subject_id=_calc_subject_id(metadata, user_id),
            direction=Direction.OUTGOING,
            is_read=1,
        )

    for addr in set(itertools.chain(
            metadata.meta['to'], metadata.meta['cc'], metadata.meta['others'])):
        r = WorkMail.find(addr)
        if not r:
            continue

        if r.owner_type not in \
                (WorkMail.TYPE_ORG_MEMBER,
                 WorkMail.TYPE_DEPARTMENT,
                 WorkMail.TYPE_DISCUSSION_GROUP):
            raise ValueError('invalid owner type')

        user_id_list = []

        if r.owner_type == WorkMail.TYPE_ORG_MEMBER:
            user_id_list.append(r.owner)
        elif r.owner_type == WorkMail.TYPE_DEPARTMENT:
            user_id_list += Department.user_ids(metadata.org_id, r.owner)
        elif r.owner_type == WorkMail.TYPE_DISCUSSION_GROUP:
            user_id_list += UserDiscussionGroup.user_ids(metadata.org_id, r.owner)

        for user_id in user_id_list:
            UserMail.save_skip_self_outgoing(
                metadata=metadata,
                user_id=user_id,
                mail_id=metadata.id,
                subject_id=_calc_subject_id(metadata, user_id),
                direction=Direction.INCOMING,
                is_read=0,
            )

        # if mail comes from generated contact, add all recipients' user-contact-relation
        if metadata.meta['from_detail']['type'] == SrcType.GENERATED_CONTACT:
            contact_id = metadata.meta['from_detail']['value']['id']
            GeneratedContact.objects\
                .using(metadata.org_id)\
                .get_or_none(id=contact_id)\
                .add_users(*user_id_list)


@receiver(post_save, sender=UserMail)
def update_user_subject(sender, instance, **kwargs):
    if kwargs['created'] and not instance.subject_id:
        _update_user_subject0(sender, instance, **kwargs)
    else:
        _update_user_subject1(sender, instance, **kwargs)


def _update_user_subject0(sender, instance, **kwargs):
    UserSubject(
        user_id=instance.user_id,
        subject_id=instance.mail_id,
        last_mail_id=instance.mail_id,
        direction=instance.direction,
        is_read=instance.is_read,
        is_deleted=instance.is_deleted
    ).save(using=instance._state.db)


def _update_user_subject1(sender, instance, **kwargs):
    subject_id = instance.subject_id if instance.subject_id else instance.mail_id

    subjects = UserSubject.objects \
        .using(instance._state.db) \
        .filter(user_id=instance.user_id, subject_id=subject_id) \
        .order_by('id')
    if not subjects:
        log.warning('can not find user subject: %s@%s', instance.id, instance._state.db)
        return

    subject = subjects[0]

    subject.last_mail_id = max(subject.last_mail_id, instance.mail_id)
    subject.direction = subject.direction | instance.direction

    cnt = UserMail.objects \
        .using(instance._state.db) \
        .filter(user_id=instance.user_id) \
        .filter(Q(mail_id=subject_id, subject_id=0) | Q(subject_id=subject_id)) \
        .filter(is_read=0) \
        .count()
    subject.is_read = 0 if cnt else 1

    cnt = UserMail.objects \
        .using(instance._state.db) \
        .filter(user_id=instance.user_id) \
        .filter(Q(mail_id=subject_id, subject_id=0) | Q(subject_id=subject_id)) \
        .count()
    subject.is_deleted = 0 if cnt else 1

    subject.save(using=instance._state.db)


def _calc_subject_id(mail_metadata, user_id):
    if mail_metadata._new_subject:
        return 0

    # user = User.objects.get_or_none(id=user_id)
    ref_mails = mail_metadata.references.all().order_by('id')
    for m in ref_mails:
        if m.has_owner(user_id):
            return m.id

    return 0


@receiver(post_save, sender=UserMail)
def save_user_mail_message(sender, instance, **kwargs):
    if not hasattr(instance, '_metadata') or not kwargs['created']:
        return

    metadata, contents, attachments = \
        instance._metadata, instance._metadata._contents, instance._metadata._attachments
    if metadata.message_has_sent():
        return

    src_type, src_id = \
        metadata.meta['from_detail']['type'], metadata.meta['from_detail']['value']['id']

    addr_list = set(
        itertools.chain(
            metadata.meta['to'], metadata.meta['cc'], metadata.meta['others']
        )
    )
    if not (src_type == SrcType.ORG_MEMBER and src_id == instance.user_id):
        addr_list.add(metadata.meta['from'])

    message_content = _save_mail_message_content(metadata, contents, attachments)
    for addr in addr_list:
        r = WorkMail.find(addr)
        if not r:
            continue

        # alice@A.com -> bob@B.com
        if r._state.db != metadata._state.db:
            continue

        dest_type, dest_id = _extract_dest(r)

        message = Message(
            src_type=src_type,
            src_id=src_id,
            dest_type=dest_type,
            dest_id=dest_id,
            type=Message.TYPE_EMAIL_CREATED,
            content=message_content.id,
            resource_id=metadata.id,
        )

        message._snapshot = message_content.content

        message.save(using=metadata._state.db)

    metadata.message_has_sent(True)


def _save_mail_message_content(metadata, contents, attachments):
    content = MessageContent(
        content={
            'email': {
                'id': metadata.id,
                'meta': metadata.meta,
                'date': metadata.date,
                'contents': [],  # [i.to_dict() for i in contents],
                'attachments': [],  # [i.to_dict() for i in attachments],
            }
        },
    )
    content.save(using=metadata._state.db)

    return content


def _extract_dest(work_mail):
    if work_mail.owner_type == WorkMail.TYPE_ORG_MEMBER:
        dest_type, dest_id = DestType.ORG_MEMBER, work_mail.owner
    elif work_mail.owner_type == WorkMail.TYPE_DISCUSSION_GROUP:
        dest_type, dest_id = DestType.DISCUSSION_GROUP, work_mail.owner
    elif work_mail.owner_type == WorkMail.TYPE_DEPARTMENT:
        dest_type, dest_id = DestType.DEPARTMENT, work_mail.owner
    else:
        raise ValueError('invalid work_mail: %s', work_mail.to_dict())

    return (dest_type, dest_id)


mail_saved = Signal(providing_args=["metadata"])
mail_saved.connect(on_mail_saved)
