from common.tests import TestCase


class SimpleTest(TestCase):
    pass
