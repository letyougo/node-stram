db = 'org'
sql = """
CREATE TABLE "project_task_operation" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "task_id" bigint NOT NULL,
    "operator" bigint NOT NULL,
    "create_time" timestamp with time zone NOT NULL,
    "operation_code" integer CHECK ("operation_code" >= 0) NOT NULL,
    "content" json
);
CREATE INDEX "project_task_operation_task_id" ON "project_task_operation" ("task_id");
"""