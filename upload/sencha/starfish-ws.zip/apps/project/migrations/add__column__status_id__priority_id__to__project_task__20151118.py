db = 'org'
sql = """
alter table project_task add column "status_id" integer;
alter table project_task add column "priority_id" integer;

CREATE INDEX "project_task_status_id" ON "project_task" ("status_id");
CREATE INDEX "project_task_priority_id" ON "project_task" ("priority_id");
"""
