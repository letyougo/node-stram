db = 'org'
sql = """
CREATE INDEX "project_task_tag_task_id" ON "project_task_tag" ("task_id");
"""