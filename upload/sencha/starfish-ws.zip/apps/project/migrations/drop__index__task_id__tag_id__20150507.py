db = 'org'
sql = """
drop index project_task_tag_task_id_tag_id;
"""
