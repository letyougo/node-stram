db = 'org'
sql = """
alter table project_task_stat add column "timestamp" date;
ALTER TABLE project_task_stat  DROP CONSTRAINT project_task_stat_user_id_project_id_key;
"""
