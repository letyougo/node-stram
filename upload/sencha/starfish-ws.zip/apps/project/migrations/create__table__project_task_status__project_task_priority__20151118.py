db = 'org'
sql = """
CREATE TABLE "project_task_status" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "is_deleted" smallint CHECK ("is_deleted" >= 0) NOT NULL,
    "create_time" timestamp with time zone,
    "update_time" timestamp with time zone,
    "project_id" bigint NOT NULL,
    "name" varchar(128) NOT NULL,
    "is_system" integer CHECK ("is_system" >= 0) NOT NULL,
    "order" integer CHECK ("order" >= 0) NOT NULL
)
;
CREATE TABLE "project_task_priority" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "is_deleted" smallint CHECK ("is_deleted" >= 0) NOT NULL,
    "create_time" timestamp with time zone,
    "update_time" timestamp with time zone,
    "project_id" bigint NOT NULL,
    "name" varchar(128) NOT NULL,
    "is_system" integer CHECK ("is_system" >= 0) NOT NULL,
    "color" integer CHECK ("color" >= 0) NOT NULL,
    "order" integer CHECK ("order" >= 0) NOT NULL
)
;

CREATE INDEX "project_task_status_order" ON "project_task_status" ("order");
CREATE INDEX "project_task_priority_order" ON "project_task_priority" ("order");
"""