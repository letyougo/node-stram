from django.conf.urls import patterns, url

from apps.account import views
from apps.acl.models import SystemRole

users_list = views.UserViewSet.as_view({
    'post': ('create', SystemRole.GUEST),
    'get': ('search', SystemRole.GUEST)
})

user_detail = views.UserViewSet.as_view({
    'get': 'retrieve',
    'patch': ('partial_update', SystemRole.USER_SELF),
    'delete': ('destroy', SystemRole.USER_SELF)
})

user_summary = views.UserViewSet.as_view({
    'get': 'retrieve_summary',
})

user_self = views.UserViewSet.as_view({
    'get': 'retrieve_self',
    'patch': ('partial_update_self', SystemRole.GUEST)
})

invite = views.UserViewSet.as_view({
    'get': ('invite', SystemRole.GUEST),
    'post': ('invite', SystemRole.GUEST)
})

user_orgs = views.UserViewSet.as_view({
    'get': ('user_orgs', SystemRole.USER_SELF)
})

user_last_org = views.UserViewSet.as_view({
    'patch': ('update_last_org', SystemRole.USER_SELF)
})

user_agents = views.AgentViewSet.as_view({
    'get': 'list_by_user',
})

agent_detail = views.AgentViewSet.as_view({
    'patch': 'partial_update',
    'delete': 'destroy',
})

sessions_list = views.SessionViewSet.as_view({
    'post': ('create', SystemRole.GUEST)
})

session_detail = views.SessionViewSet.as_view({
    'delete': ('destroy', SystemRole.GUEST)
})

tokens_list = views.TokenViewSet.as_view({
    'post': ('create', SystemRole.GUEST),
    'get': ('search', SystemRole.GUEST),
})

user_all_unread_count = views.UserViewSet.as_view({
    'get': 'get_user_all_unread_count',
})

user_reset_phone = views.UserResetPhoneViewSet.as_view({
    'get': ('get_page', SystemRole.GUEST),
    'post': ('reset_phone', SystemRole.GUEST),
})

validate_code_validate = views.ValidCodeView.as_view({
    'get': ('validate', SystemRole.GUEST),
})

user_avatar = views.UserAvatarView.as_view(SystemRole.GUEST)
validate_code_avatar = views.ValidCodeAvatarView.as_view(SystemRole.GUEST)

urlpatterns = patterns(
    '',
    url(r'^v1/invite$', invite, name='invite-page'),

    url(r'^v1/users$', users_list, name='users-list'),
    url(r'^v1/users/(?P<user_id>\d+)/orgs$', user_orgs, name='user-orgs'),
    url(r'^v1/users/(?P<user_id>\d+)/orgs/last$', user_last_org, name='user-last-org'),
    url(r'^v1/users/(?P<user_id>\d+)/messages/all_unread_count$',
        user_all_unread_count, name='user-all-unread-count'),

    url(r'^v1/users/self$', user_self, name='user-self'),
    url(r'^v1/users/(?P<user_id>[\d,]+)$', user_detail, name='user-detail'),
    url(r'^v1/user_summaries/(?P<user_id>[\d,]+)$', user_summary, name='user-detail'),

    url(r'^v1/sessions$', sessions_list, name='sessions-list'),
    url(r'^v1/sessions/self$', session_detail, name='session-self'),

    url(r'^v1/users/(?P<user_id>\d+)/agents$', user_agents, name='user-agents'),
    url(r'^v1/users/(?P<user_id>\d+)/agents/(?P<agent_key>[0-9a-f]+)$', agent_detail,
        name='agent-detail'),

    url(r'^v1/tokens$', tokens_list, name='tokens-list'),

    url(r'^v1/user-avatars/(?P<user_id>\d+)', user_avatar, name='user-avatar'),

    url(r'^v1/users/reset_phone$', user_reset_phone, name='user-reset-phone'),

    url(r'^v1/validate-code-validate$', validate_code_validate, name='validate-code-validate'),
    url(r'^v1/validate-code-avatars$',
        validate_code_avatar,
        name='validate-code-avatar'),
)
