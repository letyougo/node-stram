import json
from django.utils.crypto import get_random_string, random
import httpagentparser
import hashlib
import lifebookv2
import requests

from decimal import Decimal

from django.db import IntegrityError, transaction
from django.db.models import Q
from django.conf import settings
from django.utils.http import cookie_date
from django.shortcuts import render
from django.template import RequestContext

from rest_framework.response import Response
from apps.misc.models import OfflineTask

from apps.account.models import (
    User, UserAvatar, WechatAccount,
    UserDevice, ValidateToken, TokenType, SIPAccount,
    UserToken, UserAgent, TokenSerial, UserRememberToken, ValidateCodeAvatar, ValidateCode)
from apps.org.models import (
    Org, UserOrg, UserLastOrg,
    UserDiscussionGroup, WorkMail, ExternalInvitation)

from common.decorator import last_modified
from common.const import ErrorCode, Gender
from common.exceptions import APIError
from common.message_queue import send_message_to_queue
from common.utils import (
    shard_id, current_timestamp, BaseAvatar,
    is_phone_number,
    is_mobile_brower, normalize_phone_number, WechatUtil, list_ids, valid_org)
from common.viewset import ViewSet

import logging
log = logging.getLogger(__name__)


class UserViewSet(ViewSet):
    def create(self, request):
        if 'openid' in request.DATA:
            return self._create_by_wechat(request)

        if 'phone' in request.DATA:
            r = self._validate_phone(request)
            if r:
                return r

        kwargs = {
            'name': '',
            'password': User.encrypt_password(request.DATA['password']),
            'phone': '',
            'gender': Gender.GENDER_UNKNOWN,
            'intro': '',
            'avatar': self._save_avatar(request),
        }

        for key in ('name', 'phone', 'intro', 'gender'):
            if key in request.DATA:
                kwargs[key] = request.DATA[key]

        if kwargs['phone']:
            kwargs['phone'] = normalize_phone_number(kwargs['phone'], append=False)

        u = User(**kwargs)
        try:
            with transaction.atomic():
                u.save()
        except IntegrityError:
            raise APIError(ErrorCode.DUPLICATE_PHONE_NUMBER, phone=kwargs['phone'])

        if request.DATA.get('is_auto_login') == 1:
            response = SessionViewSet._create_by_user(request, u)
            return response
        return Response({'errcode': ErrorCode.OK, 'data': u.to_dict()})

    def _create_by_wechat(self, request):
        tokens, userinfo = None, None
        try:
            tokens, userinfo = WechatUtil().fetch_userinfo_by_token(request.DATA['refresh_token'])
        except WechatUtil.Error as e:
            log.exception(e)
            return Response({'errcode': ErrorCode.WECHAT_SERVER_ERROR})

        send_message_to_queue(
            settings.STARFISH_WECHAT_BIND_QUEUE_NAME,
            json.dumps(userinfo))

        r = User.wechat_account(tokens['openid'])
        if not r and \
                ('phone' not in request.DATA or 'token' not in request.DATA):
            return Response({'errcode': ErrorCode.MISSING_PHONE_AND_TOKEN})

        if 'token' in request.DATA:
            r = ValidateToken.check(
                request.DATA['token'],
                request.DATA['phone'],
                TokenType.VALIDATE_PHONE)
            if r is not None:
                log.warning('invalid auth token 1.')
                return Response({'errcode': ErrorCode.INVALID_AUTH_TOKEN})

        account, created = WechatAccount.objects.get_or_create(
            openid=tokens['openid'],
            defaults={
                'starfish_id': 0,
                'access_token': tokens['access_token'],
                'refresh_token': tokens['refresh_token'],
            }
        )

        if created:
            u = User.from_wechat_userinfo_and_phone(userinfo, request.DATA['phone'])
            account.starfish_id = u.id
            account.save()
            return SessionViewSet._create_by_user(request, u)

        # wechat user already signup
        if not account.starfish_id:
            u = User.from_wechat_userinfo_and_phone(userinfo, request.DATA['phone'])
            account.starfish_id = u.id
        else:
            u = User.objects.get_or_none(id=account.starfish_id)

        account.access_token = tokens['access_token']
        account.refresh_token = tokens['refresh_token']
        account.save()

        return SessionViewSet._create_by_user(request, u)

    def retrieve(self, request, user_id):
        user_ids = list_ids(user_id)

        data = []
        for user in User.objects.filter(id__in=user_ids):
            d = user.to_dict()
            if request.session.find_sessions_by_user(user.id):
                d['online'] = 1
            else:
                d['online'] = 0

            d['distance'] = User.calc_distance(user, request.current_user)
            d['location'] = user.location
            data.append(d)

        return Response({'errcode': ErrorCode.OK, 'data': data})

    @last_modified(User.last_modified)
    def retrieve_summary(self, request, user_id):
        user_ids = list_ids(user_id)

        data = []
        for user in User.objects.filter(id__in=user_ids):
            data.append(user.to_dict())

        return Response({'errcode': ErrorCode.OK, 'data': data})

    def update_last_org(self, request, user_id):
        UserLastOrg.update(request.current_uid, request.DATA['org_id'])
        return Response({'errcode': ErrorCode.OK})

    def user_orgs(self, request, user_id):
        org_ids = UserOrg.objects \
            .filter(user_id=user_id, is_left=0) \
            .values_list('org_id', flat=True)

        org_ids = [i for i in org_ids]
        last_org_id = UserLastOrg.last_org_id(user_id)
        if last_org_id in org_ids:
            org_ids.remove(last_org_id)
            org_ids.insert(0, last_org_id)

        data = []
        for org_id in org_ids:
            o = Org.objects.get_or_none(id=org_id)
            if not o:
                continue

            data.append(o.to_dict())

        return Response({'errcode': ErrorCode.OK, 'data': data})

    def search(self, request):
        if 'openid' in request.GET:
            u = User.wechat_account(request.GET.get('openid', ''))
        elif 'phone' in request.GET:
            u = User.objects.get_or_none(phone=request.GET.get('phone', ''))
        elif 'password' in request.GET:
            if request.current_user and request.current_user.auth(request.GET['password']):
                u = request.current_user
            else:
                u = None
        else:
            u = None

        if not u:
            return Response({'errcode': ErrorCode.NO_SUCH_USER})

        return Response({'errcode': ErrorCode.OK, 'data': u.to_dict()})

    def partial_update(self, request, user_id):
        u = User.objects.get_or_none(id=user_id)

        if 'phone' in request.DATA:
            r = self._update_phone(request, u)
            if r:
                return r

        for key in ('latitude', 'longitude'):
            if key in request.DATA:
                setattr(u, key, Decimal(request.DATA[key]))

        for key in ('name', 'intro', 'gender'):
            if key in request.DATA:
                setattr(u, key, request.DATA[key])

        if request.DATA.get('default_avatar') == 1:
            u.avatar = ''
        elif request.FILES:
            u.avatar = self._save_avatar(request)

        # u._summary_updated = self._user_summary_updated(request, u)
        u.save()

        return Response({'errcode': ErrorCode.OK, 'data': u.to_dict()})

    # def _user_summary_updated(self, request, user):
    #     keys = ('phone', 'name', 'intro', 'gender')
    #     for key in keys:
    #         if key in request.DATA:
    #             return True
    #
    #     return bool(request.FILES)

    def destroy(self, request, user_id):
        for o in UserOrg.objects.filter(user_id=request.current_uid):
            UserDiscussionGroup.objects \
                .using(shard_id(o.org_id)) \
                .filter(user_id=user_id) \
                .delete()

            WorkMail.objects \
                .using(shard_id(o.org_id)) \
                .filter(owner=user_id) \
                .filter(owner_type=WorkMail.TYPE_ORG_MEMBER) \
                .delete()

            o.delete()

        User.objects.filter(id=user_id).delete()

        request.session.delete()

        return Response({'errcode': ErrorCode.OK})

    # TODO refactor
    def partial_update_self(self, request):
        if 'token' in request.DATA:
            valid_types = (
                TokenType.RESET_PASSWORD_BY_PHONE,)

            r = UserToken.objects \
                .filter(token=request.DATA['token']) \
                .filter(type__in=valid_types)

            if not r or len(r) > 1:
                return Response({'errcode': ErrorCode.INVALID_TOKEN})

            if r[0].is_expired():
                return Response({'errcode': ErrorCode.TOKEN_EXPIRED})

            u = User.objects.get_or_none(id=r[0].user_id)

            u.password = User.encrypt_password(request.DATA['password'])
            u.save()

            r.delete()
        else:
            if not request.current_uid:
                return Response({'errcode': ErrorCode.YOU_NEED_SIGN_IN})

            u = request.current_user
            if not u.auth(request.DATA['original-password']):
                return Response({'errcode': ErrorCode.BAD_PASSWORD})

            u.password = User.encrypt_password(request.DATA['password'])
            u.save()

            agent = request.session.store.find_agent_by_session(
                u.id, request.session.session_key)
            OfflineTask.create_password_changed_task(u.id, agent.key)

        return Response({'errcode': ErrorCode.OK})

    def retrieve_self(self, request):
        u = request.current_user
        if not u:
            raise APIError(ErrorCode.YOU_NEED_SIGN_IN)

        data = u.to_dict()
        # data['location'] = u.location
        org_id = UserLastOrg.last_org_id(u.id)
        if org_id:
            data['last_org'] = Org.objects.getx(id=org_id).to_dict()
            data['is_admin'] = 1 if u.is_admin(org_id) else 0

        return Response({'errcode': ErrorCode.OK, 'data': data})

    def invite(self, request):
        if request.method == 'POST':
            return self._do_invite(request)

        invitation = ExternalInvitation.objects \
            .get_or_none(security_code=request.GET.get('c'), used=0)
        if not invitation:
            raise ValueError('invalid security_code')

        if invitation.is_wechat:
            template = 'user/invite-wechat.html'
        elif is_mobile_brower(request.META['HTTP_USER_AGENT']):
            template = 'user/invite-mobile.html'
        else:
            template = 'user/invite-desktop.html'

        return render(
            request, template,
            invitation.to_dict(), context_instance=RequestContext(request))

    def _do_invite(self, request):
        invitation = ExternalInvitation.objects \
            .get_or_none(security_code=request.DATA.get('c'), used=0)
        if not invitation:
            raise ValueError('invalid security_code')

        if not is_phone_number(request.DATA['account']):
            raise ValueError('invalid phone number')

        if invitation.is_wechat:
            r = ValidateToken.check(
                request.DATA['token'],
                request.DATA['account'],
                TokenType.VALIDATE_PHONE)
            if r is not None:
                log.warning('invalid auth token 2.')
                return Response({'errcode': ErrorCode.INVALID_AUTH_TOKEN})

        phone = normalize_phone_number(request.DATA['account'], append=False)

        try:
            User(**{
                'name': request.DATA['name'],
                'password': User.encrypt_password(request.DATA['password']),
                'phone': phone,
                'gender': Gender.GENDER_UNKNOWN,
                'intro': '',
                'avatar': '',
            }).save()
        except IntegrityError:
            return Response({'errcode': ErrorCode.DUPLICATE_PHONE_NUMBER})

        invitation.used = 1
        invitation.save()

        from apps.version.models import Version

        return Response({
            'errcode': ErrorCode.OK,
            'download_url': Version.download_url(
                Version.http_agent_to_platform(request.META['HTTP_USER_AGENT']))
        })

    def _validate_phone(self, request):
        r = ValidateToken.check(
            request.DATA['token'], request.DATA['phone'], TokenType.VALIDATE_PHONE)

        if r is not None:
            return Response({'errcode': r})

    def _save_avatar(self, request):
        if not request.FILES:
            return ''

        return UserAvatar.save_file(list(request.FILES.values())[0])

    def _update_phone(self, request, user):
        if not user.auth(request.DATA['password']):
            return Response({'errcode': ErrorCode.BAD_PASSWORD})

        r = ValidateToken.check(
            request.DATA['phone-token'],
            request.DATA['phone'],
            TokenType.VALIDATE_PHONE
        )
        if r is not None:
            return Response({'errcode': r})

        user.phone = request.DATA['phone']

    def get_user_all_unread_count(self, request, user_id):
        return Response({
            'errcode': ErrorCode.OK,
            'data': User.all_unread_count(request.current_uid)
        })


class SessionViewSet(ViewSet):
    def create(self, request):
        if 'password' in request.DATA:
            return SessionViewSet._create_by_pwd(request)

        if 'remember_token' in request.COOKIES or 'remember_token' in request.DATA:
            return SessionViewSet._create_by_token(request)

        raise ValueError('invalid request')

    @classmethod
    def _create_by_pwd(cls, request):
        u = None
        if 'phone' in request.DATA:
            qs = User.objects.filter(phone=request.DATA['phone']).order_by('id')
            if qs.exists():
                u = qs[0]
        else:
            u = None
        if not u:
            return Response({'errcode': ErrorCode.NO_SUCH_USER})

        if not u.auth(request.DATA['password']):
            return Response({'errcode': ErrorCode.BAD_USERNAME_OR_PASSWORD})

        return cls._create_by_user(request, u)

    # TODO refactor
    @classmethod
    def _create_by_user(cls, request, u):
        request.session.set_user_id(u.id)

        agent_key = cls._agent_key(request)
        agent = request.session.store.find_agent(u.id, agent_key)
        if not agent:
            request.session.replace_agent(
                u.id,
                agent_key,
                cls._agent_type(request),
                cls._agent_desc(request),
                settings.AGENT_AGE + current_timestamp())

        cls._update_session(request, u.id, agent_key)

        user_agent, _ = UserAgent.objects \
            .get_or_create(user_id=u.id, agent_key=agent_key)
        token_serial = TokenSerial.create(u.id)
        rem_token = UserRememberToken.create(
            serial=token_serial.id,
            agent_key=user_agent.agent_key,
            token=UserRememberToken.gen_token())

        sip_account = cls._update_opensips_account(
            u, cls._token(token_serial.serial, rem_token.token),
            request.session.session_key)

        return cls._set_cookie(
            cls._build_response(
                request,
                u.id,
                token_serial.serial,
                rem_token.token,
                sip_account.password),
            settings.SESSION_COOKIE_AGE,
            token_serial.serial, rem_token.token,
            sip_account.password)

    # TODO refactor
    @classmethod
    def _create_by_token(cls, request):
        remember_token = None
        if hasattr(request, 'DATA') and 'remember_token' in request.DATA:
            remember_token = request.DATA['remember_token']
        elif 'remember_token' in request.COOKIES:
            remember_token = request.COOKIES['remember_token']
        else:
            pass

        if not remember_token or len(remember_token) <= TokenSerial.SERIAL_LENGTH:
            log.warning('invalid auth token 3.')
            return cls._set_cookie(
                Response({'errcode': ErrorCode.INVALID_AUTH_TOKEN}))

        token_serial = TokenSerial.objects \
            .get_or_none(serial=remember_token[:TokenSerial.SERIAL_LENGTH])
        if not token_serial:
            log.warning('invalid auth token 4.')
            return cls._set_cookie(Response({'errcode': ErrorCode.INVALID_AUTH_TOKEN}))

        _token = remember_token[TokenSerial.SERIAL_LENGTH:]
        _rem_token = UserRememberToken.objects \
            .filter(serial=token_serial.id) \
            .filter(Q(last_token=_token) | Q(token=_token))
        rem_token = _rem_token[0] if _rem_token else None
        if not rem_token:
            r = UserRememberToken.objects \
                .filter(serial=token_serial.id)
            log.warning('invalid auth token 5, tokens: %s', [i.to_dict() for i in r])
            UserRememberToken.objects \
                .filter(serial=token_serial.id) \
                .delete()
            return cls._set_cookie(
                Response({'errcode': ErrorCode.INVALID_AUTH_TOKEN}))

        agent = request.session.store.find_agent(
            str(token_serial.user_id), rem_token.agent_key)
        if not agent:
            log.warning('invalid auth token 6.')
            return cls._set_cookie(
                Response({'errcode': ErrorCode.INVALID_AUTH_TOKEN}))

        # use old token
        if rem_token.last_token == _token:
            # too old
            if rem_token.update_at + UserRememberToken.TOKEN_AGE < current_timestamp():
                log.warning('invalid auth token 7.')
                return cls._set_cookie(
                    Response({'errcode': ErrorCode.INVALID_AUTH_TOKEN}))

            r = request.session.store \
                .find_session_by_agent(token_serial.user_id, rem_token.agent_key)
            if r:
                cls._update_session(
                    request, token_serial.user_id,
                    rem_token.agent_key, r.key)
            else:
                cls._update_session(
                    request, token_serial.user_id,
                    rem_token.agent_key)
        else:
            cls._update_session(request, token_serial.user_id, rem_token.agent_key)

            if rem_token.update_at + UserRememberToken.TOKEN_AGE < current_timestamp():
                UserRememberToken.objects \
                    .filter(id=rem_token.id, last_token=rem_token.last_token) \
                    .update(
                        last_token=rem_token.token,
                        token=UserRememberToken.gen_token(),
                        update_at=current_timestamp()
                    )

                rem_token = UserRememberToken.objects.get_or_none(id=rem_token.id)

        sip_account = cls._update_opensips_account(
            User.objects.get_or_none(id=token_serial.user_id),
            cls._token(token_serial.serial, rem_token.token),
            request.session.session_key)

        return cls._set_cookie(
            cls._build_response(
                request,
                token_serial.user_id,
                token_serial.serial,
                rem_token.token,
                sip_account.password),
            settings.SESSION_COOKIE_AGE,
            token_serial.serial, rem_token.token,
            sip_account.password)

    @classmethod
    def _is_auto_signin(cls, request):
        if hasattr(request, 'DATA') and 'auto_signin' in request.DATA:
            return int(request.DATA.get('auto_signin', 1))

        return 1

    @classmethod
    def _need_pull_messages(cls, request):
        if not cls._is_auto_signin(request):
            return 1

        return int(not request.session.create_session_response['is_active'])

    @classmethod
    def _update_session(cls, request, user_id, agent_key, session_key=None):
        if session_key:
            request.session.set_session_key(session_key)

        request.session \
            .set_user_id(user_id) \
            .set_agent_key(agent_key)

        # manually save
        request.session['user_id'] = user_id

        if not cls._is_auto_signin(request):
            request.session._action = \
                lifebookv2.lifebook_protocol_commander_pb2.DELETE_DELTA_MSG_ACT

        request.session.save()

        if hasattr(request, 'DATA') and 'device_token' in request.DATA:
            UserDevice.create(
                user_id=user_id,
                device_token=request.DATA['device_token']
            )

            request.session['device_token'] = request.DATA['device_token']

    @classmethod
    def _build_response(cls, request, user_id, serial, token, sip_token):
        data = {
            'maxwell_endpoint': request.session.endpoints['maxwell_frontend_pub'],
            'session_key': request.session.session_key,
            'user_id': user_id,
            'remember_token': cls._token(serial, token),
            'pull_messages': cls._need_pull_messages(request),
            'bfs_url': settings.BFS_URL,
            'sip': cls._build_sip_res(request, user_id, sip_token),
            'turn': cls._build_turn_res(request),
            'stun': cls._build_stun_res(request),
            settings.SESSION_COOKIE_NAME:
                '%s:%s' % (request.session.user_id, request.session.session_key),
        }
        log.info('_build_response: %s', data)

        return Response({'errcode': ErrorCode.OK, 'data': data})

    @classmethod
    def _build_sip_res(cls, request, user_id, sip_token):
        # TODO
        return {
            'registrar': '123.56.134.133',
            'proxy_server': '123.56.134.133',
            'name': user_id,
            'password': sip_token,
        }

    @classmethod
    def _build_turn_res(cls, request):
        # TODO
        return {
            'server': '123.56.134.133',
            'username': '',
            'password': '',
        }

    @classmethod
    def _build_stun_res(cls, request):
        # TODO
        return {
            'server': '123.56.134.133',
        }

    @classmethod
    def _token(cls, serial, token):
        return serial + token

    @classmethod
    def _agent_type(cls, request):
        r = httpagentparser.detect(request.META['HTTP_USER_AGENT'])
        if 'platform' not in r or 'name' not in r['platform'] or not r['platform']['name']:
            return lifebookv2.lifebook_protocol_common_structs_pb2.BROWSER

        platforms = {
            'Android': lifebookv2.lifebook_protocol_common_structs_pb2.ANDROID,
            'iOS': lifebookv2.lifebook_protocol_common_structs_pb2.IPHONE,
            'Mac OS': lifebookv2.lifebook_protocol_common_structs_pb2.MACOSX,
            'Linux': lifebookv2.lifebook_protocol_common_structs_pb2.LINUX,
            'Windows': lifebookv2.lifebook_protocol_common_structs_pb2.WINDOWS,
        }

        if r['platform']['name'] in platforms:
            return platforms[r['platform']['name']]

        return lifebookv2.lifebook_protocol_common_structs_pb2.BROWSER

    @classmethod
    def _agent_desc(cls, request):
        if hasattr(request, 'DATA') and 'agent_desc' in request.DATA:
            return request.DATA['agent_desc']

        return request.META['HTTP_USER_AGENT']

    @classmethod
    def _agent_key(cls, request):
        if 'device_id' not in request.DATA or not request.DATA['device_id']:
            device_id = request.META['HTTP_USER_AGENT']
        else:
            device_id = request.DATA['device_id']

        log.info('device_id: %s', device_id)

        return hashlib.md5(device_id.encode('utf8')).hexdigest()

    def destroy(self, request):
        if 'device_token' in request.session:
            res = UserDevice \
                .find_by_device_token(request.session['device_token']) \
                .filter(user_id=request.current_uid)
            for i in res:
                i.delete()

        ret = request.session.store.find_agent_by_session(
            request.current_uid,
            request.session.session_key
        )
        request.session.delete()

        if ret:
            request.session.store.delete_agent(
                request.current_uid, ret.key)

        return Response({'errcode': ErrorCode.OK})

    @classmethod
    def _set_cookie(cls, response, cookie_age=-86400, serial='', token='', sip_token=''):
        response.set_cookie(
            'remember_token',
            cls._token(serial, token),
            max_age=cookie_age,
            expires=cookie_date(cookie_age + current_timestamp()),
            domain=settings.SESSION_COOKIE_DOMAIN,
            httponly=True)

        if response.data['errcode'] == ErrorCode.OK:
            response.set_cookie(
                'maxwell_endpoint',
                response.data['data']['maxwell_endpoint'],
                max_age=cookie_age,
                expires=cookie_date(cookie_age + current_timestamp()),
                domain=settings.SESSION_COOKIE_DOMAIN,
                httponly=True)

            response.set_cookie(
                'pull_messages',
                str(response.data['data']['pull_messages']),
                max_age=cookie_age,
                expires=cookie_date(cookie_age + current_timestamp()),
                domain=settings.SESSION_COOKIE_DOMAIN,
                httponly=True)

        return response

    @classmethod
    def _update_opensips_account(cls, user, token, session_key):
        # TODO async
        sip_account = SIPAccount.get_or_create(user)

        try:
            r = requests.post(
                settings.OPENSIPS_GATEWAY, timeout=10,
                data=json.dumps({
                    'sip_account': sip_account.to_dict(),
                }),
                headers={'Content-type': 'application/json'})
        except requests.exceptions.Timeout:
            log.error('opensips-gateway timeout')
            return sip_account

        if r.status_code != requests.codes.OK:
            log.error('opensips-gateway return error: %s, %s', r.status_code, r.content)

        try:
            r = json.loads(r.content.decode('utf8'))
            if r['errcode']:
                log.error('opensips-gateway return error: %s', r.content)
        except ValueError:
            log.error('opensips-gateway return error: %s', r.content)

        return sip_account


class TokenViewSet(ViewSet):
    def search(self, request):
        _type = int(request.GET['type'])

        if _type in (TokenType.VALIDATE_PHONE, ):
            r = ValidateToken.check(
                request.GET['token'], request.GET['account'], _type)
            if r is None:
                user = User.find_by_phone(request.GET['account'])
                if user and request.GET.get('is_auto_login') == '1':
                    response = SessionViewSet._create_by_user(request, user)
                    return response

        elif _type in (TokenType.RESET_PASSWORD_BY_PHONE, ):
            r = UserToken.check(request.GET['token'], _type)
        else:
            raise ValueError('invlid args')

        if r is not None:
            return Response({'errcode': ErrorCode.OK, 'data': None})
        else:
            return Response({'errcode': ErrorCode.OK, 'data': request.GET.dict()})

    def create(self, request):
        type_ = int(request.DATA['type'])
        if type_ not in UserToken.VALID_TOKEN_TYPES \
                and type_ not in ValidateToken.VALID_TOKEN_TYPES:
            raise ValueError('invalid token type')

        methods = {
            TokenType.VALIDATE_PHONE:
            self._create_validate_phone_token,

            TokenType.RESET_PASSWORD_BY_PHONE:
            self._create_reset_password_by_phone_token}

        return methods[type_](request)

    def _create_validate_phone_token(self, request):
        phone = request.DATA['phone']
        r = ValidateToken.get_or_create(phone, TokenType.VALIDATE_PHONE)
        send_message_to_queue(
            settings.STARFISH_TOKEN_QUEUE_NAME,
            json.dumps({
                'type': TokenType.VALIDATE_PHONE,
                'phone': phone,
                'token': r.token
                }
            )
        )

        return Response({'errcode': ErrorCode.OK})

    def _create_reset_password_by_phone_token(self, request):
        u = User.objects.get_or_none(phone=request.DATA['phone'])
        if not u:
            return Response({'errcode': ErrorCode.NO_SUCH_USER})

        if u.is_fake('phone'):
            return Response({'errcode': ErrorCode.YOU_HAVE_NO_PHONE})

        r = UserToken.get_or_create(u.id, TokenType.RESET_PASSWORD_BY_PHONE)
        send_message_to_queue(
            settings.STARFISH_TOKEN_QUEUE_NAME,
            json.dumps({
                'type': TokenType.RESET_PASSWORD_BY_PHONE,
                'phone': u.phone,
                'token': r.token
                }
            )
        )

        return Response({'errcode': ErrorCode.OK})


class AgentViewSet(ViewSet):
    OFFLINE_MESSAGE = "当前设备已经被别的设备置为离线"

    def list_by_user(self, request, user_id):
        if not request.current_user.in_same_org_with(user_id):
            return Response({'errcode': ErrorCode.PERMISSION_DENIED})

        ret = []
        sessions = self._sessions(request, user_id)
        for i in request.session.store.find_agents_by_user(user_id):
            ret.append({
                'key': i.key,
                'type': i.type,
                'desc': i.desc.decode('utf8'),
                'online': int(i.key in sessions)
            })

        return Response({'errcode': ErrorCode.OK, 'data': ret})

    def _sessions(self, request, user_id):
        r = request.session.store.find_sessions_by_user(user_id)
        return set([i.agent_key for i in r])

    def partial_update(self, request, user_id, agent_key):
        orgs = request.current_user.in_same_org_with(user_id)
        if not orgs:
            return Response({'errcode': ErrorCode.PERMISSION_DENIED})

        is_admin = sum([
            1 for org_id in orgs if request.current_user.is_admin(org_id)
        ]) > 0
        if not is_admin and request.current_uid != user_id:
            return Response({'errcode': ErrorCode.PERMISSION_DENIED})

        OfflineTask.create_offline_agent_task(user_id, agent_key, self.OFFLINE_MESSAGE)

        return Response({'errcode': ErrorCode.OK})

    def destroy(self, request, user_id, agent_key):
        orgs = request.current_user.in_same_org_with(user_id)
        if not orgs:
            return Response({'errcode': ErrorCode.PERMISSION_DENIED})

        is_admin = sum([
            1 for org_id in orgs if valid_org(org_id) and request.current_user.is_admin(org_id)
        ]) > 0
        if not is_admin and request.current_uid != user_id:
            return Response({'errcode': ErrorCode.PERMISSION_DENIED})

        OfflineTask.create_remove_agent_task(user_id, agent_key, self.OFFLINE_MESSAGE)

        return Response({'errcode': ErrorCode.OK})


class UserAvatarView(BaseAvatar):
    def get(self, request, user_id):
        return self._get(
            request, User.objects.get_or_none(id=user_id).avatar,
            UserAvatar, User.DEFAULT_AVATAR)


class UserResetPhoneViewSet(ViewSet):
    def get_page(self, request):
        return render(request, 'user/reset_phone.html')

    def reset_phone(self, request):
        phone = request.DATA['phone']
        password = request.DATA['password']
        token = request.DATA['token']
        change_to = request.DATA['change_to']

        u = User.objects.get_or_none(phone=phone)
        if not u:
            return Response({'errcode': ErrorCode.INVALID_PHONE_NUMBER})

        if not u.auth(password):
            return Response({'errcode': ErrorCode.BAD_PASSWORD})

        r = ValidateToken.check(token, phone, TokenType.VALIDATE_PHONE)
        if r is not None:
            return Response({'errcode': r})

        u.phone = change_to
        u.save()
        WechatAccount.objects.filter(starfish_id=u.id).update(starfish_id=0)

        return Response({'errcode': ErrorCode.OK, 'data': u.to_dict()})


class ValidCodeView(ViewSet):
    def validate(self, request):
        code = request.GET.get('code')
        key = request.GET.get('generated_key')
        if not code or not key:
            raise APIError(ErrorCode.BAD_REQUEST_PARAMS, generated_key=key, code=code)

        is_valid = ValidateCode.is_valid(code, key,
                                         request.META.get('HTTP_USER_AGENT', ''))
        return Response({'errcode': ErrorCode.OK, 'data': {'is_valid': 1 if is_valid else 0}})


class ValidCodeAvatarView(BaseAvatar):
    def get(self, request):
        key = request.GET.get('generated_key')
        if key is None:
            key = get_random_string(random.randint(8, 32))
        if not (8 <= len(key) <= 32):
            return self._build_json_response(ErrorCode.BAD_REQUEST_PARAMS)

        user_agent = request.META.get('HTTP_USER_AGENT', '')
        obj = ValidateCode.fetch_one(key, user_agent)
        response = self._get(
            request, obj.avatar, ValidateCodeAvatar, None)

        response.set_cookie(
            'generated_key', key,
            max_age=30*60,
            expires=cookie_date(30*60 + current_timestamp()),
            domain=settings.SESSION_COOKIE_DOMAIN,
            httponly=False)

        return response
