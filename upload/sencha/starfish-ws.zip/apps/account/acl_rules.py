from apps.acl.models import SystemRole, RuleDescriptor

default_org_rules = []
default_global_rules = []

# # GUEST 访问邀请页面
# r = {
#     'role': SystemRole.GUEST,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'invite-page'},
#     'permission': RuleDescriptor.PERMISSION_VIEW,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 10,
#     'is_system': 1,
# }
# default_global_rules.append(r)

# # GUEST 访问邀请页面
# r = {
#     'role': SystemRole.GUEST,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'invite-page'},
#     'permission': RuleDescriptor.PERMISSION_CREATE,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 10,
#     'is_system': 1,
# }
# default_global_rules.append(r)

# # GUEST 注册
# r = {
#     'role': SystemRole.GUEST,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'users-list'},
#     'permission': RuleDescriptor.PERMISSION_CREATE,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 1,
#     'is_system': 1,
# }
# default_global_rules.append(r)

# # GUEST 登陆
# r = {
#     'role': SystemRole.GUEST,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'sessions-list'},
#     'permission': RuleDescriptor.PERMISSION_CREATE,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 1,
#     'is_system': 1,
# }
# default_global_rules.append(r)

# # GUEST 注销
# r = {
#     'role': SystemRole.GUEST,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'session-self'},
#     'permission': RuleDescriptor.PERMISSION_DELETE,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 1,
#     'is_system': 1,
# }
# default_global_rules.append(r)

# # GUEST 搜索用户
# r = {
#     'role': SystemRole.GUEST,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'users-list'},
#     'permission': RuleDescriptor.PERMISSION_VIEW,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 1,
#     'is_system': 1,
# }
# default_global_rules.append(r)

# # USER_SELF 获取自己所在的 ORG 列表
# r = {
#     'role': SystemRole.USER_SELF,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'user-orgs'},
#     'permission': RuleDescriptor.PERMISSION_VIEW,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 10,
#     'is_system': 1,
# }
# default_global_rules.append(r)

# # USER_SELF 更新自己所在的 ORG 列表
# r = {
#     'role': SystemRole.USER_SELF,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'user-last-org'},
#     'permission': RuleDescriptor.PERMISSION_UPDATE,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 10,
#     'is_system': 1,
# }
# default_global_rules.append(r)

# REGISTERED_USER 获取 USER 详情
r = {
    'role': SystemRole.REGISTERED_USER,
    'resource_descriptor': {
        'class': 'SimpleResourceDescriptor',
        'desc': 'user-detail'},
    'permission': RuleDescriptor.PERMISSION_VIEW,
    'allow_or_deny': RuleDescriptor.ALLOW,
    'priority': 10,
    'is_system': 1,
}
default_global_rules.append(r)

# # USER_SELF 更新自己的 USER 详情
# r = {
#     'role': SystemRole.USER_SELF,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'user-detail'},
#     'permission': RuleDescriptor.PERMISSION_UPDATE,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 10,
#     'is_system': 1,
# }
# default_global_rules.append(r)
#
# # USER_SELF 删除自己的 USER 详情
# r = {
#     'role': SystemRole.USER_SELF,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'user-detail'},
#     'permission': RuleDescriptor.PERMISSION_DELETE,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 10,
#     'is_system': 1,
# }
# default_global_rules.append(r)


#  REGISTERED_USER 获取自己的 USER 详情
r = {
    'role': SystemRole.REGISTERED_USER,
    'resource_descriptor': {
        'class': 'SimpleResourceDescriptor',
        'desc': 'user-self'},
    'permission': RuleDescriptor.PERMISSION_VIEW,
    'allow_or_deny': RuleDescriptor.ALLOW,
    'priority': 10,
    'is_system': 1,
}
default_global_rules.append(r)


# # GUEST 更新自己的 USER 详情
# r = {
#     'role': SystemRole.GUEST,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'user-self'},
#     'permission': RuleDescriptor.PERMISSION_UPDATE,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 10,
#     'is_system': 1,
# }
# default_global_rules.append(r)

# # GUEST 创建 TOKEN
# r = {
#     'role': SystemRole.GUEST,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'tokens-list'},
#     'permission': RuleDescriptor.PERMISSION_CREATE,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 10,
#     'is_system': 1,
# }
# default_global_rules.append(r)
#
# # GUEST 查询 TOKEN
# r = {
#     'role': SystemRole.GUEST,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'tokens-list'},
#     'permission': RuleDescriptor.PERMISSION_VIEW,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 10,
#     'is_system': 1,
# }
# default_global_rules.append(r)

# REGISTERED_USER 查看设备列表
r = {
    'role': SystemRole.REGISTERED_USER,
    'resource_descriptor': {
        'class': 'SimpleResourceDescriptor',
        'desc': 'user-agents'},
    'permission': RuleDescriptor.PERMISSION_VIEW,
    'allow_or_deny': RuleDescriptor.ALLOW,
    'priority': 10,
    'is_system': 1,
}
default_global_rules.append(r)

# REGISTERED_USER 删除设备
r = {
    'role': SystemRole.REGISTERED_USER,
    'resource_descriptor': {
        'class': 'SimpleResourceDescriptor',
        'desc': 'agent-detail'},
    'permission': RuleDescriptor.PERMISSION_DELETE,
    'allow_or_deny': RuleDescriptor.ALLOW,
    'priority': 10,
    'is_system': 1,
}
default_global_rules.append(r)

# REGISTERED_USER 离线设备
r = {
    'role': SystemRole.REGISTERED_USER,
    'resource_descriptor': {
        'class': 'SimpleResourceDescriptor',
        'desc': 'agent-detail'},
    'permission': RuleDescriptor.PERMISSION_UPDATE,
    'allow_or_deny': RuleDescriptor.ALLOW,
    'priority': 10,
    'is_system': 1,
}
default_global_rules.append(r)

# REGISTERED_USER 查看用户头像
r = {
    'role': SystemRole.REGISTERED_USER,
    'resource_descriptor': {
        'class': 'SimpleResourceDescriptor',
        'desc': 'user-avatar'},
    'permission': RuleDescriptor.PERMISSION_VIEW,
    'allow_or_deny': RuleDescriptor.ALLOW,
    'priority': 10,
    'is_system': 1,
}
default_global_rules.append(r)

# REGISTERED_USER 获取 USER SUMMARY
r = {
    'role': SystemRole.REGISTERED_USER,
    'resource_descriptor': {
        'class': 'SimpleResourceDescriptor',
        'desc': 'user-summary'},
    'permission': RuleDescriptor.PERMISSION_VIEW,
    'allow_or_deny': RuleDescriptor.ALLOW,
    'priority': 10,
    'is_system': 1,
}
default_global_rules.append(r)

# REGISTERED_USER 获取 UNREAD COUNT
r = {
    'role': SystemRole.REGISTERED_USER,
    'resource_descriptor': {
        'class': 'SimpleResourceDescriptor',
        'desc': 'user-all-unread-count'},
    'permission': RuleDescriptor.PERMISSION_VIEW,
    'allow_or_deny': RuleDescriptor.ALLOW,
    'priority': 10,
    'is_system': 1,
}
default_global_rules.append(r)


# # GUEST reset phone
# r = {
#     'role': SystemRole.GUEST,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'user-reset-phone'},
#     'permission': RuleDescriptor.PERMISSION_CREATE,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 10,
#     'is_system': 1,
# }
# default_global_rules.append(r)
#
# # GUEST reset phone
# r = {
#     'role': SystemRole.GUEST,
#     'resource_descriptor': {
#         'class': 'SimpleResourceDescriptor',
#         'desc': 'user-reset-phone'},
#     'permission': RuleDescriptor.PERMISSION_VIEW,
#     'allow_or_deny': RuleDescriptor.ALLOW,
#     'priority': 10,
#     'is_system': 1,
# }
# default_global_rules.append(r)