db = 'main'
sql = """
CREATE TABLE "core_validate_code" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "code" varchar(8) NOT NULL,
    "avatar" varchar(128) NOT NULL,
    "date_added" integer CHECK ("date_added" >= 0) NOT NULL
)
;

"""