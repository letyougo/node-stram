db = 'main'
sql = """
CREATE TABLE "uc_user_maxwell_endpoint" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "user_id" bigint NOT NULL UNIQUE,
    "endpoint" integer CHECK ("endpoint" >= 0) NOT NULL
);

"""