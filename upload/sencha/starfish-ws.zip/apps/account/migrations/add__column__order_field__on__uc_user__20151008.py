db = 'main'
sql = """
ALTER TABLE uc_user ADD COLUMN "order_field" integer NOT NULL DEFAULT 0;
CREATE INDEX "uc_user_order_field" ON "uc_user" ("order_field");
"""