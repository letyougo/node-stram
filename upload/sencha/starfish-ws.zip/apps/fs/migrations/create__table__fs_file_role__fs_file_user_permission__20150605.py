db = 'org'
sql = """
CREATE TABLE "fs_file_role" (
    "create_time" timestamp with time zone NOT NULL,
    "id" bigserial NOT NULL PRIMARY KEY,
    "name" varchar(128) NOT NULL,
    "owner" bigint NOT NULL,
    "owner_type" smallint CHECK ("owner_type" >= 0) NOT NULL,
    "file_id" integer NOT NULL,
    "perm" bigint NOT NULL,
    UNIQUE ("file_id", "owner", "owner_type")
)
;
CREATE TABLE "fs_file_user_permission_roles" (
    "id" serial NOT NULL PRIMARY KEY,
    "fileuserpermission_id" integer NOT NULL,
    "filerole_id" integer NOT NULL,
    UNIQUE ("fileuserpermission_id", "filerole_id")
)
;
CREATE TABLE "fs_file_user_permission" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "file_id" integer NOT NULL,
    "user_id" bigint NOT NULL,
    "perm" bigint NOT NULL,
    UNIQUE ("file_id", "user_id")
)
;
CREATE INDEX "fs_file_role_name" ON "fs_file_role" ("name");
CREATE INDEX "fs_file_role_name_like" ON "fs_file_role" ("name" varchar_pattern_ops);
CREATE INDEX "fs_file_role_file_id" ON "fs_file_role" ("file_id");
CREATE INDEX "fs_file_user_permission_roles_fileuserpermission_id" ON "fs_file_user_permission_roles" ("fileuserpermission_id");
CREATE INDEX "fs_file_user_permission_roles_filerole_id" ON "fs_file_user_permission_roles" ("filerole_id");
CREATE INDEX "fs_file_user_permission_file_id" ON "fs_file_user_permission" ("file_id");
"""