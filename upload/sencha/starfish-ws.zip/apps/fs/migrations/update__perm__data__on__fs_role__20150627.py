db = 'org'
sql = """

UPDATE fs_file_role SET perm = perm &(~64) WHERE perm =  (perm | 64);
UPDATE fs_file_user_permission SET perm = perm &(~64) WHERE perm =  (perm | 64);

UPDATE fs_file_role SET perm = perm |128 WHERE perm =  63;
UPDATE fs_file_user_permission SET perm = perm |128 WHERE perm =  63;
"""
