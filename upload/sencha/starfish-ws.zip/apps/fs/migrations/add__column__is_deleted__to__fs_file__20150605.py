db = 'org'
sql = """
alter table fs_file add column "is_deleted" smallint CHECK ("is_deleted" >= 0) NOT NULL default 0;
"""
