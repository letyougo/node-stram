from apps.version.models import Version

from common.tests import TestCase
from common.const import ErrorCode


class SimpleTest(TestCase):

    def test_version_list(self):
        v2 = Version(
            platform=Version.PLATFORM_IOS,
            version='1.1.2',
        )
        v2.save()

        v1 = Version(
            platform=Version.PLATFORM_IOS,
            version='1.1.11',
        )
        v1.save()

        response = self.client.get(
            '/v1/versions/latest?platform=%s' % Version.PLATFORM_ANDROID, format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.NO_VERSION)

        response = self.client.get(
            '/v1/versions/latest?platform=%s' % Version.PLATFORM_IOS, format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.OK)
        self.assertEqual(v2.to_dict(), response.data['data'])
