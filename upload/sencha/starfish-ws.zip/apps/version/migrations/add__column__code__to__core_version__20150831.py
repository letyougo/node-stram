db = 'main'
sql = """
alter table core_version add column "code" varchar(32) NOT NULL default '';
"""
