from common.const import ErrorCode
from common.utils import current_timestamp
from common.tests import TestCase


class SimpleTest(TestCase):

    def test_create_feedback(self):
        self.login('alice')

        data = {
            'content': 'hello moto'}
        response = self.client.post('/v1/feedbacks', data=data)

        self.assertEqual(response.data['errcode'], ErrorCode.OK)
        self.assertEqual(response.data['data']['content'], data['content'])
        self.assertEqual(response.data['data']['date_added'], current_timestamp())
