from rest_framework.response import Response

from apps.feedback.models import Feedback

from common.const import ErrorCode
from common.viewset import ViewSet


class FeedbackViewSet(ViewSet):
    PAGE_SIZE = 10

    def create(self, request):
        feedback = Feedback(
            user_id=request.current_uid,
            content=request.DATA.get('content'),
        )
        feedback.save()

        return Response({'errcode': ErrorCode.OK, 'data': feedback.to_dict()})

    def list(self, request):
        start = int(request.GET.get('start', 0))

        qs = Feedback.objects \
            .filter(user_id=request.current_uid)

        if start:
            qs = qs.filter(id__lt=start)

        ret = qs.order_by('-id')[:self.PAGE_SIZE]

        return Response({
            'errcode': ErrorCode.OK,
            'data': [i.to_dict() for i in ret]})
