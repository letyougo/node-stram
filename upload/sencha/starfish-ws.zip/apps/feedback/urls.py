from django.conf.urls import patterns, url

from apps.feedback import views

feedback_list = views.FeedbackViewSet.as_view({
    'post': 'create',
    'get': 'list',
})

urlpatterns = patterns(
    '',
    url(r'^v1/feedbacks$', feedback_list, name='feedbacks-list'),
)
