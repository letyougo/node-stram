from django.db import models

from common import models as _models
from common.utils import current_timestamp


class Feedback(_models.BaseModel):
    user_id = _models.PositiveBigIntegerField(db_index=True)
    content = models.CharField(max_length=4096)
    date_added = models.PositiveIntegerField()

    def save(self, *args, **kwargs):
        if not self.date_added:
            self.date_added = current_timestamp()

        super(Feedback, self).save(*args, **kwargs)

    class Meta:
        db_table = 'core_feedback'
