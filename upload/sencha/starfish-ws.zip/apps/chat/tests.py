from common.tests import TestCase


class ChatTest(TestCase):
    pass
