db = 'org'
sql = """
ALTER TABLE chat_text ALTER COLUMN content TYPE varchar(10240);
"""
