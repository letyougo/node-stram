import os
import random
import smtplib
import requests

from django.conf import settings
from django.db import IntegrityError, transaction

from rest_framework.response import Response

from apps.account.models import User, UserAvatar
from apps.org.models import (
    Org, DiscussionGroup, UserOrg, UserDiscussionGroup,
    OrgAvatar, DiscussionGroupAvatar, UserPosition, InvitationCode,
    WorkMail, Invitation, Department, UserDepartment, DepartmentAvatar,
    ExternalInvitation, ExternalContact, ExternalContactAvatar, GeneratedContact,
    UserGeneratedContact, OrgDomain, OrgApp, MemberOrgApp, OrgCategory, OrgAttribute)

from apps.mail import utils
from apps.org.serializers import OrgAppSerializer, WorkMailSerializer

from common.decorator import last_modified
from common.const import ErrorCode
from common.exceptions import APIError
from common.utils import (
    shard_id, GroupAvatarGenerator, is_phone_number, current_timestamp,
    ensure_dir_exists, normalize_phone_number, BaseAvatar,
    setattr_if_changed, check_domain_mx_records, TargetObject, list_ids, valid_org)
from common.viewset import ViewSet

import logging
log = logging.getLogger(__name__)


class OrgViewSet(ViewSet):
    def _update_org_attirbute(self, request, org_id):
        province = request.DATA.get('province', '')
        city = request.DATA.get('city', '')
        category = request.DATA.get('category', '')
        if category:
            category_obj = OrgCategory.create(category)
        else:
            category_obj = None
        if province or city or category:
            attribute, created = OrgAttribute.objects \
                .get_or_create(org_id=org_id,
                               defaults={'province': province,
                                         "city": city,
                                         'category': category_obj})
            if not created and setattr_if_changed(attribute, province=province, city=city,
                                                  category=category_obj):
                attribute.save()

        return Org.objects.get(id=org_id)

    def create(self, request):
        domain_name = request.DATA.get('domain')
        if domain_name and not check_domain_mx_records(domain_name):
            raise APIError(ErrorCode.DOMAIN_MX_RECORDS_ERROR, domain_name=domain_name)

        kwargs = {
            'creator': request.current_uid,
            'name': request.DATA['name'],
            'intro': request.DATA.get('intro', ''),
            'avatar': self._save_avatar(request),
        }

        retries = 3
        for i in range(retries):
            kwargs['id'] = Org.next_org_id()

            o = Org(**kwargs)
            try:
                with transaction.atomic():
                    o.save()
                break
            except IntegrityError as e:
                log.exception(e)
                if i == retries - 1:
                    raise e

        domain_name = request.DATA.get('domain')
        if domain_name:
            org_domain = o.default_domain
            org_domain.name = domain_name
            org_domain.save()

        o = self._update_org_attirbute(request, o.id)
        return Response({'errcode': ErrorCode.OK, 'data': o.to_dict()})

    @last_modified(Org.last_modified)
    def retrieve(self, request, org_id):
        o = Org.objects.get_or_none(id=org_id)
        if not o:
            return Response({'errcode': ErrorCode.NO_SUCH_ORG})

        return Response({'errcode': ErrorCode.OK, 'data': o.to_dict()})

    def partial_update(self, request, org_id):
        o = Org.objects.get_or_none(id=org_id)
        if not o:
            return Response({'errcode': ErrorCode.NO_SUCH_ORG})

        if request.FILES:
            o.avatar = self._save_avatar(request)

        fields = ('name', 'intro')
        for field in fields:
            if field in request.DATA:
                setattr(o, field, request.DATA[field])
        o.save()
        o = self._update_org_attirbute(request, o.id)
        return Response({'errcode': ErrorCode.OK, 'data': o.to_dict()})

    def list_status(self, request):
        ret = {}
        for org_id in UserOrg.user_in_org_ids(request.current_uid):
            if not valid_org(org_id):
                continue

            count = self._unread_messages_count(request.current_uid, org_id)
            ret[org_id] = {
                'has_unread_messages': 1 if count else 0,
                'unread_messages_count': count
            }

        return Response({'errcode': ErrorCode.OK, 'data': ret})

    def list_work_mails(self, request, org_id):
        if 'local_part' in request.GET:
            r = WorkMail.objects\
                .using(org_id) \
                .filter(local_part=request.GET['local_part'])
            if r.exists():
                return Response({'errcode': ErrorCode.OK, 'data': r[0].to_dict()})
        elif 'owner_type' in request.GET:
            owner_type = request.GET['owner_type']
            is_set = request.GET.get('is_set', 1)

            qs = WorkMail.objects.using(org_id)\
                .filter(owner_type=owner_type, is_set=is_set)\
                .order_by('-id')

            data = WorkMailSerializer(self.paging(request, qs), many=True).data
            return Response({'errcode': ErrorCode.OK, 'data': data})

        return Response({'errcode': ErrorCode.OK, 'data': None})

    def _unread_messages_count(self, user_id, org_id):
        from apps.message.models import UserConversation
        return UserConversation.objects \
            .using(org_id) \
            .filter(user_id=user_id) \
            .exclude(unread_count=0) \
            .count()

    def _save_avatar(self, request):
        if not request.FILES:
            return ''

        return OrgAvatar.save_file(list(request.FILES.values())[0])


class MemberFilterMixin(object):
    def user_ids_from_request(self, request, org_id):
        in_members = request.DATA.get('members', []) or request.DATA.get('user_ids', [])
        exclude_members = request.DATA.get('exclude_members', [])
        in_departments = request.DATA.get('departments', [])
        exclude_departments = request.DATA.get('exclude_departments', [])

        users_dict = {}
        for did in in_departments:
            for uid in Department.user_ids(org_id, did):
                users_dict[uid] = users_dict.get(uid, 0) + 1

        for did in exclude_departments:
            for uid in Department.user_ids(org_id, did):
                users_dict[uid] = users_dict.get(uid, 0) - 1

        for uid in exclude_members:
            users_dict[uid] = 0
        for uid in in_members:
            users_dict[uid] = 1

        return [uid for uid, count in users_dict.items() if count > 0]


class DiscussionGroupViewSet(ViewSet, MemberFilterMixin):
    def create(self, request, org_id):
        members = [request.current_uid] + self.user_ids_from_request(request, org_id)

        # exist_group_id = DiscussionGroupHash.find(org_id, members)
        # if exist_group_id:
        #     g = DiscussionGroup.objects.using(org_id).getx(id=exist_group_id)
        #     if g and not g.is_disbanded:
        #         return Response({'errcode': ErrorCode.OK, 'data': g.to_dict()})

        name = request.DATA.get('name')
        if not name:
            names_list = User.objects.filter(id__in=members[:10]).values_list('name', flat=True)
            name = ','.join(names_list)[:30]

        g = DiscussionGroup(
            creator=request.current_uid,
            name=name,
            intro=request.DATA['intro'],
            avatar=self._save_avatar(request, org_id))
        g._members = members

        g.save(using=shard_id(org_id))
        return Response({'errcode': ErrorCode.OK, 'data': g.to_dict()})

    @last_modified(UserDiscussionGroup.last_modified_by_user)
    def user_discussion_groups(self, request, org_id, user_id):
        if request.GET.get('normal') == '1':
            return self._user_discussion_groups_normal(request, org_id, user_id)
        else:
            return self._user_discussion_groups_all(request, org_id, user_id)

    def _user_discussion_groups_normal(self, request, org_id, user_id):
        r = UserDiscussionGroup.objects \
            .using(shard_id(org_id)) \
            .filter(user_id=user_id, is_left=0)\
            .values_list('group_id', flat=True)

        discussion_groups = DiscussionGroup.objects \
            .using(shard_id(org_id)) \
            .filter(id__in=list(r))\
            .filter(is_disbanded=0)\
            .order_by('-id')

        data = DiscussionGroup.to_dict_list(org_id, self.paging(request, discussion_groups))

        return Response({'errcode': ErrorCode.OK, 'data': data})

    def _user_discussion_groups_all(self, request, org_id, user_id):
        r = UserDiscussionGroup.objects \
            .using(shard_id(org_id)) \
            .filter(user_id=user_id)

        is_left = dict([(i.group_id, i.is_left) for i in r])

        discussion_groups = DiscussionGroup.objects \
            .using(shard_id(org_id)) \
            .filter(id__in=[i.group_id for i in r])

        data = {
            'normal': DiscussionGroup.to_dict_list(org_id,
                                                   [g for g in discussion_groups
                                                    if not g.is_disbanded and not is_left[g.id]]),
            'disbanded':
                DiscussionGroup.to_dict_list(org_id,
                                             [g for g in discussion_groups if g.is_disbanded]),
            'left':
                DiscussionGroup.to_dict_list(org_id,
                                             [g for g in discussion_groups if is_left[g.id]])
        }

        return Response({'errcode': ErrorCode.OK, 'data': data})

    def retrieve(self, request, org_id, group_id):
        g = DiscussionGroup.objects.using(shard_id(org_id)) \
            .get_or_none(id=group_id)

        if not g:
            return Response({'errcode': ErrorCode.NO_SUCH_DISCUSSION_GROUP})

        return Response({'errcode': ErrorCode.OK, 'data': g.to_dict()})

    def partial_update(self, request, org_id, group_id):
        g = DiscussionGroup.objects.using(shard_id(org_id)) \
            .get_or_none(id=group_id)

        if not g:
            return Response({'errcode': ErrorCode.NO_SUCH_DISCUSSION_GROUP})

        for key in ('intro', 'is_disbanded'):
            if key in request.DATA:
                setattr(g, key, request.DATA[key])

        if not g.related_project() and 'name' in request.DATA:
            g.name = request.DATA['name']

        if request.FILES:
            g.avatar = self._save_avatar(request, org_id)

        g.save(using=shard_id(org_id))

        return Response({'errcode': ErrorCode.OK, 'data': g.to_dict()})

    def partial_update_work_mails(self, request, org_id):
        result_list = []

        for v in request.DATA:
            local_part, domain_id = v.get('work_mail_local_part'), v.get('domain_id')
            try:
                wm = WorkMail.set_address(org_id,
                                          v['group_id'],
                                          WorkMail.TYPE_DISCUSSION_GROUP,
                                          local_part, domain_id)
                result_list.append({'errcode': ErrorCode.OK, 'id': wm.id})

            except APIError as e:
                result_list.append({
                    'errcode': e.error_code,
                    'local_part': local_part,
                    'domain_id': domain_id
                })

        return Response({'errcode': ErrorCode.OK, 'data': result_list})

    def _save_avatar(self, request, org_id):
        if not request.FILES:
            return ''

        return DiscussionGroupAvatar.save_file(list(request.FILES.values())[0], org_id)


class OrgMemberViewSet(ViewSet):
    def list(self, request, org_id):
        normal = UserOrg.objects \
            .filter(org_id=org_id, is_left=0)
        left = UserOrg.objects \
            .filter(org_id=org_id, is_left=1)

        data = {
            'normal': User.build_summary_list([i.user_id for i in normal], org_id),
            'left': User.build_summary_list([i.user_id for i in left], org_id),
        }

        return Response({'errcode': ErrorCode.OK, 'data': data})

    def retrieve(self, request, org_id, user_id):
        user_ids = list_ids(user_id)
        data = {u['id']: u for u in User.build_summary_list(user_ids, org_id)}
        return Response({'errcode': ErrorCode.OK, 'data': data})

    def partial_update(self, request, org_id, user_id):
        local_part = request.DATA.get('work_mail_local_part')
        domain_id = request.DATA.get('domain_id')

        if local_part or domain_id:
            WorkMail.set_address(org_id,
                                 user_id, WorkMail.TYPE_ORG_MEMBER,
                                 local_part, domain_id)

        position = request.DATA.get('position')
        if position:
            r, created = UserPosition.objects \
                .using(shard_id(org_id)) \
                .get_or_create(
                    user_id=user_id,
                    defaults={'position': position})
            if not created:
                r.position = position
                r.save()

        return Response({'errcode': ErrorCode.OK})

    def partial_update_work_mails(self, request, org_id):
        result_list = []

        for v in request.DATA:
            local_part, domain_id = v.get('work_mail_local_part'), v.get('domain_id')
            try:
                wm = WorkMail.set_address(org_id,
                                          v['user_id'],
                                          WorkMail.TYPE_ORG_MEMBER,
                                          local_part, domain_id)
                result_list.append({'errcode': ErrorCode.OK, 'id': wm.id})

            except APIError as e:
                result_list.append({
                    'errcode': e.error_code,
                    'local_part': local_part,
                    'domain_id': domain_id
                })

        return Response({'errcode': ErrorCode.OK, 'data': result_list})

    def destroy(self, request, org_id, user_id):
        o = UserOrg.objects \
            .get_or_none(
                user_id=user_id,
                org_id=org_id,
                is_left=0)
        if o:
            o.is_left = 1
            o.save()

        return Response({'errcode': ErrorCode.OK})


class DiscussionGroupMemberViewSet(ViewSet, MemberFilterMixin):
    def create(self, request, org_id, group_id):
        group = DiscussionGroup.objects \
            .using(org_id) \
            .getx(id=group_id)
        if not group:
            raise APIError(ErrorCode.NO_SUCH_DISCUSSION_GROUP, org_id=org_id, group_id=group_id)

        members = self.user_ids_from_request(request, org_id)
        group.add_users(request.current_user, members)
        return Response({'errcode': ErrorCode.OK})

    @last_modified(UserDiscussionGroup.last_modified_by_group)
    def list(self, request, org_id, group_id):
        detail = int(request.GET.get('detail', 0))
        if detail:
            return self._list_detail(request, org_id, group_id, detail)
        else:
            return self._list_ids(request, org_id, group_id)

    def _list_ids(self, request, org_id, group_id):
        group_ids = list_ids(group_id)
        qs = UserDiscussionGroup.objects.using(org_id) \
            .filter(group_id__in=group_ids) \
            .filter(is_left=0)

        data = dict((gid, []) for gid in group_ids)
        for ud in qs:
            data[ud.group_id].append(ud.user_id)

        return Response({'errcode': ErrorCode.OK, 'data': data})

    def _list_detail(self, request, org_id, group_id, detail):
        qs = UserDiscussionGroup.objects.using(org_id) \
            .filter(group_id=group_id) \
            .filter(is_left=0)\
            .values_list('user_id', flat=True)

        user_id_list = list(self.paging(request, qs))
        if detail == 2:
            work_mails = WorkMail.find_many2(user_id_list, WorkMail.TYPE_ORG_MEMBER, org_id)

        _t = TargetObject()
        data = []
        for user_id in user_id_list:
            user_info = _t.obj_info(User, user_id)
            if detail == 2:
                user_info.update(work_mail=work_mails[user_id])
            data.append(user_info)

        return Response({'errcode': ErrorCode.OK, 'data': data})

    def retrieve(self, request, org_id, group_id, user_id):
        group = DiscussionGroup.objects.using(org_id).getx(id=group_id)
        if not group:
            return Response({'errcode': ErrorCode.NO_SUCH_DISCUSSION_GROUP})

        data = group.to_dict()
        data.update(is_left=(0 if group.has_user(user_id) else 1),
                    member_count=group.user_count())
        return Response({'errcode': ErrorCode.OK, 'data': data})

    def destroy(self, request, org_id, group_id, user_id):
        group = DiscussionGroup.objects \
            .using(org_id) \
            .getx(id=group_id)
        if not group:
            raise APIError(ErrorCode.NO_SUCH_DISCUSSION_GROUP, org_id=org_id, group_id=group_id)

        group.remove_users(request.current_user, [user_id])
        return Response({'errcode': ErrorCode.OK})


class DepartmentViewSet(ViewSet):
    def create(self, request, org_id):
        parent_id = int(request.DATA.get('parent', 0))
        if not parent_id:
            parent_id = request.current_org.default_department.id
        elif not Department.objects.using(org_id).getx(id=parent_id):
            raise APIError(ErrorCode.NO_SUCH_DEPARTMENT, parent_id=parent_id)

        d = Department(
            creator=request.current_uid,
            name=request.DATA['name'],
            avatar=self._save_avatar(request, org_id),
            parent_id=parent_id)
        d.save(using=shard_id(org_id))

        for user_id in request.DATA['members']:
            d.add_direct_in(user_id)

        return Response({'errcode': ErrorCode.OK, 'data': d.to_dict()})

    def list(self, request, org_id):
        groups = Department.objects.using(org_id).filter(is_disbanded=0)

        parent_id = request.GET.get('parent')
        if parent_id == '0':
            groups = groups.filter(parent=None)
        elif parent_id is not None:
            groups = groups.filter(parent_id=parent_id)

        data = Department.to_dict_list(org_id, self.paging(request, groups, 100))
        return Response({'errcode': ErrorCode.OK, 'data': data})

    def retrieve(self, request, org_id, group_id):
        group = Department.objects \
            .using(shard_id(org_id)) \
            .get_or_none(id=group_id, is_disbanded=0)
        if not group:
            return Response({'errcode': ErrorCode.NO_SUCH_DEPARTMENT})

        data = group.to_dict()
        data['parents'] = []
        while group.parent:
            group = group.parent
            data['parents'].append(group.to_dict())

        return Response({'errcode': ErrorCode.OK, 'data': data})

    def partial_update(self, request, org_id, group_id):
        group = Department.objects \
            .using(shard_id(org_id)) \
            .get_or_none(id=group_id, is_disbanded=0)
        if not group:
            return Response({'errcode': ErrorCode.NO_SUCH_DEPARTMENT})

        name = request.DATA.get('name')
        is_disbanded = request.DATA.get('is_disbanded')
        if is_disbanded:
            group.is_disbanded = is_disbanded
        if name:
            group.name = name

        if request.FILES:
            group.avatar = self._save_avatar(request, org_id)

        group.save(using=shard_id(org_id))

        local_part = request.DATA.get('work_mail_local_part')
        domain_id = request.DATA.get('domain_id')
        if local_part or domain_id:
            WorkMail.set_address(org_id,
                                 group_id, WorkMail.TYPE_DEPARTMENT,
                                 local_part, domain_id)

        return Response({'errcode': ErrorCode.OK, 'data': group.to_dict()})

    def partial_update_work_mails(self, request, org_id):
        result_list = []

        for v in request.DATA:
            local_part, domain_id = v.get('work_mail_local_part'), v.get('domain_id')
            try:
                wm = WorkMail.set_address(org_id,
                                          v['group_id'],
                                          WorkMail.TYPE_DEPARTMENT,
                                          local_part, domain_id)
                result_list.append({'errcode': ErrorCode.OK, 'id': wm.id})

            except APIError as e:
                result_list.append({
                    'errcode': e.error_code,
                    'local_part': local_part,
                    'domain_id': domain_id
                })

        return Response({'errcode': ErrorCode.OK, 'data': result_list})

    def update_user_departments(self, request, org_id, user_id):
        if not request.current_user.is_admin(org_id):
            return Response({'errcode': ErrorCode.PERMISSION_DENIED})

        Department.user_reset_direct_in(org_id, user_id, request.DATA)
        return Response({'errcode': ErrorCode.OK})

    def list_user_departments(self, request, org_id, user_id):
        db = shard_id(org_id)

        qs = UserDepartment.objects.using(db)\
            .filter(user_id=user_id)

        direct_in = 0
        if 'is_direct' in request.GET:
            direct_in = int(request.GET['is_direct'])
        elif 'direct_in' in request.GET:
            direct_in = int(request.GET['direct_in'])

        if direct_in == 1:
            qs = qs.filter(direct_in=1)

        _t = TargetObject()
        data = [dict(direct_in=i.direct_in, is_direct=i.direct_in,
                     **_t.obj_info(Department, i.group_id, db))
                for i in qs]

        return Response({'errcode': ErrorCode.OK, 'data': data})

    def _save_avatar(self, request, org_id):
        if not request.FILES:
            return ''

        return DepartmentAvatar.save_file(list(request.FILES.values())[0], org_id)


class DepartmentMemberViewSet(ViewSet):
    def create(self, request, org_id, group_id):
        user_ids = request.DATA['user_ids']

        if User.objects.filter(id__in=user_ids).count() < len(user_ids):
            return Response({'errcode': ErrorCode.NO_SUCH_USER})

        if UserOrg.objects.filter(
                org_id=org_id,
                is_left=0,
                user_id__in=user_ids).count() < len(user_ids):
            return Response({'errcode': ErrorCode.NO_SUCH_USER_IN_ORG})

        d = Department.objects.using(org_id).getx(id=group_id)
        d.add_direct_in(*user_ids)

        return Response({'errcode': ErrorCode.OK})

    def list(self, request, org_id, group_id):
        detail = int(request.GET.get('detail', 0))
        UserDepartment.normalize(org_id)
        if detail:
            return self._list_detail(request, org_id, group_id, detail)
        else:
            return self._list_ids(request, org_id, group_id)

    def _list_ids(self, request, org_id, group_id):
        group_ids = list_ids(group_id)

        qs = UserDepartment.objects.using(org_id) \
            .filter(group_id__in=group_ids)

        direct_in = 1
        if 'is_direct' in request.GET:
            direct_in = int(request.GET['is_direct'])
        elif 'direct_in' in request.GET:
            direct_in = int(request.GET['direct_in'])

        if direct_in:
            qs = qs.filter(direct_in=1)

        data = dict((gid, []) for gid in group_ids)
        for ud in qs:
            data[ud.group_id].append(ud.user_id)

        return Response({'errcode': ErrorCode.OK, 'data': data})

    def _list_detail(self, request, org_id, group_id, detail):
        qs = UserDepartment.objects.using(org_id) \
            .filter(group_id=group_id) \
            .values_list('user_id', flat=True)

        direct_in = 1
        if 'is_direct' in request.GET:
            direct_in = int(request.GET['is_direct'])
        elif 'direct_in' in request.GET:
            direct_in = int(request.GET['direct_in'])

        if direct_in:
            qs = qs.filter(direct_in=1)

        users = self.paging(request,
                            User.objects.filter(id__in=list(qs)),
                            ordering='order_field')
        results = []
        if detail == 2:
            user_id_list = list(users.values_list('id', flat=True))
            work_mails = WorkMail.find_many2(user_id_list, WorkMail.TYPE_ORG_MEMBER, org_id)
        if detail == 3:
            user_id_list = list(users.values_list('id', flat=True))
            user_details = {u['id']: u for u in User.build_summary_list(user_id_list, org_id)}

        _t = TargetObject()
        for u in users:
            user_info = _t.obj_info(User, u.id)

            if detail == 2:
                user_info.update(work_mail=work_mails[u.id])
            if detail == 3:
                user_info.update(user_details[u.id],
                                 location=u.location,
                                 is_admin=u.is_admin(org_id))
                user_info.update(u.to_dict())
            results.append(user_info)

        return Response({'errcode': ErrorCode.OK, 'data': results})

    def retrieve(self, request, org_id, group_id, user_id):
        d = Department.objects.using(org_id).getx(id=group_id)
        if not d:
            return Response({'errcode': ErrorCode.NO_SUCH_DEPARTMENT})

        data = d.to_dict()
        data.update(is_left=(0 if d.has_user(user_id) else 1),
                    member_count=d.user_count(direct_in=1))
        return Response({'errcode': ErrorCode.OK, 'data': data})

    def destroy(self, request, org_id, group_id, user_id):
        Department.objects.using(org_id).getx(id=group_id).remove_direct_in(user_id)
        return Response({'errcode': ErrorCode.OK})


class DepartmentItemViewSet(ViewSet):
    def list_all_items(self, request, org_id, parent_id):
        page = int(request.GET.get('page', 1))
        count = int(request.GET.get('count', 10))

        groups = Department.objects.using(org_id)\
            .filter(parent_id=parent_id, is_disbanded=0)

        UserDepartment.normalize(org_id)
        user_ids = UserDepartment.objects.using(org_id) \
            .filter(group_id=parent_id, direct_in=1) \
            .values_list('user_id', flat=True)

        #  order by order_field
        user_ids = list(User.objects.filter(id__in=list(user_ids)).values_list('id', flat=True))

        departments, members = [], []

        start, end = (page-1)*count, page*count
        groups_count = groups.count()
        if end <= groups_count:
            departments = Department.to_dict_list(org_id, groups[start:end])

        elif start < groups_count and end > groups_count:
            departments = Department.to_dict_list(org_id, groups[start:])
            start, end = 0, count-len(departments)
            members = User.build_summary_list(user_ids[start:end], org_id,
                                              _work_mail=True, _departments=False, _is_left=False)
        else:
            start -= groups_count
            end -= groups_count
            members = User.build_summary_list(user_ids[start:end], org_id,
                                              _work_mail=True, _departments=False, _is_left=False)

        _t = TargetObject()
        for m in members:
            m.update(**_t.obj_info(User, m['id']))

        # data = {'departments': departments, 'members': members}
        data = []
        for i in departments:
            data.append(dict(item_type=1, item=i))
        for i in members:
            data.append(dict(item_type=2, item=i))
        return Response({'errcode': ErrorCode.OK, 'data': data})


class InvitationViewSet(ViewSet):
    def create(self, request):
        if 'user_id' in request.DATA:
            return self.create0(request)

        return self.create1(request)

    def create0(self, request):
        org_id = int(request.DATA['org_id'])
        org = Org.objects.get_or_none(id=org_id)
        if not org:
            return Response({'errcode': ErrorCode.NO_SUCH_ORG})

        if not request.current_user.is_admin(org_id):
            return Response({'errcode': ErrorCode.PERMISSION_DENIED})

        r = UserOrg.objects \
            .filter(user_id=request.DATA['user_id'], org_id=org_id) \
            .filter(is_left=0)
        if r:
            return Response({'errcode': ErrorCode.USER_ALREADY_IN_ORG})

        invitation = Invitation(
            who=request.current_uid,
            whom=request.DATA['user_id'],
            org_id=org_id)
        invitation.save()

        return Response({'errcode': ErrorCode.OK, 'data': invitation.to_dict()})

    def create1(self, request):
        org_id = int(request.DATA['org_id'])
        org = Org.objects.get_or_none(id=org_id)
        if not org:
            return Response({'errcode': ErrorCode.NO_SUCH_ORG})

        if not request.current_user.is_admin(org_id):
            return Response({'errcode': ErrorCode.PERMISSION_DENIED})

        if 'to' not in request.DATA:
            r = ExternalInvitation.create(
                request.current_uid,
                '',
                org.id,
                ExternalInvitation.INVITATION_TYPE_WECHAT)
            ret = {
                'url': '%s/invite?c=%s' % (settings.API_URL, r.security_code),
            }
            return Response({'errcode': ErrorCode.OK, 'data': ret})

        if is_phone_number(request.DATA['to'][0]):
            self._invite_by_sms(request.DATA['to'], org, request.current_user)
        else:
            self._invite_by_email(request.DATA['to'], org, request.current_user)

        return Response({'errcode': ErrorCode.OK})

    def _invite_by_sms(self, to_list, org, admin):
        if not settings.SMS_SWITCH:
            return

        from apps.account.template import sms_invitation_template

        for to in to_list:
            to = normalize_phone_number(to, append=False)
            invitation = ExternalInvitation.create(admin.id, to, org.id)
            url = '%s/invite?c=%s' % (settings.API_URL, invitation.security_code)
            content = sms_invitation_template % (admin.name, org.name, url)

            log.info('send sms invitation to: %s', to)
            for i in range(5):
                try:
                    requests.get(
                        settings.SMS_GATEWAY_URL,
                        params={
                            'to': normalize_phone_number(to),
                            'body': content,
                            'sc': settings.SMS_GATEWAY_SECRET_CODE,
                            'type': settings.SMS_TYPE_INVITATION},
                        timeout=settings.SMS_GATEWAY_TIMEOUT)
                    break
                except Exception as e:
                    if i == 4:
                        log.error('send sms invitation to: %s', to)
                        raise e

    def _invite_by_email(self, to, org, admin):
        from apps.account.template import email_invitation_template

        invitation = ExternalInvitation.create(admin.id, to[0], org.id)
        url = '%s/invite?c=%s' % (settings.API_URL, invitation.security_code)
        content = email_invitation_template % (org.name, admin.name, url)
        mail = utils.build_mail(
            sender="\"Starfish\" <%s>" % settings.SERVICE_MAIL_CONF['from'],
            to=to,
            subject='%s邀请你加入%s' % (admin.name, org.name),
            content=content)

        retries = 5
        for i in range(retries):
            try:
                conn = smtplib.SMTP(random.choice(settings.SMTP_HOST))

                conn.login(mail.get('From'), settings.SMPT_FAKE_PWD)
                conn.sendmail(mail.get('From'), to, mail.as_string())

                conn.quit()

                break
            except Exception as e:
                log.exception(e)

    def partial_update(self, request, invitation_id):
        invitation = Invitation.objects.get_or_none(id=invitation_id)
        if not invitation:
            return Response({'errcode': ErrorCode.NO_SUCH_INVITATION})

        if invitation.whom != request.current_uid:
            return Response({'errcode': ErrorCode.PERMISSION_DENIED})

        invitation_status = int(request.DATA['status'])
        r = UserOrg.objects \
            .filter(user_id=invitation.whom, org_id=invitation.org_id) \
            .filter(is_left=0)
        if r:
            invitation.status = Invitation.STATUS_CONFIRM
            invitation._do_not_notify = True
            invitation.save()

            return Response({'errcode': ErrorCode.USER_ALREADY_IN_ORG})

        invitation.status = invitation_status
        invitation.save()

        return Response({'errcode': ErrorCode.OK, 'data': invitation.to_dict()})


class InvitationCodeViewSet(ViewSet):
    def search(self, request):
        r = InvitationCode.objects \
            .filter(code=request.GET['code'], used_by_org=0)
        if r:
            return Response({'errcode': ErrorCode.OK, 'data': request.GET.dict()})

        return Response({'errcode': ErrorCode.OK, 'data': None})


class ExternalContactView(ViewSet):
    def create(self, request, org_id):
        kwargs = {
            'creator': request.current_uid,
            'manager': request.current_uid,
            'avatar': self._save_avatar(request),
        }
        for key in ('name', 'gender', 'phone', 'wechat', 'email',
                    'corporation', 'position', 'department', 'address'):
            kwargs[key] = request.DATA.get(key, '')

        v = ExternalContact(**kwargs)
        v.save(using=shard_id(org_id))

        return Response({'errcode': ErrorCode.OK, 'data': v.to_dict()})

    def list(self, request, org_id):
        ret = ExternalContact.objects \
            .using(shard_id(org_id)) \
            .all()
        return Response({
            'errcode': ErrorCode.OK,
            'data': [v.to_dict() for v in ret]})

    def partial_update(self, request, org_id, external_contact_id):
        v = ExternalContact.objects \
            .using(shard_id(org_id)) \
            .get_or_none(id=external_contact_id)
        if not v:
            return Response({'errcode': ErrorCode.NO_SUCH_CONTACT})

        for key in ('name', 'gender', 'phone', 'wechat', 'email', 'manager',
                    'corporation', 'position', 'department', 'address'):
            if key in request.DATA:
                setattr(v, key, request.DATA.get(key, ''))

        if request.FILES:
            v.avatar = self._save_avatar(request)

        v.save(using=shard_id(org_id))

        return Response({'errcode': ErrorCode.OK, 'data': v.to_dict()})

    def retrieve(self, request, org_id, external_contact_id):
        ec = ExternalContact.objects \
            .using(shard_id(org_id)) \
            .getx(id=external_contact_id)

        return Response({'errcode': ErrorCode.OK, 'data': ec.to_dict()})

    def destroy(self, request, org_id, external_contact_id):
        ExternalContact.objects \
            .using(shard_id(org_id)) \
            .filter(id=external_contact_id) \
            .delete()

        return Response({'errcode': ErrorCode.OK})

    def _save_avatar(self, request):
        if not request.FILES:
            return ''

        return ExternalContactAvatar.save_file(list(request.FILES.values())[0])


class ExternalContactAvatarView(BaseAvatar):
    def get(self, request, org_id, external_contact_id):
        v = ExternalContact.objects \
            .using(shard_id(org_id)) \
            .get_or_none(id=external_contact_id)

        return self._get(
            request,
            v.avatar if v else None,
            ExternalContactAvatar,
            ExternalContact.DEFAULT_AVATAR)


class OrgAvatarView(BaseAvatar):
    def get(self, request, org_id):
        org = Org.objects.get_or_none(id=org_id)
        return self._get(
            request, org.avatar if org else None,
            OrgAvatar, Org.DEFAULT_AVATAR)


class GroupAvatarView(BaseAvatar):
    AVATAR_AGE = 3600

    def get(self, request, org_id, group_id):
        request._resize_disabled = True
        try:
            return self._get0(
                request, org_id, group_id, int(request.GET.get('width', 200)))
        except Exception as e:
            log.exception(e)
            raise e

    def _should_regenerate_avatar(self, path):
        if not os.path.isfile(path):
            return True

        return os.path.getmtime(path) + self.AVATAR_AGE < current_timestamp()

    def generate(self, default_avatar_path, users, box_size, name=''):
        if not self._should_regenerate_avatar(default_avatar_path):
            return

        image_files = []
        for user in users:
            if user.avatar and os.path.isfile(UserAvatar.full_path(user.avatar)):
                image_files.insert(0, UserAvatar.full_path(user.avatar))
            else:
                image_files.append(User.DEFAULT_AVATAR)

        ensure_dir_exists(default_avatar_path)

        try:
            GroupAvatarGenerator() \
                .generate(image_files, box_size, name) \
                .save(default_avatar_path)
        except OSError as e:
            log.warning('file exists: %s' % e)


class DepartmentAvatarView(GroupAvatarView):
    def _get0(self, request, org_id, group_id, box_size):
        department = Department.objects \
            .using(shard_id(org_id)) \
            .get_or_none(id=group_id)

        default_avatar_path = DepartmentAvatar.full_path(
            'department-avatars/%s/%s_%s.png' % (org_id, group_id, box_size))

        user_ids = Department.user_ids(org_id, group_id, filter_disbanded=False)
        # users = User.objects.filter(id__in=user_ids)
        self.generate(default_avatar_path, [], box_size, department.name)

        return self._get(
            request,
            department.avatar,
            DepartmentAvatar,
            default_avatar_path)


class DiscussionGroupAvatarView(GroupAvatarView):
    def _get0(self, request, org_id, group_id, box_size):
        group_avatar = DiscussionGroup.objects \
            .using(shard_id(org_id)) \
            .get_or_none(id=group_id).avatar

        default_avatar_path = DiscussionGroupAvatar.full_path(
            'discussion-group-avatars/%s/%s_%s.png' % (org_id, group_id, box_size))

        user_ids = [i for i in UserDiscussionGroup.objects
                    .filter(group_id=group_id, is_left=0)
                    .using(shard_id(org_id))
                    .values_list('user_id', flat=True)]
        users = User.objects.filter(id__in=user_ids)
        self.generate(default_avatar_path, users, box_size)

        return self._get(
            request, group_avatar,
            DiscussionGroupAvatar, default_avatar_path)


class GeneratedContactView(ViewSet):
    def list(self, request, org_id):
        gc_ids = UserGeneratedContact.objects \
            .using(org_id) \
            .filter(user_id=request.current_uid)\
            .order_by('-id')\
            .values_list('contact_id', flat=True)

        gc_ids = self.paging(request, gc_ids)

        ret = GeneratedContact.objects.using(org_id).filter(id__in=gc_ids)
        return Response({'errcode': ErrorCode.OK, 'data': [v.to_dict() for v in ret]})


class OrgDomainViewSet(ViewSet):
    def _is_valid_name(self, name):
        return name and OrgDomain.objects.getx(name=name) is None

    def create(self, request, org_id):
        name = request.DATA.get('name')
        if not self._is_valid_name(name):
            return Response({'errcode': ErrorCode.DOMAIN_OCCUPIED})

        if not check_domain_mx_records(name):
            raise APIError(ErrorCode.DOMAIN_MX_RECORDS_ERROR, domain_name=name)

        od = Org.objects.getx(id=org_id).default_domain
        if not od.valid_name:
            od.creator = request.current_uid
            od.name = name
            od.save()
        else:
            od = OrgDomain.objects.create(
                creator=request.current_uid,
                name=name,
                org_id=org_id,
                is_default=request.DATA.get('is_default', 0)
            )
        return Response({'errcode': ErrorCode.OK, 'data': od.to_dict()})

    def list(self, request, org_id):
        qs = OrgDomain.objects.filter(org_id=org_id)\
            .order_by('-is_default', 'id')

        return Response({'errcode': ErrorCode.OK,
                         'data': [i.to_dict() for i in qs if i.valid_name]})

    def partial_update(self, request, org_id, domain_id):
        od = OrgDomain.objects.get_or_none(id=domain_id)
        if not od or od.org_id != org_id:
            return Response({'errcode': ErrorCode.CAN_NOT_MODIFY_DOMAIN})

        kwargs = {}
        name = request.DATA.get('name')
        is_default = request.DATA.get('is_default')
        if name:
            if not self._is_valid_name(name):
                return Response({'errcode': ErrorCode.DOMAIN_OCCUPIED})
            kwargs.update(name=name)
        if is_default:
            kwargs.update(is_default=is_default)

        if setattr_if_changed(od, **kwargs):
            od.save()

        return Response({'errcode': ErrorCode.OK, 'data': od.to_dict()})

    def destroy(self, request, org_id, domain_id):
        od = OrgDomain.objects.get_or_none(id=domain_id)
        if not od or od.org_id != org_id or od.is_default:
            return Response({'errcode': ErrorCode.CAN_NOT_MODIFY_DOMAIN})

        od.delete()
        return Response({'errcode': ErrorCode.OK})


class OrgAppViewSet(ViewSet):

    def install_or_uninstall(self, request, org_id):
        if not request.current_user.is_admin(org_id):
            raise APIError(ErrorCode.PERMISSION_DENIED, user_id=request.current_uid)

        is_install = request.DATA.get('install')
        app = request.DATA.get('app')

        org_app, created = OrgApp.objects\
            .using(org_id)\
            .get_or_create(app=app,
                           defaults={
                               'creator': request.current_uid,
                               'is_install': is_install}
                           )
        if not created and setattr_if_changed(org_app, is_install=is_install):
            org_app.save()

        return Response({'errcode': ErrorCode.OK})

    def list_install(self, request, org_id):
        qs = OrgApp.objects.using(org_id).filter(is_install=1)
        data = OrgAppSerializer(qs, many=True).data
        return Response({'errcode': ErrorCode.OK, 'data': data})

    def modify_navi(self, request, org_id, user_id):
        if request.current_uid != user_id:
            raise APIError(ErrorCode.PERMISSION_DENIED,
                           current_uid=request.current_uid, user_id=user_id)

        is_navi = request.DATA.get('navi')
        app = request.DATA.get('app')

        if not OrgApp.has_install(org_id, app):
            raise APIError(ErrorCode.ORG_APP_NOT_INSTALL, org_id=org_id, app=app)

        member_app, created = MemberOrgApp.objects\
            .using(org_id)\
            .get_or_create(app=app, user_id=user_id,
                           defaults={'is_navi': is_navi}
                           )
        if not created and setattr_if_changed(member_app, is_navi=is_navi):
            member_app.save()

        return Response({'errcode': ErrorCode.OK})

    def list_navi(self, request, org_id, user_id):
        if request.current_uid != user_id:
            raise APIError(ErrorCode.PERMISSION_DENIED,
                           current_uid=request.current_uid, user_id=user_id)
        qs = MemberOrgApp.objects.using(org_id).filter(user_id=user_id, is_navi=1)
        return Response({'errcode': ErrorCode.OK, 'data': qs.values_list('app', flat=True)})
