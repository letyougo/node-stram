db = 'main'
sql = """
drop index uc_org_domain;

CREATE TABLE "uc_org_domain" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "org_id" bigint NOT NULL,
    "creator" bigint NOT NULL,
    "name" varchar(64) NOT NULL UNIQUE,
    "is_default" integer CHECK ("is_default" >= 0) NOT NULL,
    "create_time" timestamp with time zone NOT NULL
)
;

CREATE INDEX "uc_org_domain_org_id" ON "uc_org_domain" ("org_id");
CREATE INDEX "uc_org_domain_name_like" ON "uc_org_domain" ("name" varchar_pattern_ops);
"""
