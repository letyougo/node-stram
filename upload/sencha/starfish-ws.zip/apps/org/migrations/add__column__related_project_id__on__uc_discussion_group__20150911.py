db = 'org'
sql = """
ALTER TABLE uc_discussion_group ADD COLUMN "related_project_id" bigint NOT NULL default 0;
"""