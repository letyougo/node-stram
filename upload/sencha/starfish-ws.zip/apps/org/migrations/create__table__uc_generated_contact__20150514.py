db = 'org'
sql = """
CREATE TABLE "uc_generated_contact" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "name" varchar(128),
    "gender" smallint CHECK ("gender" >= 0) NOT NULL,
    "phone" varchar(32),
    "email" varchar(128) NOT NULL UNIQUE,
    "create_time" timestamp with time zone NOT NULL
)
;
CREATE TABLE "uc_user_generated_contact" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "user_id" bigint NOT NULL,
    "contact_id" bigint NOT NULL,
    UNIQUE ("user_id", "contact_id")
)
;

CREATE INDEX "uc_generated_contact_email_like" ON "uc_generated_contact" ("email" varchar_pattern_ops);
CREATE INDEX "uc_user_generated_contact_user_id" ON "uc_user_generated_contact" ("user_id");
CREATE INDEX "uc_user_generated_contact_contact_id" ON "uc_user_generated_contact" ("contact_id");
"""