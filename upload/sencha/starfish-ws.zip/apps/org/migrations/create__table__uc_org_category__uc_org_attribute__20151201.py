db = 'main'
sql = """
CREATE TABLE "uc_org_category" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "is_deleted" smallint CHECK ("is_deleted" >= 0) NOT NULL,
    "create_time" timestamp with time zone,
    "update_time" timestamp with time zone,
    "name" varchar(128) NOT NULL,
    "parent_id" integer
)
;
CREATE TABLE "uc_org_attribute" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "org_id" bigint NOT NULL,
    "province" varchar(64) NOT NULL,
    "city" varchar(64) NOT NULL,
    "category_id" integer
)
;

CREATE INDEX "uc_org_category_parent_id" ON "uc_org_category" ("parent_id");
CREATE INDEX "uc_org_attribute_org_id" ON "uc_org_attribute" ("org_id");
CREATE INDEX "uc_org_attribute_category_id" ON "uc_org_attribute" ("category_id");

"""
