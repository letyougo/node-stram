db = 'org'
sql = """
ALTER TABLE uc_discussion_group ADD COLUMN "order_field" integer NOT NULL DEFAULT 0;
CREATE INDEX "uc_discussion_group_order_field" ON "uc_discussion_group" ("order_field");

ALTER TABLE uc_department ADD COLUMN "order_field" integer NOT NULL DEFAULT 0;
CREATE INDEX "uc_department_order_field" ON "uc_department" ("order_field");
"""