db = 'main'
sql = """
ALTER TABLE uc_org ADD COLUMN "order_field" integer NOT NULL DEFAULT 0;
CREATE INDEX "uc_org_order_field" ON "uc_org" ("order_field");
"""