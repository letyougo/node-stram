db = 'org'
sql = """
ALTER TABLE uc_department ADD COLUMN "parent_id" bigint default NULL;
ALTER TABLE uc_user_department ADD COLUMN "direct_in" smallint CHECK ("direct_in" >= 0) NOT NULL default 1;

CREATE INDEX "uc_department_parent_id" ON "uc_department" ("parent_id");
"""