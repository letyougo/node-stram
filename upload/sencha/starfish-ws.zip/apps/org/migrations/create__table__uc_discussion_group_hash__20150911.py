db = 'org'
sql = """
CREATE TABLE "uc_discussion_group_hash" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "group_id" bigint NOT NULL UNIQUE,
    "hash" bytea NOT NULL UNIQUE
)
"""
