db = 'main'
sql = """
ALTER TABLE uc_external_invitation ADD COLUMN "is_deleted" smallint CHECK ("is_deleted" >= 0) NOT NULL default 0;
ALTER TABLE uc_external_invitation ADD COLUMN "create_time" timestamp with time zone default NULL;
ALTER TABLE uc_external_invitation ADD COLUMN "update_time" timestamp with time zone default NULL;
"""