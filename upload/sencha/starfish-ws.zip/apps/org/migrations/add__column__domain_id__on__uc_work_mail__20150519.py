db = 'org'
sql = """
alter table uc_work_mail add column "domain_id" bigint NOT NULL default 0;

CREATE INDEX "uc_work_mail_domain_id" ON "uc_work_mail" ("domain_id");
"""