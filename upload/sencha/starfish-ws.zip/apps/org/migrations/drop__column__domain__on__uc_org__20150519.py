db = 'main'
#sql = """ALTER TABLE uc_org DROP COLUMN domain;"""