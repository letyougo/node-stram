db = 'org'
sql = """
CREATE TABLE "app_org_app" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "is_deleted" smallint CHECK ("is_deleted" >= 0) NOT NULL,
    "create_time" timestamp with time zone,
    "update_time" timestamp with time zone,
    "creator" bigint NOT NULL,
    "app" integer CHECK ("app" >= 0) NOT NULL UNIQUE,
    "is_install" smallint CHECK ("is_install" >= 0) NOT NULL
)
;
CREATE TABLE "app_user_org_app" (
    "id" bigserial NOT NULL PRIMARY KEY,
    "user_id" bigint NOT NULL,
    "app" integer CHECK ("app" >= 0) NOT NULL,
    "is_navi" smallint CHECK ("is_navi" >= 0) NOT NULL,
    UNIQUE ("user_id", "app")
)
;
CREATE INDEX "app_user_org_app_user_id" ON "app_user_org_app" ("user_id");

"""
