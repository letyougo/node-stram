db = 'org'
sql = """
drop index uc_work_mail_local_part;
CREATE UNIQUE INDEX uc_work_mail_local_part_domain_id ON uc_work_mail (local_part, domain_id);
"""
