import hashlib
import string

from django.core.cache import cache
from django.db.models import get_model
from django.utils.crypto import get_random_string
from django.conf import settings
from django.db import IntegrityError, transaction
from django.db import models
from django.core.files.storage import FileSystemStorage

from common import models as _models
from common.const import Gender, ErrorCode
from common.exceptions import APIError
from common.utils import (
    shard_id, current_timestamp, format_phone_number,
    setattr_if_changed, is_valid_email_local_part, find_first_gap, dt_to_timestamp, time_to_str)

import logging
log = logging.getLogger(__name__)


class UserLastOrg(_models.SimpleBaseModel):
    user_id = _models.PositiveBigIntegerField(unique=True)
    org_id = _models.PositiveBigIntegerField()
    update_at = models.PositiveIntegerField()

    @classmethod
    def update(cls, user_id, org_id):
        r, created = UserLastOrg.objects \
            .get_or_create(
                user_id=user_id,
                defaults={
                    'org_id': org_id,
                    'update_at': current_timestamp()
                }
            )
        if not created:
            r.org_id = org_id
            r.update_at = current_timestamp()
            r.save()

    @classmethod
    def last_org_id(cls, user_id):
        r = UserLastOrg.objects.get_or_none(user_id=user_id)
        if not r:
            return 0

        return r.org_id

    class Meta:
        db_table = 'uc_user_last_org'


class OrgDomain(_models.BaseModel):
    FAKE_DELETE_FIELDS = ('name',)

    org = models.ForeignKey('Org', db_constraint=False, related_name='domains')
    creator = _models.PositiveBigIntegerField()
    name = models.CharField(max_length=64, unique=True)
    is_default = models.PositiveIntegerField(default=0)

    @property
    def valid_name(self):
        if self.is_fake('name'):
            return ''
        else:
            return self.name

    def to_dict(self):
        ret = super(OrgDomain, self).to_dict(fields=['id', 'name', 'is_default'])
        ret['name'] = self.valid_name
        return ret

    class Meta:
        db_table = 'uc_org_domain'


class Org(_models.BaseModel):
    DEFAULT_AVATAR = '%s/default_org_icon.png' % settings.FS_ROOT

    creator = _models.PositiveBigIntegerField()
    name = models.CharField(max_length=128)
    intro = models.CharField(max_length=1024)
    avatar = models.CharField(max_length=128)
    update_at = models.PositiveIntegerField()
    order_field = models.IntegerField(default=0, db_index=True)

    @property
    def avatar_url(self):
        if self.avatar.lower().startswith('http'):
            return self.avatar

        from yxt.models import OrgYxt
        if OrgYxt.objects.getx(org_id=self.id):
            prefix = settings.ORG_AVATAR_URL_PREFIX_YXT
        else:
            prefix = settings.ORG_AVATAR_URL_PREFIX_STARFISH

        return '%s/%s/%s' % (prefix, self.id, self.avatar)

    @property
    def default_domain(self):
        domain = OrgDomain.objects.get_or_none(org_id=self.id, is_default=1)
        if domain is None:
            domain = OrgDomain(
                org=self,
                creator=self.creator,
                name=OrgDomain.fake_identity(),
                is_default=1)
            domain.save()
        return domain

    @property
    def default_domain_name(self):
        return self.default_domain.valid_name

    @classmethod
    def next_org_id(cls):
        org_ids = Org.objects \
            .values_list('id', flat=True) \
            .order_by('-id')[:100]
        return find_first_gap(list(reversed(org_ids)))

    def save(self, *args, **kwargs):
        if not self.name:
            raise ValueError('invalid org name')

        self.update_at = current_timestamp()

        super(Org, self).save(*args, **kwargs)

    def to_dict(self):
        params = {'avatar': self.avatar_url}

        ret = super(Org, self).to_dict()
        ret.update(params)
        ret['domain'] = self.default_domain_name
        # ret['domains'] = self.domains.values('id', 'name', 'is_default')
        from yxt.models import OrgYxt
        if OrgYxt.objects.getx(org_id=self.id):
            ret['api_url'] = settings.API_URL_YXT
            ret['bfs_url'] = settings.BFS_URL_YXT
            # ret['cookie_domain'] = settings.SESSION_COOKIE_DOMAIN_YXT
        else:
            ret['api_url'] = settings.API_URL
            ret['bfs_url'] = settings.BFS_URL_STARFISH
            # ret['cookie_domain'] = settings.SESSION_COOKIE_DOMAIN_STARFISH

        attribute = OrgAttribute.objects.get_or_none(org_id=self.id)
        if attribute:
            ret['province'] = attribute.province
            ret['city'] = attribute.city
            ret['category'] = attribute.category.to_dict() if attribute.category else ''
        else:
            ret['province'] = ''
            ret['city'] = ''
            ret['category'] = ''

        return ret

    @property
    def default_department(self):
        '''get default all department of org, or create it if not exists'''
        d = Department.objects \
            .using(shard_id(self.id)) \
            .get_or_none(type=Department.TYPE_DEFAULT_ALL, parent=None)

        if d is None:
            d = Department(
                creator=self.creator,
                name=self.name,
                avatar=self.avatar,
                type=Department.TYPE_DEFAULT_ALL,
                parent=None
            )
            d.save(using=shard_id(self.id))

        return d

    @classmethod
    def last_modified(cls, request, org_id):
        return Org.objects.get_or_none(id=org_id).update_at

    class Meta:
        db_table = 'uc_org'
        ordering = ('order_field',)


class OrgAvatar(_models.FileModelsMixin):
    fs = FileSystemStorage(location=settings.FS_ROOT)


class OrgCategory(_models.BaseModel):
    name = models.CharField(max_length=128)
    parent = models.ForeignKey('self', db_constraint=False, null=True)

    @classmethod
    def create(cls, full_name):
        if not full_name:
            return

        parent = None
        for n in full_name.split('-'):
            obj = cls.objects.get_or_create(name=n, parent=parent)[0]
            parent = obj

        return parent

    def to_dict(self):
        res = [self.name]
        parent = self.parent
        while parent:
            res.append(parent.name)
            parent = parent.parent

        return '-'.join(reversed(res))

    class Meta:
        db_table = 'uc_org_category'


class OrgAttribute(_models.SimpleBaseModel):
    org_id = _models.PositiveBigIntegerField(db_index=True)
    province = models.CharField(max_length=64)
    city = models.CharField(max_length=64)
    category = models.ForeignKey(OrgCategory, db_constraint=False, null=True)

    class Meta:
        db_table = 'uc_org_attribute'


class UserOrg(_models.SimpleBaseModel):
    user_id = _models.PositiveBigIntegerField()
    org_id = _models.PositiveBigIntegerField(db_index=True)
    is_left = models.PositiveSmallIntegerField(default=0)

    @classmethod
    def user_in_org_ids(cls, user_id):
        return list(
            cls.objects.filter(user_id=user_id, is_left=0).values_list('org_id', flat=True)
        )

    class Meta:
        db_table = 'uc_user_org'
        unique_together = ('user_id', 'org_id', )


class InvitationCode(_models.SimpleBaseModel):
    code = models.CharField(max_length=16, unique=True)
    used_by_org = _models.PositiveBigIntegerField()

    class Meta:
        db_table = 'uc_invitation_code'


class WorkMail(_models.SimpleBaseOrgModel):
    TYPE_ORG_MEMBER = 0
    TYPE_DEPARTMENT = 1
    TYPE_DISCUSSION_GROUP = 2

    owner = _models.PositiveBigIntegerField()
    owner_type = models.PositiveSmallIntegerField()
    local_part = models.CharField(max_length=64)
    is_set = models.PositiveSmallIntegerField(default=0)
    domain_id = _models.PositiveBigIntegerField(db_index=True)

    @property
    def owner_model(self):
        if self.owner_type == self.TYPE_ORG_MEMBER:
            return get_model('account', 'User')
        elif self.owner_type == self.TYPE_DISCUSSION_GROUP:
            return get_model('org', 'DiscussionGroup')
        elif self.owner_type == self.TYPE_DEPARTMENT:
            return get_model('org', 'Department')

    @property
    def address(self):
        org_domain = OrgDomain.objects.getx(id=self.domain_id)
        if not org_domain:
            org = Org.objects.getx(id=self.org_id)
            if org:
                org_domain = org.default_domain
                self.domain_id = org_domain.id
                self.save()
            else:
                return None

        if self.is_fake('local_part') or not org_domain.valid_name:
            return ''
        else:
            return '%s@%s' % (self.local_part, org_domain.name)

    def to_dict(self):
        if self.owner_type == WorkMail.TYPE_ORG_MEMBER:
            return {'user_id': self.owner}

        return {'group_id': self.owner}

    @classmethod
    def find(cls, addr):
        try:
            local_part, domain = addr.split('@')
        except:
            return None
        org_domain = OrgDomain.objects.getx(name=domain)
        if org_domain:
            return cls.objects.using(org_domain.org_id).getx(local_part=local_part)

    @classmethod
    def find_user(cls, addr):
        r = cls.find(addr)
        if not r:
            return None

        if r.owner_type != WorkMail.TYPE_ORG_MEMBER:
            return None

        from apps.account.models import User
        return User.objects.get_or_none(id=r.owner)

    @classmethod
    def get_address(cls, owner, owner_type, org_id):
        wm = cls.objects \
            .using(shard_id(org_id)) \
            .getx(owner=owner, owner_type=owner_type)

        if wm and wm.is_set:
            return wm.address
        else:
            return ''

    @classmethod
    def find_many2(cls, owners, owner_type, org_id):
        o = Org.objects.getx(id=org_id)
        if not o:
            raise ValueError()

        ret = dict([(owner, '') for owner in owners])

        _r = cls.objects \
            .using(shard_id(org_id)) \
            .filter(owner__in=owners, owner_type=owner_type)
        r = dict([
            (i.owner, i.address) for i in _r
            if i.is_set and not i.is_fake('local_part')
        ])

        ret.update(r)

        return ret

    @classmethod
    def set_address(cls, org_id, owner, owner_type, local_part=None, domain_id=None):
        ''' raise APIError '''
        if domain_id:
            assert OrgDomain.objects.getx(id=domain_id).org_id == org_id
        if local_part and not is_valid_email_local_part(local_part):
            raise APIError(ErrorCode.INVALID_EMAIL_ADDR_LOCAL_PART)

        if local_part == '':  # '' to remove local_part
            local_part = WorkMail.fake_identity()
            is_set = 0
        else:
            is_set = 1

        wm, created = cls.objects.\
            using(org_id).\
            get_or_create(owner=owner, owner_type=owner_type)

        if not created:
            _local_part = local_part or wm.local_part
            _domain_id = domain_id or wm.domain_id
        else:
            if not local_part:
                raise APIError(ErrorCode.INVALID_EMAIL_ADDR_LOCAL_PART)
            _local_part = local_part
            _domain_id = domain_id or Org.objects.getx(id=org_id).default_domain.id

        if cls.objects.using(org_id)\
                .filter(local_part=_local_part, domain_id=_domain_id)\
                .exists():
            raise APIError(ErrorCode.ORG_MAIL_SET)

        if setattr_if_changed(wm, local_part=_local_part, domain_id=_domain_id, is_set=is_set):
            wm.save()

        return wm

    class Meta:
        db_table = 'uc_work_mail'
        unique_together = (('owner_type', 'owner'), ('local_part', 'domain_id'))


class DiscussionGroup(_models.BaseOrgModel):
    creator = _models.PositiveBigIntegerField()
    name = models.CharField(max_length=512)
    intro = models.CharField(max_length=1024)
    avatar = models.CharField(max_length=128)
    is_disbanded = models.PositiveSmallIntegerField(default=0)
    related_project_id = _models.PositiveBigIntegerField(default=0)
    order_field = models.IntegerField(default=0, db_index=True)

    @property
    def avatar_url(self):
        return '%s/%s/%s/%s' % (settings.DISCUSSION_GROUP_AVATAR_URL_PREFIX,
                                self.org_id, self.id,
                                self.avatar or GroupAvatarCache(self.org_id).get_or_create())

    def user_count(self):
        return UserDiscussionGroup.objects \
            .using(self.org_id) \
            .filter(group_id=self.id) \
            .filter(is_left=0).count()

    @classmethod
    def to_dict_list(cls, org_id, obj_list):
        ret = []
        group_ids = [i.id for i in obj_list]
        if not group_ids:
            return ret

        # related_projects = cls.related_project_list(org_id, obj_list)
        work_mails = WorkMail.find_many2(group_ids, WorkMail.TYPE_DISCUSSION_GROUP, org_id)

        for obj in obj_list:
            ret.append(cls._to_dict0(
                obj, work_mails[obj.id], org_id))

        return ret

    @classmethod
    def _to_dict0(cls, obj, work_mail, org_id):
        params = {
            'avatar': obj.avatar_url,
            'work_mail': work_mail,
            'create_timestamp': dt_to_timestamp(obj.create_time),
            'create_time': time_to_str(obj.create_time)
        }

        # if not obj.avatar:
        #     params['avatar'] = '%s%s' % (
        #         params['avatar'],
        #         GroupAvatarCache(org_id).get_or_create()
        #     )

        ret = super(DiscussionGroup, obj).to_dict()
        # ret = super(DiscussionGroup, obj).to_dict(exclude=['related_project_id'])
        ret.update(params)

        return ret

    # @classmethod
    # def related_project_list(cls, org_id, obj_list):
    #     ret = dict([(i.id, None) for i in obj_list])
    #
    #     from apps.project.models import Project
    #     r = Project.objects \
    #         .using(org_id) \
    #         .filter(discussion_group_id__in=[i.id for i in obj_list])
    #
    #     ret.update(dict([(i.discussion_group_id, i) for i in r]))
    #
    #     return ret

    def related_project(self):
        if self.related_project_id:
            from apps.project.models import Project
            return Project.objects.using(self.org_id).getx(id=self.related_project_id)
        # if not hasattr(self, '__related_project'):
        #     self.__related_project = self.related_project_list(self.org_id, [self])[self.id]
        # return self.__related_project

    def to_dict(self):
        return self.to_dict_list(self.org_id, [self])[0]

    def has_user(self, user_id):
        r = UserDiscussionGroup.objects \
            .using(self.org_id) \
            .getx(group_id=self.id, user_id=user_id)
        return r and not r.is_left

    def has_operate_permission(self, operator):
        if self.is_disbanded:
            return False
        elif operator.is_admin(self.org_id):
            return True
        else:
            project = self.related_project()
            if project:  # project discuss group
                return operator.id == project.person_in_charge
            else:  # normal discuss group
                return self.has_user(operator.id)

    def add_users(self, operator, user_ids):
        '''
            interface to add users to a discuss_group, with permission check
            raise APIError.
        '''
        if not self.has_operate_permission(operator):
            raise APIError(ErrorCode.PERMISSION_DENIED)

        from apps.account.models import User
        for user_id in user_ids:
            user = User.objects.getx(id=user_id)
            if not user:
                raise APIError(ErrorCode.NO_SUCH_USER, user_id=user_id)
            if not user.in_org(self.org_id):
                raise APIError(ErrorCode.NO_SUCH_USER_IN_ORG,
                               user_id=user_id, org_id=self.org_id)
            # add user to group
            UserDiscussionGroup.add(user_id, self.id, self.org_id)

        self.update_hash()

    def remove_users(self, operator, user_ids):
        '''
            interface to remove users from a discuss_group, with permission check
            raise APIError.
        '''
        if not self.has_operate_permission(operator):
            raise APIError(ErrorCode.PERMISSION_DENIED)

        for user_id in user_ids:
            # if self.creator == user_id:
            #     raise APIError(ErrorCode.CAN_NOT_REMOVE_CREATOR_FROM_DISCUSSION_GROUP)

            UserDiscussionGroup.remove(user_id, self.id, self.org_id)

        self.update_hash()

    def update_hash(self):
        pass
        # DiscussionGroupHash.update_hash_for_group(self.org_id, self.id)

    class Meta:
        db_table = 'uc_discussion_group'
        ordering = ('order_field',)


class DiscussionGroupHash(_models.SimpleBaseOrgModel):
    group_id = _models.PositiveBigIntegerField(unique=True)
    hash = models.BinaryField(unique=True)

    @classmethod
    def find(cls, org_id, user_ids):
        hash = cls.calc_hash(user_ids)
        obj = cls.objects.using(org_id).get_or_none(hash=hash)
        if obj:
            return obj.group_id

    @classmethod
    def calc_hash(cls, user_ids):
        keys = ','.join(str(i) for i in sorted(list(set(user_ids))))
        return hashlib.md5(keys.encode('utf8')).digest()

    @classmethod
    def update_hash_for_group(cls, org_id, group_id):
        #  for project discussion group, do not save hash, so project groups are not users-unique
        d = DiscussionGroup.objects.using(org_id).getx(id=group_id, is_disbanded=0)
        if not d or d.related_project_id:
            return

        # do not hash for no-user discuss_group
        user_ids = UserDiscussionGroup.user_ids(org_id, group_id)
        if not user_ids:
            return

        hash = cls.calc_hash(user_ids)
        obj, created = cls.objects.using(org_id)\
            .get_or_create(group_id=group_id,
                           defaults={'hash': hash})

        if not created and setattr_if_changed(obj, hash=hash):
            obj.save()

        return obj

    class Meta:
        db_table = 'uc_discussion_group_hash'


class DiscussionGroupAvatar(_models.FileModelsMixin):
    fs = FileSystemStorage(location=settings.FS_ROOT)


class UserDiscussionGroup(_models.SimpleBaseOrgModel):
    DEFAULT_CACHE_TIMEOUT = 86400

    user_id = _models.PositiveBigIntegerField()
    group_id = _models.PositiveBigIntegerField(db_index=True)
    date_joined = models.PositiveIntegerField()
    is_left = models.PositiveSmallIntegerField(default=0)

    def save(self, *args, **kwargs):
        if not self.pk and not self.date_joined:
            self.date_joined = current_timestamp()

        super(UserDiscussionGroup, self).save(*args, **kwargs)

    @classmethod
    def add(cls, user_id, group_id, org_id):
        try:
            v = UserDiscussionGroup(
                user_id=user_id,
                group_id=group_id,
                date_joined=current_timestamp()
            )
            with transaction.atomic():
                v.save(using=shard_id(org_id))
        except IntegrityError:
            v = UserDiscussionGroup.objects \
                .using(shard_id(org_id)) \
                .get_or_none(user_id=user_id, group_id=group_id)

            if setattr_if_changed(v, is_left=0):
                v.save(using=shard_id(org_id))

    @classmethod
    def remove(cls, user_id, group_id, org_id):
        o = UserDiscussionGroup.objects. \
            using(shard_id(org_id)). \
            get_or_none(group_id=group_id, user_id=user_id)
        if o:
            o.is_left = 1
            o.save(using=shard_id(org_id))

    @classmethod
    def group_ids(cls, org_id, user_id):
        r = UserDiscussionGroup.objects \
            .using(shard_id(org_id)) \
            .filter(user_id=user_id) \
            .filter(is_left=0)

        group_ids = [i.group_id for i in r]
        groups = DiscussionGroup.objects \
            .using(shard_id(org_id)) \
            .filter(id__in=group_ids, is_disbanded=0)

        return [g.id for g in groups]

    @classmethod
    def user_ids(cls, org_id, group_id, filter_disbanded=True):
        g = DiscussionGroup.objects \
            .using(shard_id(org_id)) \
            .getx(id=group_id, is_disbanded=0)
        if not g and filter_disbanded:
            return []

        r = UserDiscussionGroup.objects \
            .using(shard_id(org_id)) \
            .filter(group_id=group_id) \
            .filter(is_left=0)

        return list(r.values_list('user_id', flat=True))

    @classmethod
    def last_modified_by_user(cls, request, org_id, user_id):
        cache_key = cls._last_modified_cache_key(org_id, 'user', user_id)
        r = cache.get(cache_key)
        if not r:
            return cls.update_last_modified(org_id, 'user', user_id)

        return r

    @classmethod
    def last_modified_by_group(cls, request, org_id, group_id):
        if isinstance(group_id, int):
            group_ids = [group_id]
        else:
            group_ids = [int(i) for i in group_id.split(',') if i]

        keys = [cls._last_modified_cache_key(org_id, 'group', i) for i in group_ids]
        values = cache.get_many(keys)
        if len(keys) == len(values):
            return max(values.values())

        now = current_timestamp()
        set_many_args = dict([(k, now) for k in keys if k not in values])
        cache.set_many(set_many_args, cls.DEFAULT_CACHE_TIMEOUT)

        return now

    @classmethod
    def _last_modified_cache_key(cls, org_id, k, id_):
        return '%s_last_modified_cache_key_%s:%s:%s' % ('UserDiscussionGroup', org_id, k, id_)

    @classmethod
    def update_last_modified(cls, org_id, k, id_):
        v = current_timestamp()
        cache.set(cls._last_modified_cache_key(org_id, k, id_), v, cls.DEFAULT_CACHE_TIMEOUT)
        return v

    class Meta:
        db_table = 'uc_user_discussion_group'
        unique_together = ('user_id', 'group_id', )


class Department(_models.BaseOrgModel):
    TYPE_NORMAL = 0
    TYPE_DEFAULT_ALL = 1

    parent = models.ForeignKey('self', db_constraint=False, null=True)
    creator = _models.PositiveBigIntegerField()
    name = models.CharField(max_length=512)
    avatar = models.CharField(max_length=128)
    is_disbanded = models.PositiveSmallIntegerField(default=0)
    order_field = models.IntegerField(default=0, db_index=True)

    TYPE_CHOICES = (
        (TYPE_NORMAL, 'normal'),
        (TYPE_DEFAULT_ALL, 'default all'),
    )
    type = models.PositiveSmallIntegerField(default=TYPE_NORMAL, choices=TYPE_CHOICES)

    @property
    def avatar_url(self):
        if self.avatar.lower().startswith('http'):
            return self.avatar

        return '%s/%s/%s/%s' % (settings.DEPARTMENT_AVATAR_URL_PREFIX,
                                self.org_id, self.id,
                                self.avatar or GroupAvatarCache(self.org_id).get_or_create())

    @property
    def children(self):
        return Department.objects.using(self.org_id).filter(parent=self, is_disbanded=0)

    @classmethod
    def to_dict_list(cls, org_id, obj_list):
        ret = []
        group_ids = [i.id for i in obj_list]
        if not group_ids:
            return ret

        work_mails = WorkMail.find_many2(group_ids, WorkMail.TYPE_DEPARTMENT, org_id)
        for obj in obj_list:
            ret.append(cls._to_dict0(obj, work_mails[obj.id], org_id))

        return ret

    def has_user(self, user_id, direct_in=0):
        qs = UserDepartment.objects.using(self.org_id).filter(group_id=self.id, user_id=user_id)
        if direct_in:
            qs = qs.filter(direct_in=1)
        return qs.exists()

    def user_count(self, direct_in=0):
        qs = UserDepartment.objects \
            .using(self.org_id) \
            .filter(group_id=self.id)
        if direct_in:
            qs = qs.filter(direct_in=1)
        return qs.count()

    def to_dict(self):
        return self.to_dict_list(self.org_id, [self])[0]

    @classmethod
    def _to_dict0(cls, obj, work_mail, org_id):
        params = {
            'avatar': obj.avatar_url,
            'work_mail': work_mail,
        }
        # if not obj.avatar:
        #     params['avatar'] = '%s%s' % (
        #         params['avatar'],
        #         GroupAvatarCache(org_id).get_or_create()
        #     )

        ret = super(Department, obj).to_dict()
        ret.update(params)

        if ret['parent'] is None:
            ret['parent'] = 0

        ret['children_count'] = obj.children.count()
        ret['all_members_count'] = obj.user_count(direct_in=0)
        return ret

    @classmethod
    def user_ids(cls, org_id, group_id, direct_in=0, filter_disbanded=True):
        g = cls.objects.using(org_id).getx(id=group_id)
        if not g:
            raise APIError(ErrorCode.NO_SUCH_DEPARTMENT, group_id=group_id)
        if filter_disbanded and g.is_disbanded:
            return []

        qs = UserDepartment.objects \
            .using(org_id) \
            .filter(group_id=group_id)
        if direct_in:
            qs = qs.filter(direct_in=1)

        return list(qs.values_list('user_id', flat=True))

    @classmethod
    def reset_user_indirect_in(cls, org_id, user_id):
        uc_qs = UserDepartment.objects.using(org_id).filter(user_id=user_id)

        # get all indirect(parents) by direct_ids
        direct_ids = uc_qs.filter(direct_in=1).values_list('group_id', flat=True)
        parents = []
        for group_id in direct_ids:
            parents += Department.objects.using(org_id).getx(id=group_id).all_parents()

        # indirect ids except direct ids
        indirect_ids = set([p.id for p in parents if p.id not in direct_ids])

        # delete indirect not need any more
        uc_qs.filter(direct_in=0).exclude(group_id__in=indirect_ids).delete()

        # indirect that existed
        existed = uc_qs.filter(direct_in=0).values_list('group_id', flat=True)

        # add new indirect
        for group_id in set(indirect_ids)-set(existed):
            UserDepartment.create(org_id, user_id, group_id, 0)

        # user departments changed, send message of direct_in and indirect_in
        body = {
            'user_id': user_id,
            'is_direct': list(direct_ids),
            'is_not_direct': list(indirect_ids)
        }
        # for Forward Compatible
        body.update(direct_in=body['is_direct'], indirect_in=body['is_not_direct'])

        from common.message_queue import SystemMessage
        from apps.message.models import Message
        SystemMessage(Message.TYPE_MEMBER_DEPARTMENTS_UPDATED, body, org_id).send(user_id)

    @classmethod
    def user_reset_direct_in(cls, org_id, user_id, group_ids):
        '''rest user direct in groups'''
        uc_qs = UserDepartment.objects.using(org_id).filter(user_id=user_id)

        uc_qs.filter(direct_in=1).exclude(group_id__in=group_ids).delete()
        existed = uc_qs.filter(direct_in=1).values_list('group_id', flat=True)
        for group_id in set(group_ids)-set(existed):
            obj, created = UserDepartment.objects.using(org_id)\
                .get_or_create(user_id=user_id, group_id=group_id, defaults={'direct_in': 1})

            if not created and setattr_if_changed(obj, direct_in=1):
                obj.save()

        cls.reset_user_indirect_in(org_id, user_id)

    def all_parents(self):
        _all = []
        parent_id = self.parent_id
        while parent_id:
            parent = Department.objects.using(self.org_id).getx(id=parent_id)
            if not parent:
                break
            _all.append(parent)
            parent_id = parent.parent_id

        return _all

    def add_direct_in(self, *user_ids):
        '''add direct in users'''
        for user_id in user_ids:
            obj, created = UserDepartment.objects\
                .using(self.org_id)\
                .get_or_create(user_id=user_id,
                               group_id=self.id,
                               defaults={'direct_in': 1})
            if not created and setattr_if_changed(obj, direct_in=1):
                obj.save()
            Department.reset_user_indirect_in(self.org_id, user_id)

    def remove_direct_in(self, *user_ids):
        '''remove direct in users'''
        for user_id in user_ids:
            qs = UserDepartment.objects\
                .using(self.org_id)\
                .filter(group_id=self.id, user_id=user_id, direct_in=1)
            if qs.exists():
                qs.delete()
                Department.reset_user_indirect_in(self.org_id, user_id)

    class Meta:
        db_table = 'uc_department'
        ordering = ('order_field',)


class DepartmentAvatar(_models.FileModelsMixin):
    fs = FileSystemStorage(location=settings.FS_ROOT)


class UserDepartment(_models.SimpleBaseOrgModel):
    user_id = _models.PositiveBigIntegerField()
    group_id = _models.PositiveBigIntegerField(db_index=True)
    direct_in = models.PositiveSmallIntegerField(default=1)

    @classmethod
    def normalize(cls, org_id):
        org_member_ids = UserOrg.objects\
            .filter(org_id=org_id, is_left=0)\
            .values_list('user_id', flat=True)
        department_member_ids = UserDepartment.objects.using(org_id) \
            .filter(direct_in=1) \
            .values_list('user_id', flat=True) \
            .distinct()
        for user_id in set(org_member_ids) - set(department_member_ids):
            o = Org.objects.getx(id=org_id)
            d = o.default_department
            d.add_direct_in(user_id)

    @classmethod
    def create(cls, org_id, user_id, group_id, direct_in):
        try:
            v, created = cls.objects.using(org_id)\
                .get_or_create(user_id=user_id,
                               group_id=group_id,
                               defaults={"direct_in": direct_in}
                               )
            if not created and v.direct_in != direct_in:
                v.delete()
                cls.create(org_id, user_id, group_id, direct_in)

            # v = cls(
            #     user_id=user_id,
            #     group_id=group_id,
            #     direct_in=direct_in
            # )
            # with transaction.atomic():
            #     v.save(using=shard_id(org_id))
        except IntegrityError as e:
            log.exception(e)

    class Meta:
        db_table = 'uc_user_department'
        unique_together = ('user_id', 'group_id', )


class Invitation(_models.BaseModel):
    (STATUS_INIT,
     STATUS_IGNORE,
     STATUS_REFUSE,
     STATUS_CONFIRM
     ) = list(range(4))

    who = _models.PositiveBigIntegerField()
    whom = _models.PositiveBigIntegerField()
    org_id = _models.PositiveBigIntegerField()
    status = models.PositiveSmallIntegerField(default=STATUS_INIT)
    date_added = models.PositiveIntegerField()
    date_updated = models.PositiveIntegerField()

    def save(self, *args, **kwargs):
        if not self.pk and not self.date_added:
            self.date_added = current_timestamp()

        self.date_updated = current_timestamp()

        super(Invitation, self).save(*args, **kwargs)

    def to_dict(self):
        from apps.account.models import User

        r = super(Invitation, self).to_dict()
        org = Org.objects.get_or_none(id=self.org_id)
        r.update({
            'who': User.objects.get_or_none(id=self.who).to_dict(),
            'whom': User.objects.get_or_none(id=self.whom).to_dict(),
            'org': org.to_dict() if org else None,
        })

        return r

    class Meta:
        db_table = 'uc_invitation'
        index_together = [['who', 'whom', 'org_id']]


class ExternalInvitation(_models.BaseModel):
    VALID_DAYS = 7  # auto invite user into org if external invitation phone registered

    SECURITY_CODE_LENGTH = 32
    VALID_KEY_CHARS = string.ascii_lowercase + string.digits

    (INVITATION_TYPE_NORMAL,
     INVITATION_TYPE_WECHAT) = range(2)

    admin = _models.PositiveBigIntegerField()
    account = models.CharField(max_length=128)
    org_id = _models.PositiveBigIntegerField()
    security_code = models.CharField(max_length=SECURITY_CODE_LENGTH, unique=True)
    used = models.PositiveSmallIntegerField(default=0)
    invitation_type = models.PositiveSmallIntegerField(default=0)

    def to_dict(self):
        from apps.account.models import User

        r = super(ExternalInvitation, self).to_dict()
        r['admin'] = User.objects.get_or_none(id=self.admin).to_dict()
        r['org'] = Org.objects.get_or_none(id=self.org_id).to_dict()
        return r

    @property
    def is_wechat(self):
        return self.invitation_type == self.INVITATION_TYPE_WECHAT

    @classmethod
    def create(cls, admin, account, org_id, invitation_type=0):
        retries = 10
        for i in range(retries):
            try:
                r = ExternalInvitation(
                    admin=admin,
                    account=account,
                    org_id=org_id,
                    security_code=get_random_string(cls.SECURITY_CODE_LENGTH, cls.VALID_KEY_CHARS),
                    invitation_type=invitation_type
                )
                with transaction.atomic():
                    r.save()

                return r
            except IntegrityError as e:
                if i == retries - 1:
                    raise e

    class Meta:
        db_table = 'uc_external_invitation'


class UserPosition(_models.SimpleBaseOrgModel):
    user_id = _models.PositiveBigIntegerField(unique=True)
    position = models.CharField(max_length=128)

    class Meta:
        db_table = 'uc_user_position'


class ExternalContact(_models.BaseOrgModel):
    FAKE_DELETE_FIELDS = ('email',)
    DEFAULT_AVATAR = '%s/member_info_default_icon.png' % settings.FS_ROOT

    name = models.CharField(max_length=128, default='')
    gender = models.PositiveSmallIntegerField(default=Gender.GENDER_UNKNOWN)
    phone = models.CharField(max_length=32, default='')
    wechat = models.CharField(max_length=128, default='')
    email = models.CharField(max_length=128, default='', unique=True)
    corporation = models.CharField(max_length=128, default='')
    position = models.CharField(max_length=32, default='')
    department = models.CharField(max_length=32, default='')
    address = models.CharField(max_length=256, default='')
    avatar = models.CharField(max_length=128)
    creator = _models.PositiveBigIntegerField(default=0)
    manager = _models.PositiveBigIntegerField(default=0)

    @property
    def avatar_url(self):
        return '%s/%s/%s/%s' % (settings.EXTERNAL_CONTACT_AVATAR_URL_PREFIX,
                                self.org_id, self.id, self.avatar)

    def save(self, *args, **kwargs):
        if self.gender is None or self.gender == '':
            self.gender = Gender.GENDER_UNKNOWN

        if self.manager == '':
            self.manager = 0

        if not self.email:
            self.email = self.fake_identity()

        super(ExternalContact, self).save(*args, **kwargs)

    def to_dict(self):
        r = super(ExternalContact, self).to_dict()
        if self.phone:
            r['formatted_phone'] = format_phone_number(self.phone)
        else:
            r['formatted_phone'] = ''

        if self.is_fake('email'):
            r['email'] = ''

        r['avatar'] = self.avatar_url
        return r

    class Meta:
        db_table = 'uc_external_contacts'


class ExternalContactAvatar(_models.FileModelsMixin):
    fs = FileSystemStorage(location=settings.FS_ROOT)


class GroupAvatarCache(object):
    KEY_PATTERN = 'GroupAvatarCache:{org_id}'

    DEFAULT_CACHE_TIMEOUT = 86400

    def __init__(self, org_id):
        self.org_id = org_id

    def get_or_create(self, v=None):
        r = cache.get(self._key())
        if r:
            return r

        if not v:
            v = current_timestamp()
        cache.set(self._key(), v, self.DEFAULT_CACHE_TIMEOUT)
        return v

    def delete(self):
        log.info('clear group avatar cache: %s', self._key())
        cache.delete(self._key())

    def _key(self):
        return self.KEY_PATTERN.format(org_id=self.org_id)


class GeneratedContact(_models.BaseOrgModel):
    FAKE_DELETE_FIELDS = ('email',)

    name = models.CharField(max_length=128, null=True)
    gender = models.PositiveSmallIntegerField(default=Gender.GENDER_UNKNOWN)
    phone = models.CharField(max_length=32, null=True)
    email = models.CharField(max_length=128, unique=True)

    @property
    def avatar_url(self):
        return ''

    @classmethod
    def create_by_name_and_email(cls, name, email, org_id):
        r, _ = cls.objects \
            .using(org_id) \
            .get_or_create(email=email, defaults={'name': name})
        return r

    def add_users(self, *user_ids):
        queryset = UserGeneratedContact.objects.using(self._state.db)
        exist_user_ids = queryset\
            .filter(contact_id=self.id, user_id__in=user_ids)\
            .values_list('user_id', flat=True)

        to_added = list(set(user_ids)-set(exist_user_ids))
        queryset.bulk_create(
            [UserGeneratedContact(user_id=uid, contact_id=self.id) for uid in to_added]
        )

    def to_dict(self):
        r = super(GeneratedContact, self).to_dict()
        r['formatted_phone'] = format_phone_number(self.phone) if self.phone else ''
        return r

    class Meta:
        db_table = 'uc_generated_contact'


class UserGeneratedContact(_models.SimpleBaseOrgModel):
    user_id = _models.PositiveBigIntegerField(db_index=True)
    contact_id = _models.PositiveBigIntegerField(db_index=True)

    class Meta:
        db_table = 'uc_user_generated_contact'
        unique_together = ('user_id', 'contact_id', )


class OrgApp(_models.BaseOrgModel):
    PROJECT = 1
    FILE = 2
    MAIL = 3

    creator = _models.PositiveBigIntegerField()
    app = models.PositiveIntegerField(unique=True)
    is_install = models.PositiveSmallIntegerField(default=0)

    @classmethod
    def has_install(cls, org_id, app):
        return cls.objects.using(org_id).getx(app=app, is_install=1) is not None

    class Meta:
        db_table = 'app_org_app'


class MemberOrgApp(_models.SimpleBaseOrgModel):
    user_id = _models.PositiveBigIntegerField(db_index=True)
    app = models.PositiveIntegerField()
    is_navi = models.PositiveSmallIntegerField(default=0)

    class Meta:
        db_table = 'app_user_org_app'
        unique_together = ('user_id', 'app', )
