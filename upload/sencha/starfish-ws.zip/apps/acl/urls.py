from django.conf.urls import patterns, url

from apps.acl import views
from apps.acl.models import SystemRole

permissions_list = views.ACLViewSet.as_view({
    'post': ('query', SystemRole.GUEST)
})

self_permissions_list = views.ACLViewSet.as_view({
    'post': 'query_self',
})

admins_list = views.ACLUserRoleViewSet.as_view({
    'post': ('create', SystemRole.ORG_CREATOR),
    'get': 'list',
})

admin_detail = views.ACLUserRoleViewSet.as_view({
    'get': 'retrieve',
    'delete': ('destroy', SystemRole.ORG_CREATOR)
})

urlpatterns = patterns(
    '',
    url(r'^v1/permissions$', permissions_list, name='permissions-list'),
    url(r'^v1/self_permissions$', self_permissions_list, name='self-permissions-list'),
    url(r'^v1/orgs/(?P<org_id>\d+)/administrators$', admins_list, name='admins-list'),
    url(r'^v1/orgs/(?P<org_id>\d+)/administrators/(?P<user_id>\d+)$',
        admin_detail, name='admin-detail'),
)
