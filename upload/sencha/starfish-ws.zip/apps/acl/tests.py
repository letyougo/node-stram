from apps.acl.models import RuleDescriptor
import unittest
from common.tests import TestCase
from common.const import ErrorCode


@unittest.skip("testing skipping")
class SimpleTest(TestCase):

    def test_query_permission(self):
        data = {
            "permissions": [
                {'user_id': self.users['alice'].id,
                 'resource': {
                     'desc': 'project-app-projects-list',
                     'args': {'org_id': self.orgs['ibm'].id}},
                 'permission': RuleDescriptor.PERMISSION_CREATE},
                {'user_id': 0,
                 'resource': {
                     'desc': 'sessions-list',
                     'args': {'org_id': 0}},
                 'permission': RuleDescriptor.PERMISSION_CREATE}
            ]
        }
        response = self.client.post('/v1/permissions', data=data, format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.OK)
        self.assertEqual(response.data['data'][0]['is_allowed'], True)
        self.assertEqual(response.data['data'][1]['is_allowed'], True)

    def test_query_self_permission(self):
        self.login('alice')

        data = {
            "permissions": [
                {'resource': {
                    'desc': 'project-app-projects-list',
                    'args': {'org_id': self.orgs['ibm'].id}},
                 'permission': RuleDescriptor.PERMISSION_CREATE},
                {'resource': {
                    'desc': 'sessions-list',
                    'args': {'org_id': 0}},
                 'permission': RuleDescriptor.PERMISSION_CREATE}
            ]
        }
        response = self.client.post('/v1/self_permissions', data=data, format='json')
        self.assertEqual(response.data['errcode'], ErrorCode.OK)
        self.assertEqual(response.data['data'][0]['is_allowed'], True)
        self.assertEqual(response.data['data'][1]['is_allowed'], True)
