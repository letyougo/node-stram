from rest_framework.response import Response

from apps.acl.models import ACL, Resource, Role, UserRole

from common.utils import shard_id, current_timestamp
from common.const import ErrorCode
from common.viewset import ViewSet


class ACLViewSet(ViewSet):
    def query(self, request):
        ret = []
        for r in request.DATA['permissions']:
            user_id, resource, permission = (
                int(r['user_id']),
                Resource(r['resource']['desc'], r['resource']['args']),
                int(r['permission'])
            )
            ret.append(r)
            ret[-1]['is_allowed'] = ACL.is_allowed(user_id, resource, permission)

        return Response({'errcode': ErrorCode.OK, 'data': ret})

    def query_self(self, request):
        ret = []
        for r in request.DATA['permissions']:
            user_id, resource, permission = (
                request.current_uid,
                Resource(r['resource']['desc'], r['resource']['args']),
                int(r['permission'])
            )
            ret.append(r)
            ret[-1]['is_allowed'] = ACL.is_allowed(user_id, resource, permission)

        return Response({'errcode': ErrorCode.OK, 'data': ret})


class ACLUserRoleViewSet(ViewSet):
    ROLE_AGE = 3600 * 24 * 365 * 3

    def create(self, request, org_id):
        r = UserRole.add(request.DATA['user_id'], org_id,
                         expires_at=current_timestamp() + self.ROLE_AGE)
        return Response({'errcode': ErrorCode.OK, 'data': r.to_dict()})

    def list(self, request, org_id):
        r = UserRole.objects \
            .using(shard_id(org_id)) \
            .filter(role=Role.role_id(org_id, Role.ADMIN_ROLE_NAME))

        return Response({'errcode': ErrorCode.OK, 'data': [i.to_dict() for i in r]})

    def retrieve(self, request, org_id, user_id):
        ur = UserRole.objects \
            .using(shard_id(org_id)) \
            .get_or_none(user_id=user_id, role=Role.role_id(org_id, Role.ADMIN_ROLE_NAME))

        data = ur.to_dict() if ur else {}
        return Response({'errcode': ErrorCode.OK, 'data': data})

    def destroy(self, request, org_id, user_id):
        UserRole.objects \
            .using(shard_id(org_id)) \
            .filter(user_id=user_id) \
            .filter(role=Role.role_id(org_id, Role.ADMIN_ROLE_NAME)) \
            .delete()

        return Response({'errcode': ErrorCode.OK})
