from django.conf.urls import patterns, url
from apps.acl.models import SystemRole

from apps.misc import views

download = views.MiscViewSet.as_view({
    'get': ('download', SystemRole.GUEST)
})

wechat_notify = views.MiscViewSet.as_view({
    'post': ('wechat_notify', SystemRole.GUEST),
    'get': ('wechat_notify', SystemRole.GUEST)
})

urlpatterns = patterns(
    '',
    url(r'^v1/downloads/(?P<code>\w+)/(?P<platform>\w+)$', download, name='download'),

    url(r'^v1/wechat_notify$', wechat_notify, name='wechat-notify'),
)
